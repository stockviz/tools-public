"""Test the local tool boundary without sending data through a language model."""
from contextlib import asynccontextmanager
import tempfile
from types import SimpleNamespace
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from mcp_consumer.cli import parser
from mcp_consumer.client import run_download
from mcp_consumer.download import DownloadError
from mcp_consumer.server import build_server, safe_output


class InterfaceTests(unittest.IsolatedAsyncioTestCase):
    """Cover CLI discoverability and constrained MCP file destinations."""

    def test_parser_accepts_nav_index_login_serve(self):
        """Parse the exact documented command shapes."""
        p = parser()
        for command in [["login"], ["nav", "--scheme-code", "105758", "--output", "fund.csv"],
                        ["index", "--index-name", "NIFTY 50 TR", "--output", "index.csv"],
                        ["serve", "--output-dir", "exports"]]:
            with self.subTest(command=command):
                self.assertEqual(p.parse_args(command).command, command[0])

    def test_safe_output_rejects_path_traversal(self):
        """A model may choose a basename, never a path outside the operator's root."""
        with tempfile.TemporaryDirectory() as tmp:
            for name in ["../bad.csv", "/bad.csv", "nested/bad.csv", "bad.txt", "..", "a\\b.csv"]:
                with self.subTest(name=name):
                    with self.assertRaises(ValueError):
                        safe_output(Path(tmp), name)
            self.assertEqual(safe_output(Path(tmp), "fund.csv"), Path(tmp) / "fund.csv")

    async def test_download_error_survives_transport_sanitization(self):
        """Keep safe partial-file diagnostics outside the transport exception guard."""
        @asynccontextmanager
        async def connection(*args, **kwargs):
            """Emulate the production transport's secret-safe context boundary."""
            try:
                yield SimpleNamespace(call_tool=AsyncMock())
            except Exception:
                raise RuntimeError("sanitized") from None
        with patch("mcp_consumer.client.connect", connection), patch("mcp_consumer.client.download", new=AsyncMock(side_effect=DownloadError("Incomplete file: known.partial"))):
            with self.assertRaisesRegex(DownloadError, "known.partial"):
                await run_download("https://example.test/mcp", Path("auth"), "get_nav_history",
                                   {"scheme_code":"105758"}, Path("test.csv"))

    async def test_mcp_discovery_and_complete_download_wrapper(self):
        """Expose compact download tools rather than raw row or cursor arguments."""
        with tempfile.TemporaryDirectory() as tmp:
            server = build_server("https://example.test/mcp", Path(tmp) / "auth", Path(tmp) / "exports")
            tools = await server.list_tools()
            self.assertEqual({tool.name for tool in tools}, {"download_nav_history", "download_index_history"})
            for tool in tools:
                self.assertNotIn("cursor", tool.inputSchema["properties"])
            with patch("mcp_consumer.server.run_download", new=AsyncMock(return_value={"status":"complete","row_count":4})) as run:
                value = await server.call_tool("download_nav_history", {"scheme_code":"105758", "filename":"fund.csv"})
                self.assertTrue(value)
                self.assertEqual(run.await_args.args[2], "get_nav_history")
                self.assertEqual(run.await_args.args[4], Path(tmp) / "exports" / "fund.csv")


if __name__ == "__main__":
    unittest.main()
