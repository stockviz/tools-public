"""Run archived setup commands with space-containing paths and real stdio."""
import asyncio
import os
import re
import shlex
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from build_share import build


class DocumentedInstallTests(unittest.TestCase):
    """Keep the printed Goose command executable outside the project directory."""

    def test_archived_instructions_start_stdio_from_unrelated_directory(self):
        """Extract a source ZIP, install offline, and discover four real tools."""
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory(prefix="documented install spaces ") as temporary:
            work = Path(temporary)
            archive_path = work / "mcp-consumer-share.zip"
            build(root, archive_path)
            with zipfile.ZipFile(archive_path) as archive:
                self.assertEqual({Path(name).parts[0] for name in archive.namelist()}, {"mcp-consumer"})
                self.assertFalse(any(".venv" in Path(name).parts for name in archive.namelist()))
                archive.extractall(work)
            project = work / "mcp-consumer"
            self.assertTrue((project / "mcp_consumer/cli.py").is_file())
            # Reuse the suite's verified dependencies; this regression never needs a network.
            environment = dict(os.environ, PIP_NO_INDEX="1", PIP_DISABLE_PIP_VERSION_CHECK="1")
            environment["PYTHONPATH"] = os.pathsep.join(
                entry for entry in sys.path if entry and Path(entry).name in {"site-packages", "dist-packages"})
            subprocess.run([sys.executable, "-m", "venv", ".venv"], cwd=project,
                           env=environment, check=True, capture_output=True, text=True, timeout=60)
            python = project / ".venv/bin/python"
            installed = subprocess.run([str(python), "-m", "pip", "install", "--no-build-isolation", "--no-deps", "-e", "."],
                                       cwd=project, env=environment, capture_output=True, text=True, timeout=60)
            self.assertEqual(installed.returncode, 0, installed.stdout + installed.stderr)
            commands = []
            for name in ("README.md", "PUBLIC_README.md"):
                text = (project / name).read_text()
                self.assertIn("unzip mcp-consumer-share.zip\ncd mcp-consumer", text)
                blocks = re.findall(r"```sh\n(.*?)\n```", text, re.S)
                generators = [block for block in blocks if "GOOSE_COMMAND=" in block]
                self.assertEqual(len(generators), 1, name + " must generate the Goose command")
                block = generators[0].split('\ngoose session')[0]
                result = subprocess.run(["sh", "-eu", "-c", block], cwd=project, env=environment,
                                        check=True, capture_output=True, text=True, timeout=30)
                command = result.stdout.strip()
                expected = [str(project / ".venv/bin/stockviz-mcp-consumer"),
                            "--config", str(project / "config.json"), "serve"]
                self.assertEqual(shlex.split(command), expected)
                commands.append(command)
            self.assertEqual(commands[0], commands[1])
            elsewhere = work / "unrelated working directory"
            elsewhere.mkdir()
            asyncio.run(self.discover(commands[0], elsewhere, environment))
            resolved = subprocess.run([str(python), "-c",
                "import sys; from mcp_consumer.cli import parser, resolve_config; "
                "print(resolve_config(parser().parse_args(sys.argv[1:])).output_dir)",
                "--config", str(project / "config.json"), "serve"],
                cwd=elsewhere, env=environment, check=True, capture_output=True, text=True, timeout=30)
            self.assertEqual(Path(resolved.stdout.strip()), project / "exports")
            self.assertFalse((elsewhere / "exports").exists())

    async def discover(self, command, cwd, environment):
        """Initialize the installed executable over SDK stdio and list its tools."""
        argv = shlex.split(command)
        parameters = StdioServerParameters(command=argv[0], args=argv[1:], cwd=str(cwd), env=environment)
        async with asyncio.timeout(30):
            async with stdio_client(parameters) as (reader, writer):
                async with ClientSession(reader, writer) as session:
                    await session.initialize()
                    tools = await session.list_tools()
                    self.assertEqual({tool.name for tool in tools.tools}, {
                        "download_nav_history", "download_index_history", "download_equity_history", "list_equities"})


if __name__ == "__main__":
    unittest.main()
