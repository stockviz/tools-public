"""Run equity CLI and stdio over a real, explicitly synthetic HTTP MCP fixture."""
import asyncio
import json
import sys
import unittest
from datetime import timedelta

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from test_equity import FIELDS, equity
import test_feature_workflows as workflows
from test_feature_workflows import ROOT, SyntheticHistoryServer, opaque_cursor


ROWS = [equity(day) for day in ('2026-10-19', '2026-10-21', '2026-10-22')]
CATALOG = [dict(symbol='RELIANCE', series=series, first_date='2026-10-19',
                last_date='2026-10-22', observations=3) for series in ('BE', 'EQ')]


class SyntheticEquityServer(SyntheticHistoryServer):
    """Extend only the remote synthetic fixture, never the production consumer."""

    def __init__(self):
        """Register equity tools beside existing history fixtures."""
        super().__init__()
        self.server.add_tool(self.get_equity_history)
        self.server.add_tool(self.list_equities)

    def get_equity_history(self, symbol: str, series: str, start: str | None = None,
                           end: str | None = None, limit: int = 1000,
                           format: str = 'json', cursor: str | None = None) -> dict:
        """Return raw synthetic pages or explicit identity, cursor, gap and quota failures."""
        arguments = dict(symbol=symbol, series=series, start=start, end=end,
                         limit=limit, format=format, cursor=cursor)
        self.requests.append(('get_equity_history', arguments))
        if symbol == 'DATA_GAP':
            return {'status':'data_gap', 'rows':[], 'page':{'limit':limit, 'returned_count':0,
                    'has_more':False, 'next_cursor':None}}
        if symbol in ('RATE', 'BURST') and (symbol == 'BURST' or
                sum(a == arguments for t,a in self.requests if t == 'get_equity_history') == 1):
            return {'error':{'code':'download_rate_limited',
                    'category':'page_rate' if symbol == 'RATE' else 'burst',
                    'retry_after_seconds':0}}
        rows = [{**r, 'symbol':symbol, 'series':series} for r in ROWS
                if (start is None or r['date'] >= start) and (end is None or r['date'] <= end)]
        identity = [symbol, series]
        offset = 0
        if cursor is not None:
            matches = [i for i in range(limit, len(rows), limit)
                       if cursor == opaque_cursor('equity', identity, start, end, limit, i)]
            if not matches:
                raise ValueError('Synthetic equity cursor/context mismatch')
            offset = matches[0]
        selected = rows[offset:offset + limit]
        if offset and selected:
            if symbol == 'WRONG_SERIES':
                selected[0]['series'] = 'BE'
            elif symbol == 'WRONG_SYMBOL':
                selected[0]['symbol'] = 'OTHER'
            elif symbol == 'DUPLICATE':
                selected[0]['date'] = rows[0]['date']
        more = offset + len(selected) < len(rows)
        continuation = opaque_cursor('equity', identity, start, end, limit, offset + len(selected)) if more else None
        if symbol == 'REPEAT_CURSOR' and offset and more:
            continuation = cursor
        return {'status':'ok', 'rows':selected, 'page':{'limit':limit,
                'returned_count':len(selected), 'has_more':more, 'next_cursor':continuation},
                'metadata':{'warnings':['Raw stored equity prices are not adjusted.',
                  'Mirror ownership does not independently verify source freshness.',
                  'This is a partial history page, not the entire requested window.']}}

    def list_equities(self, search: str | None = None, series: str | None = None,
                       limit: int = 250, cursor: str | None = None) -> dict:
        """Provide same-symbol distinct-series catalog continuation over HTTP."""
        self.requests.append(('list_equities', dict(search=search, series=series, limit=limit, cursor=cursor)))
        rows = [r for r in CATALOG if (series is None or r['series'] == series)
                and (search is None or search.lower() in r['symbol'].lower())]
        token = opaque_cursor('list_equities', series, search, None, limit, 1)
        if cursor is not None and cursor != token:
            raise ValueError('Synthetic catalog cursor mismatch')
        selected = rows[limit:] if cursor else rows[:limit]
        more = cursor is None and len(rows) > limit
        return {'status':'ok', 'rows':selected, 'page':{'limit':limit,
                'returned_count':len(selected), 'has_more':more, 'next_cursor':token if more else None},
                'metadata':{'warnings':['Explicitly synthetic catalog.']}}


class EquityFeatureWorkflows(unittest.IsolatedAsyncioTestCase):
    """Exercise new public interfaces without downloader or transport mocks."""
    asyncSetUp = workflows.ConsumerFeatureWorkflows.asyncSetUp
    cli = workflows.ConsumerFeatureWorkflows.cli
    assert_export = workflows.ConsumerFeatureWorkflows.assert_export

    @classmethod
    def setUpClass(cls):
        """Start a real isolated HTTP equity fixture."""
        cls.fixture = SyntheticEquityServer()
        cls.fixture.start()

    @classmethod
    def tearDownClass(cls):
        """Stop and join the fixture at suite exit."""
        cls.fixture.stop()

    async def test_cli_equity_exact_csv_and_cursor(self):
        """Export all nullable OHLC/activity strings and preserve context/cursor bytes."""
        output = self.directory / 'equity.csv'
        code, stdout, stderr = await self.cli('equity', '--symbol', 'RELIANCE', '--series', 'EQ',
            '--start', '2026-10-19', '--end', '2026-10-22', '--page-size', '2', '--output', str(output))
        self.assertEqual(code, 0, stderr)
        report = json.loads(stdout)
        self.assert_export(output, report, FIELDS, ROWS, 2)
        self.assertIn('Mirror ownership does not independently verify source freshness.', report['warnings'])
        self.assertFalse(any(w.startswith('This is a partial history page,') for w in report['warnings']))
        first, second = [a for _,a in self.fixture.requests]
        self.assertEqual(second['cursor'], opaque_cursor('equity', ['RELIANCE','EQ'],
                         '2026-10-19', '2026-10-22', 2, 2))
        self.assertEqual({k:v for k,v in first.items() if k != 'cursor'},
                         {k:v for k,v in second.items() if k != 'cursor'})

    async def test_cli_equity_guards_and_quota_fail_closed(self):
        """Do not publish on identity leaks, duplicate dates, cursor loops, gaps or burst limits."""
        for symbol, message in [('WRONG_SERIES','different equity'), ('WRONG_SYMBOL','different equity'),
                ('DUPLICATE','did not increase'), ('REPEAT_CURSOR','cursor repeated'),
                ('DATA_GAP','status=ok'), ('BURST','category=burst')]:
            with self.subTest(symbol=symbol):
                self.fixture.requests.clear()
                output = self.directory / (symbol + '.csv')
                code, stdout, stderr = await self.cli('equity', '--symbol', symbol, '--series', 'EQ',
                    '--page-size', '1', '--output', str(output))
                self.assertEqual(code, 1)
                self.assertEqual(stdout, '')
                self.assertIn(message, stderr)
                self.assertFalse(output.exists())
                self.assertEqual(len(list(self.directory.glob(symbol + '.csv.*.partial'))), 1)

    async def test_cli_equity_transient_retry_preserves_exact_page(self):
        """Retry each explicit synthetic rate-limited page within existing policy bounds."""
        output = self.directory / 'rate.csv'
        code, stdout, stderr = await self.cli('equity', '--symbol', 'RATE', '--series', 'EQ',
            '--page-size', '2', '--output', str(output))
        self.assertEqual(code, 0, stderr)
        self.assert_export(output, json.loads(stdout), FIELDS, [{**r,'symbol':'RATE'} for r in ROWS], 2)
        self.assertEqual(len(self.fixture.requests), 4)
        self.assertEqual(self.fixture.requests[0], self.fixture.requests[1])
        self.assertEqual(self.fixture.requests[2], self.fixture.requests[3])

    async def test_cli_catalog_pair_pagination(self):
        """Keep BE and EQ distinct while forwarding a catalog cursor literally."""
        code, stdout, stderr = await self.cli('equities', '--search', 'rel', '--page-size', '1')
        self.assertEqual(code, 0, stderr)
        first = json.loads(stdout)
        token = first['page']['next_cursor']
        code, stdout, stderr = await self.cli('equities', '--search', 'rel', '--page-size', '1', '--cursor', token)
        self.assertEqual(code, 0, stderr)
        second = json.loads(stdout)
        self.assertEqual(first['rows'] + second['rows'], CATALOG)
        self.assertEqual(self.fixture.requests[1][1]['cursor'], token)

    async def test_stdio_equity_export_and_catalog(self):
        """Run real stdio→HTTP exports/discovery and enforce filename confinement."""
        parameters = StdioServerParameters(command=sys.executable,
            args=['-m','mcp_consumer','--config',str(self.config),'serve'], cwd=str(self.directory),
            env={'PYTHONPATH':str(ROOT), 'PYTHONDONTWRITEBYTECODE':'1'})
        with (self.directory / 'stdio.stderr').open('w') as errors:
            async with stdio_client(parameters, errlog=errors) as (read,write):
                async with ClientSession(read,write,read_timeout_seconds=timedelta(seconds=20)) as session:
                    await session.initialize()
                    result = await session.call_tool('download_equity_history',
                        {'symbol':'RELIANCE','series':'EQ','filename':'equity.csv','page_size':2})
                    self.assertFalse(result.isError)
                    report = result.structuredContent or json.loads(result.content[0].text)
                    self.assert_export(self.directory / 'exports' / 'equity.csv', report, FIELDS, ROWS, 2)
                    result = await session.call_tool('list_equities', {'search':'rel','series':'EQ','limit':2})
                    self.assertFalse(result.isError)
                    catalog = result.structuredContent or json.loads(result.content[0].text)
                    self.assertEqual(catalog['rows'], CATALOG[1:])
                    before = len(self.fixture.requests)
                    for arguments in ({'symbol':'RELIANCE','filename':'missing.csv'},
                            {'symbol':'RELIANCE','series':'EQ','filename':'../escape.csv'}):
                        result = await session.call_tool('download_equity_history', arguments)
                        self.assertTrue(result.isError)
                    self.assertEqual(len(self.fixture.requests), before)
