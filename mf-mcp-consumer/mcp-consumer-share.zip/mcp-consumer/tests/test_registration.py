"""Regress standard SDK OAuth registration and persistent cached authentication."""
import base64
import hashlib
import json
import inspect
import tempfile
import unittest
from pathlib import Path
from typing import cast
from urllib.parse import parse_qs, urlsplit

import httpx

from mcp_consumer.transport import FileTokenStorage, make_provider


class RegistrationTests(unittest.IsolatedAsyncioTestCase):
    """Use server-assigned IDs with the redirect metadata this client requested."""

    async def test_conforming_registration_completes_standard_sdk_oauth(self):
        """Fresh SDK registration preserves returned metadata without the adapter."""
        await self._exercise_sdk_registration()

    def test_registration_adapter_and_plumbing_are_absent(self):
        """Keep transport/client/server signatures free of removed arguments."""
        import mcp_consumer.transport as transport
        from mcp_consumer.client import run_download, run_equity_catalog
        from mcp_consumer.server import build_server
        self.assertFalse(hasattr(transport, 'bootstrap_stockviz_registration'))
        for function in (transport.connect, run_download, run_equity_catalog, build_server):
            with self.subTest(function=function.__name__):
                self.assertNotIn('legacy_registration', inspect.signature(function).parameters)

    async def _exercise_sdk_registration(self):
        """Replace network I/O only; retain real provider, grants and private storage."""
        url = 'https://mcp.example.com/mcp'
        origin = 'https://mcp.example.com'
        redirect_uri = 'http://127.0.0.1:54321/callback'
        state = {}
        registrations = []

        async def redirect(location):
            state.update(parse_qs(urlsplit(location).query))

        async def callback():
            return 'synthetic-code', state['state'][0]

        def response(request):
            if request.url.path == '/mcp':
                authorized = request.headers.get('authorization') == 'Bearer synthetic-token'
                return httpx.Response(200 if authorized else 401)
            if 'oauth-protected-resource' in request.url.path:
                return httpx.Response(200, json={'resource': url, 'authorization_servers': [origin],
                                                 'scopes_supported': ['research:read']})
            if 'oauth-authorization-server' in request.url.path:
                return httpx.Response(200, json={'issuer': origin,
                    'authorization_endpoint': origin + '/oauth/authorize',
                    'token_endpoint': origin + '/oauth/token',
                    'registration_endpoint': origin + '/oauth/register',
                    'response_types_supported': ['code'], 'scopes_supported': ['research:read']})
            if request.url.path == '/oauth/register':
                body = json.loads(request.content)
                registrations.append(body)
                self.assertEqual(body['redirect_uris'], [redirect_uri])
                self.assertEqual(body['scope'], 'research:read')
                self.assertEqual(body['token_endpoint_auth_method'], 'none')
                self.assertEqual(body['grant_types'], ['authorization_code', 'refresh_token'])
                self.assertEqual(body['response_types'], ['code'])
                payload = {
                    **body, 'client_id': 'server-assigned-id', 'client_id_issued_at': 1234567890}
                return httpx.Response(201, json=payload)
            if request.url.path == '/oauth/token':
                body = parse_qs(request.content.decode())
                self.assertEqual(body['client_id'], ['server-assigned-id'])
                self.assertEqual(body['redirect_uri'], [redirect_uri])
                self.assertEqual(body['grant_type'], ['authorization_code'])
                self.assertEqual(body['code'], ['synthetic-code'])
                self.assertNotIn('client_secret', body)
                challenge = base64.urlsafe_b64encode(
                    hashlib.sha256(body['code_verifier'][0].encode()).digest()).rstrip(b'=').decode()
                self.assertEqual(state['code_challenge'], [challenge])
                self.assertEqual(state['code_challenge_method'], ['S256'])
                return httpx.Response(200, json={'access_token': 'synthetic-token',
                    'refresh_token': 'synthetic-refresh', 'token_type': 'Bearer', 'scope': 'research:read'})
            return httpx.Response(404)

        with tempfile.TemporaryDirectory() as tmp:
            storage = FileTokenStorage(url, Path(tmp))
            provider = make_provider(url, storage, redirect_uri, redirect, callback)
            self.assertIsNone(await storage.get_client_info())
            async with httpx.AsyncClient(auth=cast(httpx.Auth, provider), transport=httpx.MockTransport(response)) as client:
                result = await client.get(url)
            self.assertEqual(result.status_code, 200)
            self.assertEqual(len(registrations), 1)
            self.assertEqual(state['scope'], ['research:read'])
            info = await storage.get_client_info()
            assert info is not None and info.redirect_uris is not None
            self.assertEqual(info.client_id, 'server-assigned-id')
            self.assertEqual([str(uri) for uri in info.redirect_uris], [redirect_uri])
            self.assertEqual(info.token_endpoint_auth_method, 'none')
            self.assertEqual(info.scope, 'research:read')
            self.assertEqual(info.client_id_issued_at, 1234567890)
            tokens = await storage.get_tokens()
            assert tokens is not None
            self.assertEqual(tokens.access_token, 'synthetic-token')
            original_client = (storage.directory / 'client.json').read_bytes()
            original_tokens = (storage.directory / 'tokens.json').read_bytes()
            state.clear()
            reopened = FileTokenStorage(url, Path(tmp))
            provider = make_provider(url, reopened, redirect_uri, redirect, callback)
            async with httpx.AsyncClient(auth=cast(httpx.Auth, provider), transport=httpx.MockTransport(response)) as client:
                result = await client.get(url)
            self.assertEqual(result.status_code, 200)
            self.assertEqual(len(registrations), 1)
            self.assertEqual(state, {})
            self.assertEqual((storage.directory / 'client.json').read_bytes(), original_client)
            self.assertEqual((storage.directory / 'tokens.json').read_bytes(), original_tokens)
            cached = await reopened.get_client_info()
            assert cached is not None
            self.assertEqual(cached.model_dump(), info.model_dump())


if __name__ == "__main__":
    unittest.main()
