"""Test observed legacy StockViz registration metadata without changing the server."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import httpx
from mcp.shared.auth import OAuthClientMetadata

from mcp_consumer.transport import FileTokenStorage, bootstrap_stockviz_registration


class RegistrationTests(unittest.IsolatedAsyncioTestCase):
    """Use server-assigned IDs with the redirect metadata this client requested."""

    async def test_legacy_empty_redirect_response_uses_requested_metadata(self):
        """Accept only the known Worker compatibility case; never invent an ID."""
        with tempfile.TemporaryDirectory() as tmp:
            url = "https://mcp.example.com/mcp"
            storage = FileTokenStorage(url, Path(tmp))
            metadata = OAuthClientMetadata(redirect_uris=["http://127.0.0.1:54321/callback"],
                                           scope="research:read", token_endpoint_auth_method="none")
            def response(request):
                """Return the minimal registration shape observed on the live Worker."""
                self.assertEqual(request.url.path, "/oauth/register")
                self.assertEqual(json.loads(request.content)["redirect_uris"], ["http://127.0.0.1:54321/callback"])
                return httpx.Response(201, json={"client_id":"server-assigned-id", "redirect_uris":[]})
            client = httpx.AsyncClient(transport=httpx.MockTransport(response))
            with patch("mcp_consumer.transport.httpx.AsyncClient", return_value=client):
                await bootstrap_stockviz_registration(url, storage, metadata, enabled=True)
            info = await storage.get_client_info()
            self.assertEqual(info.client_id, "server-assigned-id")
            self.assertEqual(str(info.redirect_uris[0]), "http://127.0.0.1:54321/callback")
            self.assertEqual(info.scope, "research:read")

    async def test_other_servers_use_standard_sdk_registration(self):
        """Do not reinterpret third-party OAuth registration policies."""
        with tempfile.TemporaryDirectory() as tmp:
            storage = FileTokenStorage("https://example.com/mcp", Path(tmp))
            with patch("mcp_consumer.transport.httpx.AsyncClient") as client:
                await bootstrap_stockviz_registration("https://example.com/mcp", storage,
                    OAuthClientMetadata(redirect_uris=["http://127.0.0.1:1/callback"]))
            client.assert_not_called()
            self.assertIsNone(await storage.get_client_info())


if __name__ == "__main__":
    unittest.main()
