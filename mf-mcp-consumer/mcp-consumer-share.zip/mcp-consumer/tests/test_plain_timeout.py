"""Regress safe recognition of the observed typed MariaDB timeout result."""
import unittest
from unittest.mock import AsyncMock, patch

from mcp.types import CallToolResult, TextContent

from mcp_consumer.download import DownloadError, PublicToolError, fetch_page, unpack


TIMEOUT_TEXT = 'MariaDB read unavailable (PROTOCOL_SEQUENCE_TIMEOUT)'


def raw_result(text=TIMEOUT_TEXT, failed=True):
    """Build the actual SDK error shape without a structured payload."""
    return CallToolResult(isError=failed, content=[TextContent(type='text', text=text)])


class PlainTimeoutTests(unittest.IsolatedAsyncioTestCase):
    """Keep recognized diagnostics separate from arbitrary upstream text."""

    def test_typed_timeout_maps_to_safe_query_timeout(self):
        """Recognize the exact error before attempting JSON decoding."""
        with self.assertRaises(PublicToolError) as caught:
            unpack(raw_result())
        self.assertEqual(caught.exception.code, 'query_timeout')
        self.assertEqual(caught.exception.category, 'query_timeout')
        self.assertIsNone(caught.exception.retry_after_seconds)
        self.assertIsNone(caught.exception.reset_at)
        self.assertNotIn('not valid JSON', str(caught.exception))

    def test_unrecognized_or_hostile_errors_never_echo_raw_text(self):
        """Require exact matching, suppressing injected credentials and code lookalikes."""
        for text in ('PRIVATE_SENTINEL password=synthetic-secret',
                     TIMEOUT_TEXT + ' password=synthetic-secret',
                     'password=synthetic-secret ' + TIMEOUT_TEXT,
                     TIMEOUT_TEXT + '\n', TIMEOUT_TEXT.lower(),
                     'MariaDB read unavailable (UNKNOWN_CODE)'):
            with self.subTest(text=text), self.assertRaises(DownloadError) as caught:
                unpack(raw_result(text))
            self.assertNotIsInstance(caught.exception, PublicToolError)
            self.assertNotIn(text, str(caught.exception))
            self.assertNotIn('synthetic-secret', str(caught.exception))

    def test_non_json_success_remains_invalid_json(self):
        """Do not interpret successful plain text as a typed timeout failure."""
        with self.assertRaisesRegex(DownloadError, 'not valid JSON') as caught:
            unpack(raw_result(failed=False))
        self.assertNotIsInstance(caught.exception, PublicToolError)

    def test_structured_content_takes_precedence_over_plain_text(self):
        """Preserve structured policy semantics even alongside recognized error text."""
        result = raw_result()
        result.structuredContent = {'error': {'code': 'download_rate_limited',
                                            'category': 'concurrency', 'retry_after_seconds': 0}}
        with self.assertRaises(PublicToolError) as caught:
            unpack(result)
        self.assertEqual(caught.exception.code, 'download_rate_limited')

    async def test_plain_query_timeout_is_never_retried(self):
        """Stop at the first query timeout without sleeping or consuming another page."""
        call = AsyncMock(return_value=raw_result())
        with patch('mcp_consumer.download.asyncio.sleep', new_callable=AsyncMock) as sleep:
            with self.assertRaises(PublicToolError):
                await fetch_page(call, 'get_equity_history', {'cursor': None}, 30)
        call.assert_awaited_once()
        sleep.assert_not_awaited()
