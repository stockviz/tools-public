"""Real loopback mixed-auth MCP and OAuth/PKCE transport regressions."""
import asyncio
import base64
from contextlib import redirect_stderr
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import logging
from pathlib import Path
import secrets
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlencode, urlsplit

import httpx

from mcp_consumer.cli import execute, parser
from mcp_consumer.transport import FileTokenStorage, TransportError, connect


class MixedAuthHandler(BaseHTTPRequestHandler):
    """Serve public MCP discovery and protected calls with real PKCE grants."""

    def log_message(self, format, *args):
        """Keep fixture request credentials out of test output."""

    def reply(self, status, body=None, headers=None):
        """Send a bounded JSON or empty HTTP response."""
        data = json.dumps(body).encode() if body is not None else b''
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        """Expose discovery and simulate an authorization decision, not SDK state."""
        fixture = self.server.fixture
        path = urlsplit(self.path).path
        if path.startswith('/.well-known/oauth-protected-resource'):
            self.reply(200, {'resource': fixture.url, 'authorization_servers': [fixture.origin],
                             'scopes_supported': ['research:read', 'research:admin']})
        elif path == '/.well-known/oauth-authorization-server':
            self.reply(200, {'issuer': fixture.origin, 'authorization_endpoint': fixture.origin + '/authorize',
                             'token_endpoint': fixture.origin + '/oauth/token',
                             'registration_endpoint': fixture.origin + '/register',
                             'response_types_supported': ['code'], 'grant_types_supported': ['authorization_code', 'refresh_token'],
                             'code_challenge_methods_supported': ['S256'], 'token_endpoint_auth_methods_supported': ['none']})
        elif path == '/authorize':
            query = parse_qs(urlsplit(self.path).query)
            fixture.authorizations.append(query)
            if fixture.deny:
                values = {'error': 'access_denied', 'state': query['state'][0]}
            else:
                code = secrets.token_urlsafe(32)
                fixture.codes[code] = query
                values = {'code': code, 'state': query['state'][0]}
            self.reply(302, headers={'Location': query['redirect_uri'][0] + '?' + urlencode(values)})
        else:
            self.reply(405)

    def do_DELETE(self):
        """Allow session cleanup without side effects."""
        self.reply(200)

    def do_POST(self):
        """Challenge protected calls before validating tool arguments."""
        fixture = self.server.fixture
        raw = self.rfile.read(int(self.headers.get('Content-Length', '0')))
        if self.path == '/register':
            metadata = json.loads(raw)
            fixture.registration = metadata
            self.reply(201, dict(metadata, client_id='loopback-consumer'))
            return
        if self.path in ('/oauth/token', '/token'):
            values = parse_qs(raw.decode())
            fixture.token_posts.append((self.path, values))
            if self.path != '/oauth/token':
                self.reply(404)
                return
            if values.get('grant_type') == ['authorization_code']:
                query = fixture.codes.pop(values.get('code', [''])[0], None)
                verifier = values.get('code_verifier', [''])[0]
                challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
                if not query or query['code_challenge'] != [challenge] or query['redirect_uri'] != values.get('redirect_uri'):
                    self.reply(400, {'error': 'invalid_grant'})
                    return
            elif values.get('refresh_token') != [fixture.refresh] or fixture.reject_refresh:
                self.reply(400, {'error': 'invalid_grant', 'error_description': fixture.refresh})
                return
            fixture.access = secrets.token_urlsafe(32)
            fixture.refresh = secrets.token_urlsafe(32)
            fixture.issued.extend([fixture.access, fixture.refresh])
            self.reply(200, {'access_token': fixture.access, 'refresh_token': fixture.refresh,
                             'token_type': 'Bearer', 'expires_in': 86400, 'scope': 'research:read'})
            return
        if self.path != '/mcp':
            self.reply(404)
            return
        message = json.loads(raw)
        method = message['method']
        fixture.methods.append(method)
        if method == 'tools/call':
            fixture.calls.append(message['params'])
            if not fixture.public_calls and self.headers.get('Authorization') != 'Bearer ' + fixture.access:
                fixture.challenges += 1
                self.reply(401, headers={'WWW-Authenticate': 'Bearer resource_metadata="' + fixture.origin + '/.well-known/oauth-protected-resource/mcp"'})
                return
        if 'id' not in message:
            self.reply(202)
            return
        if method == 'initialize':
            result = {'protocolVersion': '2025-06-18', 'capabilities': {'tools': {}},
                      'serverInfo': {'name': 'mixed-auth-loopback', 'version': '1'}}
        elif method == 'tools/list':
            result = {'tools': [{'name': name, 'inputSchema': {'type': 'object', 'properties': {'scheme_code': {'type': 'string'}}, 'required': ['scheme_code']}}
                                for name in ('get_nav_history', 'get_index_history')]}
        elif method == 'tools/call':
            if not message['params'].get('arguments'):
                self.reply(200, {'jsonrpc': '2.0', 'id': message['id'], 'error': {'code': -32602, 'message': 'scheme_code required'}})
                return
            result = {'content': [{'type': 'text', 'text': 'protected-success'}], 'isError': False}
        else:
            self.reply(400)
            return
        self.reply(200, {'jsonrpc': '2.0', 'id': message['id'], 'result': result})


class MixedAuthFixture:
    """Own an isolated real HTTP listener and opaque, fixture-issued credentials."""

    def __init__(self):
        """Start on a loopback port without accessing any operator cache."""
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), MixedAuthHandler)
        self.server.fixture = self
        self.origin = 'http://127.0.0.1:' + str(self.server.server_port)
        self.url = self.origin + '/mcp'
        self.codes = {}
        self.access = secrets.token_urlsafe(32)
        self.refresh = secrets.token_urlsafe(32)
        self.issued = []
        self.token_posts = []
        self.authorizations = []
        self.calls = []
        self.methods = []
        self.challenges = 0
        self.deny = False
        self.public_calls = False
        self.reject_refresh = False
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def close(self):
        """Stop and join the fixture listener."""
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()

    async def redirect(self, url):
        """Follow the SDK-generated authorization URL through a real callback."""
        async with httpx.AsyncClient(follow_redirects=True) as client:
            response = await client.get(url)
            response.raise_for_status()


class MixedAuthTests(unittest.IsolatedAsyncioTestCase):
    """Exercise SDK sessions, HTTP challenges, PKCE, persistence and rotation."""

    async def asyncSetUp(self):
        """Create a private temporary consumer cache and local OAuth server."""
        self.fixture = MixedAuthFixture()
        self.temporary = tempfile.TemporaryDirectory()
        self.state = Path(self.temporary.name)
        self.args = parser().parse_args(['--url', self.fixture.url, '--state-dir', str(self.state), 'login'])

    async def asyncTearDown(self):
        """Remove only fixture resources and never inspect the real cache."""
        await asyncio.to_thread(self.fixture.close)
        self.temporary.cleanup()

    async def login(self):
        """Replace only browser interaction, leaving SDK and transport real."""
        with patch('mcp_consumer.transport.interactive_redirect', self.fixture.redirect):
            return await execute(self.args)

    def token_payload(self):
        """Read only this test's private token document."""
        storage = FileTokenStorage(self.fixture.url, self.state)
        return json.loads((storage.directory / 'tokens.json').read_text())

    def expire(self):
        """Age the fixture cache to exercise refresh on a new connection."""
        storage = FileTokenStorage(self.fixture.url, self.state)
        path = storage.directory / 'tokens.json'
        payload = json.loads(path.read_text())
        payload['_expires_at'] = time.time() - 60
        path.write_text(json.dumps(payload))

    async def protected_call(self):
        """Perform a real noninteractive protected SDK request."""
        async with connect(self.fixture.url, self.state) as session:
            return await session.call_tool('get_nav_history', {'scheme_code': 'fixture'})

    async def test_fresh_login_challenges_and_persists_real_pkce_token(self):
        """Public discovery cannot authenticate; an empty protected probe must."""
        result = await self.login()
        self.assertEqual(result['status'], 'authenticated')
        self.assertEqual(self.fixture.challenges, 1)
        self.assertEqual(self.fixture.calls, [{'name': 'get_nav_history', 'arguments': {}}] * 2)
        payload = self.token_payload()
        self.assertEqual(payload['access_token'], self.fixture.access)
        self.assertEqual(payload['refresh_token'], self.fixture.refresh)
        self.assertGreater(payload['_expires_at'], time.time())
        self.assertEqual(self.fixture.registration['scope'], 'research:read')
        self.assertEqual(self.fixture.authorizations[0]['scope'], ['research:read'])
        self.assertEqual(len(self.fixture.token_posts), 1)

    async def test_denied_authorization_never_reports_authenticated(self):
        """An OAuth denial fails instead of accepting the public tool catalog."""
        self.fixture.deny = True
        with self.assertRaises(TransportError):
            await self.login()
        self.assertEqual(self.fixture.token_posts, [])

    async def test_public_probe_without_token_is_not_authenticated(self):
        """A mistakenly unprotected tool cannot prove a persisted identity."""
        self.fixture.public_calls = True
        with self.assertRaises(TransportError):
            await self.login()

    async def test_expired_reload_refreshes_rotates_and_second_process_reuses(self):
        """Discover the true token endpoint and retain replacement expiry on disk."""
        await self.login()
        self.assertEqual(self.fixture.challenges, 1)
        old = self.token_payload()
        self.expire()
        result = await self.protected_call()
        self.assertFalse(result.isError)
        current = self.token_payload()
        self.assertNotEqual(current['refresh_token'], old['refresh_token'])
        self.assertEqual(current['refresh_token'], self.fixture.refresh)
        self.assertGreater(current['_expires_at'], time.time() + 86000)
        self.assertEqual(self.fixture.token_posts[-1][0], '/oauth/token')
        self.assertEqual(self.fixture.token_posts[-1][1]['refresh_token'], [old['refresh_token']])
        process = await asyncio.create_subprocess_exec(sys.executable, '-m', 'mcp_consumer', '--url', self.fixture.url,
            '--state-dir', str(self.state), 'login', stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await asyncio.wait_for(process.communicate(), 15)
        self.assertEqual(process.returncode, 0, stderr.decode())
        self.assertEqual(json.loads(stdout)['status'], 'authenticated')
        self.assertEqual(len(self.fixture.token_posts), 2)
        self.assertEqual(self.token_payload(), current)

    async def test_invalid_refresh_requires_login_without_blind_rotation_retries(self):
        """Do not POST a rejected refresh credential again after cache reload."""
        await self.login()
        self.assertEqual(self.fixture.challenges, 1)
        self.expire()
        self.fixture.reject_refresh = True
        for attempt in range(2):
            with self.assertRaises(TransportError):
                await self.protected_call()
        refresh_posts = [entry for entry in self.fixture.token_posts if entry[1].get('grant_type') == ['refresh_token']]
        self.assertEqual(len(refresh_posts), 1)
        self.assertEqual(refresh_posts[0][0], '/oauth/token')

    async def test_raw_tokens_never_reach_transport_logs_or_errors(self):
        """Capture real OAuth and refresh diagnostics, including hostile grant errors."""
        output = io.StringIO()
        handler = logging.StreamHandler(output)
        root = logging.getLogger()
        previous = root.level
        root.setLevel(logging.DEBUG)
        root.addHandler(handler)
        try:
            with redirect_stderr(output):
                await self.login()
                self.assertEqual(self.fixture.challenges, 1)
                self.expire()
                self.fixture.reject_refresh = True
                with self.assertRaises(TransportError) as caught:
                    await self.protected_call()
            text = output.getvalue() + str(caught.exception)
            for token in self.fixture.issued:
                self.assertNotIn(token, text)
        finally:
            root.removeHandler(handler)
            root.setLevel(previous)
