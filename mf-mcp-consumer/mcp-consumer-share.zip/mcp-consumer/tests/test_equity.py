"""Regress raw equity identity, safe pagination, CSV fields and discovery."""
import csv
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, AsyncMock

from mcp_consumer.cli import parser
from mcp_consumer.catalog import equity_catalog, validate_catalog
from mcp_consumer.download import DownloadError, download, validate_request
from mcp_consumer.server import build_server
from test_download import Pages, page


FIELDS = ['symbol', 'series', 'date', 'open', 'high', 'low', 'close', 'last',
          'previous_close', 'total_traded_quantity', 'total_traded_value', 'num_transactions']


def equity(day='2026-10-19'):
    """Create synthetic nullable database-text equity observations."""
    return dict(zip(FIELDS, ['RELIANCE', 'EQ', day, None, '1.2e3', '1100', '1202',
                            '1201.5', '1190', '123456', '1.23e8', '100']))


class EquityTests(unittest.IsolatedAsyncioTestCase):
    """Require both identity components and fail closed on corrupt history."""

    async def test_export_exact_fields_and_opaque_cursor(self):
        """Keep nulls, database text and literal cursor bytes over two pages."""
        token = '  opaque/+/=☃  '
        rows = [equity(), equity('2026-10-21'), equity('2026-10-22')]
        client = Pages([page(rows[:2], token), page(rows[2:])])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / 'equity.csv'
            result = await download(client, 'get_equity_history',
                                    dict(symbol='RELIANCE', series='EQ', limit=2), output)
            self.assertEqual(result['row_count'], 3)
            self.assertEqual(client.calls[1][1]['cursor'], token)
            with output.open(newline='') as handle:
                reader = csv.DictReader(handle)
                self.assertEqual(reader.fieldnames, FIELDS)
                self.assertEqual(list(reader), [{k: '' if v is None else v for k, v in r.items()} for r in rows])

    async def test_native_integer_transaction_count(self):
        """Accept the native SQL int count without allowing floats or booleans."""
        with tempfile.TemporaryDirectory() as tmp:
            for count in (0, 100, 2147483647, -2147483648, None):
                output = Path(tmp) / f'count-{count}.csv'
                await download(Pages([page([dict(equity(), num_transactions=count)])]),
                               'get_equity_history', dict(symbol='RELIANCE', series='EQ', limit=2), output)
                with output.open(newline='') as handle:
                    self.assertEqual(next(csv.DictReader(handle))['num_transactions'],
                                     '' if count is None else str(count))
            for index, count in enumerate((True, False, 100.0, 2147483648, -2147483649)):
                output = Path(tmp) / f'invalid-{index}.csv'
                with self.subTest(count=count), self.assertRaises(DownloadError):
                    await download(Pages([page([dict(equity(), num_transactions=count)])]),
                                   'get_equity_history', dict(symbol='RELIANCE', series='EQ', limit=2), output)
                self.assertFalse(output.exists())

    def test_request_requires_exact_bounded_pair(self):
        """Reject missing, malformed and overlength identities before any IO."""
        for args in ({'symbol': 'RELIANCE'}, {'symbol': 'RELIANCE', 'series': None},
                     {'symbol': 'RELIANCE', 'series': ''}, {'symbol': 'x\n', 'series': 'EQ'},
                     {'symbol': '☃' * 257, 'series': 'EQ'}, {'symbol': '😀' * 129, 'series': 'EQ'}):
            with self.subTest(args=args), self.assertRaises(DownloadError):
                validate_request('get_equity_history', args)

    async def test_corrupt_equity_never_publishes(self):
        """Reject wrong tuple members, extra/missing fields, floats and duplicate dates."""
        bad = [page([dict(equity(), symbol='OTHER')]), page([dict(equity(), series='BE')]),
               page([dict(equity(), close=1202.0)]), page([dict(equity(), extra='x')]),
               page([{k:v for k,v in equity().items() if k != 'last'}]),
               page([equity(), equity()]), dict(page([]), status='data_gap')]
        with tempfile.TemporaryDirectory() as tmp:
            for i, value in enumerate(bad):
                output = Path(tmp) / f'{i}.csv'
                with self.subTest(i=i), self.assertRaises(DownloadError):
                    await download(Pages([value]), 'get_equity_history',
                                   dict(symbol='RELIANCE', series='EQ', limit=2), output)
                self.assertFalse(output.exists())

    def test_cli_equity_and_catalog(self):
        """Expose explicit pair exports and bounded catalog filters."""
        self.assertEqual(parser().parse_args(['equity', '--symbol', 'RELIANCE', '--series', 'EQ',
                                             '--output', 'equity.csv']).series, 'EQ')
        self.assertEqual(parser().parse_args(['equities', '--search', 'REL', '--series', 'EQ',
                                             '--page-size', '2']).search, 'REL')

    async def test_stdio_equity_wrapper(self):
        """Use the same downloader and metadata-only boundary for equity exports."""
        server = build_server('https://example.test/mcp', Path('state'), Path('exports'))
        names = {t.name for t in await server.list_tools()}
        self.assertTrue({'download_equity_history', 'list_equities'}.issubset(names))
        with patch('mcp_consumer.server.run_download', new=AsyncMock(return_value={'status':'complete'})) as run:
            await server.call_tool('download_equity_history',
                                   {'symbol':'RELIANCE', 'series':'EQ', 'filename':'equity.csv'})
            self.assertEqual(run.await_args.args[2], 'get_equity_history')
            self.assertEqual(run.await_args.args[3]['series'], 'EQ')

    async def test_catalog_validation_and_retry(self):
        """Keep bounded exact catalog filters and reuse safe transient retries."""
        token = '  exact/catalog+/=☃  '
        row = dict(symbol='RELIANCE', series='EQ', first_date='2026-10-19',
                   last_date='2026-10-22', observations=3)
        response = page([row], token)
        calls = Pages([{'error':{'code':'download_rate_limited', 'category':'page_rate',
                                'retry_after_seconds':0}}, response])
        result = await equity_catalog(calls, dict(search='rel', series='EQ', limit=2))
        self.assertEqual(result['page']['next_cursor'], token)
        self.assertEqual(calls.calls[0], calls.calls[1])
        for bad in (dict(row, series='BE'), dict(row, first_date='bad'),
                    dict(row, observations=True), dict(row, observations='0'),
                    dict(row, symbol='OTHER'), dict(row, extra=1)):
            with self.subTest(row=bad), self.assertRaises(DownloadError):
                await equity_catalog(Pages([page([bad])]), dict(search='rel', series='EQ', limit=2))
        with self.assertRaises(DownloadError):
            await equity_catalog(Pages([page([row,row])]), dict(limit=2))
        with self.assertRaises(DownloadError):
            await equity_catalog(Pages([response]), dict(limit=2, cursor=token))

    def test_catalog_request_rejected_before_io(self):
        """Reject unsupported fields and invalid identifiers, sizes and cursors."""
        for args in ({'limit':True}, {'limit':1001}, {'cursor':''}, {'cursor':2},
                     {'cursor':'x'*4097}, {'search':''}, {'series':'EQ\n'}, {'symbol':'REL'}):
            with self.subTest(args=args), self.assertRaises(DownloadError):
                validate_catalog(args)
