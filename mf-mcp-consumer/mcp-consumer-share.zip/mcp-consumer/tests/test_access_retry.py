"""Regress policy validation, bounded retries, and whole-export execution slots."""
import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import httpx

from mcp_consumer.download import (DownloadError, PublicToolError, download, fetch_page,
                                   http_rate_error, public_error, unpack)
from mcp_consumer.server import build_server
from test_download import Pages, nav, page


def policy(category="concurrency", delay=1, code="download_rate_limited", **fields):
    """Build untrusted public metadata without any real upstream credentials."""
    return {"error": dict(code=code, category=category, retry_after_seconds=delay, **fields)}


def result(value, structured=True):
    """Represent either supported SDK result encoding."""
    return SimpleNamespace(isError=True, structuredContent=value if structured else None,
                           content=[SimpleNamespace(type="text", text=json.dumps(value))])


class PolicyValidationTests(unittest.TestCase):
    """Require recognized nested metadata and sanitized diagnostics."""

    def test_nested_errors_in_both_sdk_encodings(self):
        """Expose only validated policy fields, not arbitrary upstream text."""
        for structured in (True, False):
            with self.subTest(structured=structured), self.assertRaises(PublicToolError) as caught:
                unpack(result(policy(message="UNTRUSTED-MESSAGE"), structured))
            self.assertEqual(caught.exception.category, "concurrency")
            self.assertNotIn("UNTRUSTED-MESSAGE", str(caught.exception))
        for value in ({"code": "download_rate_limited"}, {"error": "bad"}, policy(code="other")):
            self.assertIsNone(public_error(value))

    def test_known_categories_are_preserved_unknown_fails_closed(self):
        """Keep current Worker category names without accepting arbitrary strings."""
        categories = "concurrency global_concurrency page_rate request_rate policy_unavailable query_timeout burst distinct_instruments state_capacity page_size response_bound daily day_rate daily_rows daily_bytes daily_pages daily_requests daily_exports row_budget byte_budget rows bytes requests pages exports timeout".split()
        for category in categories:
            self.assertEqual(public_error(policy(category)).category, category)
        for category in (None, [], "new_category", "concurrency\n"):
            self.assertEqual(public_error(policy(category)).category, "unknown")

    def test_delay_and_reset_metadata_validation(self):
        """Reject booleans, nonfinite waits, and unzoned or injected reset strings."""
        for delay in (True, -1, "1", float("inf"), float("nan"), 10 ** 400):
            self.assertIsNone(public_error(policy(delay=delay)).retry_after_seconds)
        for reset in (True, -1, "2027-01-01", "2027-01-01T00:00:00", "2027-01-01T00:00:00Z\n", "x" * 65):
            self.assertIsNone(public_error(policy(reset_at=reset)).reset_at)
        self.assertEqual(public_error(policy(reset_at="2027-01-01T00:00:00Z")).reset_at,
                         "2027-01-01T00:00:00Z")

    def test_http_retry_after_seconds_dates_and_invalid_values(self):
        """Read Retry-After only and validate both standardized representations."""
        for header, expected in (("2", 2), ("Thu, 01 Jan 1970 00:16:45 GMT", 5),
                                 ("Thu, 01 Jan 1970 00:00:00 GMT", 0),
                                 ("1.5", None), ("-1", None), ("NaN", None),
                                 ("9" * 13, None), ("bad", None),
                                 ("Thu, 01 Jan 1970 00:16:45", None)):
            response = httpx.Response(429, headers={"Retry-After": header},
                                      request=httpx.Request("GET", "https://example.invalid/"))
            error = httpx.HTTPStatusError("untrusted", request=response.request, response=response)
            with self.subTest(header=header), patch("mcp_consumer.download.time.time", return_value=1000):
                self.assertEqual(http_rate_error(error).retry_after_seconds, expected)


class RetryTests(unittest.IsolatedAsyncioTestCase):
    """Exercise actual retry control flow while replacing only elapsed waits."""

    async def test_short_transient_categories_retry_exact_arguments(self):
        """Retry only declared short transient categories with the unchanged opaque cursor."""
        for category in ("concurrency", "global_concurrency", "page_rate", "request_rate", "policy_unavailable"):
            code = "policy_unavailable" if category == "policy_unavailable" else "download_rate_limited"
            calls = Pages([policy(category, 1, code), page([])])
            args = {"cursor": '  opaque/+/=☃  ', "limit": 2}
            with self.subTest(category=category), patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock) as sleep:
                value, remaining = await fetch_page(calls, "get_nav_history", args, 30)
            self.assertEqual(value["status"], "ok")
            self.assertEqual(calls.calls, [("get_nav_history", args)] * 2)
            sleep.assert_awaited_once_with(1)
            self.assertLessEqual(remaining, 29)

    async def test_maximum_three_attempts_even_for_zero_delay(self):
        """Bound attempts independently of the aggregate wait budget."""
        calls = Pages([policy(delay=0)] * 4)
        with patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock) as sleep:
            with self.assertRaises(PublicToolError):
                await fetch_page(calls, "get_nav_history", {}, 30)
        self.assertEqual(len(calls.calls), 3)
        self.assertEqual(sleep.await_count, 2)

    async def test_nontransient_or_long_wait_never_loops(self):
        """Reject burst/daily/query-timeout and unavailable or oversized retry hints immediately."""
        failures = [policy(category, 0) for category in
                    ("burst", "daily", "daily_rows", "daily_bytes", "daily_pages", "daily_requests",
                     "daily_exports", "state_capacity", "unknown", "query_timeout")]
        failures += [policy(delay=31), policy(delay=None), policy(delay=True),
                     policy("query_timeout", 0, "query_timeout")]
        for failure in failures:
            calls = Pages([failure, page([])])
            with self.subTest(failure=failure), patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock) as sleep:
                with self.assertRaises(PublicToolError):
                    await fetch_page(calls, "get_nav_history", {}, 30)
                sleep.assert_not_awaited()
            self.assertEqual(len(calls.calls), 1)

    async def test_later_reset_cannot_be_bypassed_by_short_hint(self):
        """Honor a future reset even when retry_after_seconds advertises a shorter wait."""
        calls = Pages([policy(delay=1, reset_at=1031)])
        with patch("mcp_consumer.download.time.time", return_value=1000), self.assertRaises(PublicToolError):
            await fetch_page(calls, "get_nav_history", {}, 30)
        self.assertEqual(len(calls.calls), 1)

    async def test_wait_budget_is_aggregate_across_pages(self):
        """Do not replenish the 30-second retry budget on each new page."""
        calls = Pages([policy(delay=20), page([nav()], "opaque"), policy(delay=11), page([])])
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "out.csv"
            with patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock) as sleep:
                with self.assertRaises(DownloadError):
                    await download(calls, "get_nav_history", {"scheme_code": "105758", "limit": 2}, output)
            sleep.assert_awaited_once_with(20)
            self.assertFalse(output.exists())
            self.assertEqual(len(list(output.parent.glob("*.partial"))), 1)
        self.assertEqual(len(calls.calls), 3)

    async def test_actual_sleep_overrun_is_charged(self):
        """Charge scheduler delay rather than only the advertised sleep duration."""
        calls = Pages([policy(delay=1), page([])])
        with patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock), patch(
                "mcp_consumer.download.time.monotonic", side_effect=[100, 105]):
            _, remaining = await fetch_page(calls, "get_nav_history", {}, 30)
        self.assertEqual(remaining, 25)

    async def test_http_429_retries_but_other_http_status_does_not(self):
        """Apply bounded Retry-After handling exclusively to HTTP 429."""
        for status in (429, 503):
            response = httpx.Response(status, headers={"Retry-After": "0"},
                                      request=httpx.Request("GET", "https://example.invalid/"))
            error = httpx.HTTPStatusError("untrusted", request=response.request, response=response)
            calls = Pages([error, page([])])
            with patch("mcp_consumer.download.asyncio.sleep", new_callable=AsyncMock):
                if status == 429:
                    await fetch_page(calls, "get_nav_history", {}, 30)
                    self.assertEqual(len(calls.calls), 2)
                else:
                    with self.assertRaises(httpx.HTTPStatusError):
                        await fetch_page(calls, "get_nav_history", {}, 30)
                    self.assertEqual(len(calls.calls), 1)

    async def test_cancelled_error_propagates_during_retry(self):
        """Do not convert cancellation into another retry or a public tool failure."""
        calls = Pages([policy(), page([])])
        with patch("mcp_consumer.download.asyncio.sleep", side_effect=asyncio.CancelledError):
            with self.assertRaises(asyncio.CancelledError):
                await fetch_page(calls, "get_nav_history", {}, 30)
        self.assertEqual(len(calls.calls), 1)

    async def test_cancellation_retains_partial_and_never_publishes(self):
        """Leave already verified bytes explicitly partial on task cancellation."""
        calls = AsyncMock(side_effect=[SimpleNamespace(isError=False, structuredContent=page([nav()], "next")),
                                      asyncio.CancelledError()])
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "out.csv"
            with self.assertRaises(asyncio.CancelledError):
                await download(calls, "get_nav_history", {"scheme_code": "105758", "limit": 2}, output)
            self.assertFalse(output.exists())
            partials = list(output.parent.glob("*.partial"))
            self.assertEqual(len(partials), 1)
            self.assertIn("123.45000000000001", partials[0].read_text())

    async def test_stdio_tools_share_two_whole_export_slots_and_release_on_cancel(self):
        """Queue all three history types behind two exports and recover cancelled slots."""
        entered = []
        release = asyncio.Event()

        async def blocked(*args, **kwargs):
            """Hold a whole export open without mocking the semaphore under test."""
            entered.append(args[2])
            await release.wait()
            return {"status": "complete"}

        with patch("mcp_consumer.server.run_download", side_effect=blocked):
            server = build_server("https://example.invalid", Path("state"), Path("exports"))
            tasks = [asyncio.create_task(server.call_tool(name, arguments)) for name, arguments in [
                ("download_nav_history", {"scheme_code": "1", "filename": "a.csv"}),
                ("download_index_history", {"index_name": "INDEX", "filename": "b.csv"}),
                ("download_equity_history", {"symbol": "RELIANCE", "series": "EQ", "filename": "c.csv"})]]
            try:
                for _ in range(20):
                    await asyncio.sleep(0)
                self.assertEqual(entered, ["get_nav_history", "get_index_history"])
                tasks[0].cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await tasks[0]
                for _ in range(20):
                    await asyncio.sleep(0)
                self.assertEqual(len(entered), 3)
                self.assertEqual(entered[-1], "get_equity_history")
            finally:
                release.set()
                await asyncio.gather(*tasks, return_exceptions=True)


if __name__ == "__main__":
    unittest.main()
