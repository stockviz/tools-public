"""Guard complete dashboard export counts and exact UTF-16 request bounds."""
import tempfile
import unittest
from pathlib import Path

from mcp_consumer import dashboard
from mcp_consumer.download import DownloadError
from test_dashboard import Remote, page, row


class DashboardIntegrityTests(unittest.IsolatedAsyncioTestCase):
    """Reject silent unfiltered truncation while allowing valid filtered subsets."""

    async def test_full_table_requires_published_row_count(self):
        """A terminal page is insufficient when fewer rows than the catalog were returned."""
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'full.csv'
            with self.assertRaises(DownloadError):
                await dashboard.download_dashboard(Remote(page([row()])), {'dataset_name': 'DASHBOARD_SAMPLE'}, output)
            self.assertFalse(output.exists())

    async def test_filtered_subset_does_not_require_whole_table_count(self):
        """Filtered exports use terminal paging because catalog counts cover the entire table."""
        with tempfile.TemporaryDirectory() as directory:
            result = await dashboard.download_dashboard(Remote(page([row()])), {'dataset_name': 'DASHBOARD_SAMPLE', 'entity_column': 'ROW_ID', 'entity': '1'}, Path(directory)/'filtered.csv')
            self.assertEqual(result['row_count'], 1)

    async def test_text_limits_match_server_utf16_units(self):
        """Astral characters consume two units without normalizing their literal value."""
        self.assertEqual(dashboard.validate_dashboard_catalog({'search': '\U0001f600'*128})['search'], '\U0001f600'*128)
        with self.assertRaises(DownloadError):
            dashboard.validate_dashboard_catalog({'search': '\U0001f600'*129})
