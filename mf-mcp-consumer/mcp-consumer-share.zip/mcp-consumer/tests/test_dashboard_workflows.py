"""Exercise dashboard subprocesses against synthetic loopback MCP publications.

No production service, credentials, transport, downloader, or writer is mocked.
"""
import csv
import hashlib
import io
import json
import sys
import unittest
from contextlib import asynccontextmanager
from datetime import timedelta

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.server.fastmcp import FastMCP
from mcp.types import CallToolResult, TextContent

from tests import test_feature_workflows as workflows
from tests.test_feature_workflows import FIXTURE_TOKEN, ROOT, SyntheticHistoryServer, opaque_cursor


DATASET = 'DASHBOARD_SYNTHETIC_PUBLIC'
ENTITY = 'Synthetic "Quoted", Entity'
SCHEMA = [['ROW_ID', 'BIGINT'], ['ENTITY', 'VARCHAR(255)'], ['AS_OF', 'DATE'],
          ['VALUE', 'DOUBLE'], ['NOTE', 'LONGTEXT']]
COLUMNS = [column for column, _ in SCHEMA]
ROWS = [
    {'ROW_ID': '9007199254740993', 'ENTITY': ENTITY, 'AS_OF': '2021-01-04',
     'VALUE': '100.000000000000000001', 'NOTE': 'comma, quote " and\nnewline'},
    {'ROW_ID': '9007199254740994', 'ENTITY': ENTITY, 'AS_OF': '2021-01-05',
     'VALUE': None, 'NOTE': None},
    {'ROW_ID': '9223372036854775807', 'ENTITY': ENTITY, 'AS_OF': '2021-01-06',
     'VALUE': '-0.000000000000000001', 'NOTE': 'Unicode ☃'},
]
FILTERS = {'entity_column': 'ENTITY', 'entity': ENTITY, 'date_column': 'AS_OF',
           'start': '2021-01-04', 'end': '2021-01-06'}
CLI_FILTERS = ['--entity-column', 'ENTITY', '--entity', ENTITY, '--date-column', 'AS_OF',
               '--start', '2021-01-04', '--end', '2021-01-06']


def publication(name=DATASET, changed=False):
    """Build the real catalog metadata shape using only synthetic values."""
    return {'dataset_name': name, 'row_count': str(len(ROWS)),
            'schema': SCHEMA, 'metadata': {'source': 'synthetic loopback fixture'},
            'refreshed_at': '2021-01-07 00:00:00.000002' if changed else '2021-01-07 00:00:00.000001',
            'content_digest': ('b' if changed else 'a') * 64}


class SyntheticDashboardServer(SyntheticHistoryServer):
    """Reuse authenticated uvicorn lifecycle without registering history handlers."""

    def __init__(self):
        """Register public discovery/query tools on a real stateless HTTP server."""
        self.requests = []
        self.mode = 'ok'
        self.server = FastMCP('Synthetic dashboard fixture', stateless_http=True,
                              json_response=True, log_level='CRITICAL')
        self.server.add_tool(self.list_dashboard_datasets)
        self.server.add_tool(self.query_dashboard_dataset)

    def list_dashboard_datasets(self, search: str | None = None, limit: int = 100,
                                cursor: str | None = None) -> dict:
        """Serve bounded catalog pages with exact opaque continuation context."""
        self.requests.append(('list_dashboard_datasets', dict(search=search, limit=limit, cursor=cursor)))
        names = [DATASET, 'DASHBOARD_SYNTHETIC_SECOND']
        rows = [publication(name) for name in names if search is None or search.lower() in name.lower()]
        token = opaque_cursor('list_dashboard_datasets', search, None, None, limit, limit)
        if cursor is not None and cursor != token:
            raise ValueError('Synthetic catalog cursor mismatch')
        offset = limit if cursor else 0
        selected = rows[offset:offset + limit]
        more = offset + len(selected) < len(rows)
        return {'status': 'ok', 'rows': selected, 'page': {
            'limit': limit, 'returned_count': len(selected), 'has_more': more,
            'next_cursor': token if more else None}}

    def query_dashboard_dataset(self, dataset_name: str, entity_column: str | None = None,
                                entity: str | None = None, date_column: str | None = None,
                                start: str | None = None, end: str | None = None,
                                limit: int = 100, cursor: str | None = None) -> dict:
        """Return precision-safe pages or explicit controlled publication failures."""
        arguments = dict(dataset_name=dataset_name, entity_column=entity_column, entity=entity,
                         date_column=date_column, start=start, end=end, limit=limit, cursor=cursor)
        self.requests.append(('query_dashboard_dataset', arguments))
        empty = {'limit': limit, 'returned_count': 0, 'has_more': False, 'next_cursor': None}
        if dataset_name != DATASET or self.mode == 'data_gap':
            return {'status': 'data_gap', 'rows': [], 'page': empty,
                    'reason': 'Synthetic publication unavailable'}
        if self.mode == 'error':
            return CallToolResult(isError=True, content=[TextContent(
                type='text', text='Synthetic upstream failure password=PRIVATE_SENTINEL')])
        rows = [dict(row) for row in ROWS
                if (entity is None or (entity_column == 'ENTITY' and entity.lower() in row['ENTITY'].lower()))
                and (start is None or row['AS_OF'] >= start)
                and (end is None or row['AS_OF'] <= end)]
        context = json.dumps([dataset_name, entity_column, entity, date_column], ensure_ascii=False)
        offset = 0
        if cursor is not None:
            offsets = [value for value in range(limit, len(rows), limit)
                       if cursor == opaque_cursor('query_dashboard_dataset', context, start, end, limit, value)]
            if not offsets:
                raise ValueError('Synthetic query cursor mismatch')
            offset = offsets[0]
        selected = rows[offset:offset + limit]
        more = offset + len(selected) < len(rows)
        token = opaque_cursor('query_dashboard_dataset', context, start, end, limit,
                              offset + len(selected)) if more else None
        return {'status': 'ok', 'dataset_name': dataset_name, 'rows': selected,
                'metadata': publication(changed=self.mode == 'generation' and bool(offset)),
                'page': {'limit': limit, 'returned_count': len(selected),
                         'has_more': more, 'next_cursor': token},
                'warnings': ['Explicitly synthetic loopback fixture.']}


class DashboardWorkflows(unittest.IsolatedAsyncioTestCase):
    """Drive actual CLI and local SDK stdio subprocesses through HTTP and CSV."""

    asyncSetUp = workflows.ConsumerFeatureWorkflows.asyncSetUp
    cli = workflows.ConsumerFeatureWorkflows.cli

    @classmethod
    def setUpClass(cls):
        """Start the synthetic authenticated loopback fixture."""
        cls.fixture = SyntheticDashboardServer()
        cls.fixture.start()

    @classmethod
    def tearDownClass(cls):
        """Join the fixture thread and close its socket."""
        cls.fixture.stop()

    async def asyncTearDown(self):
        """Reset explicit fault scenarios between tests."""
        self.fixture.mode = 'ok'

    @asynccontextmanager
    async def session(self):
        """Open the real local MCP extension in a separate Python process."""
        parameters = StdioServerParameters(command=sys.executable,
            args=['-m', 'mcp_consumer', '--config', str(self.config), 'serve'],
            cwd=str(self.directory), env={'PYTHONPATH': str(ROOT), 'PYTHONDONTWRITEBYTECODE': '1'})
        with (self.directory / 'stdio.stderr').open('w+') as errors:
            async with stdio_client(parameters, errlog=errors) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=20)) as session:
                    await session.initialize()
                    yield session
            errors.seek(0)
            self.assertNotIn(FIXTURE_TOKEN, errors.read())

    def payload(self, response):
        """Decode successful SDK tool data without assuming a text-only SDK version."""
        self.assertFalse(response.isError, response.content)
        return response.structuredContent or json.loads(response.content[0].text)

    def assert_csv(self, output, metadata):
        """Check independently serialized exact bytes, hash, and metadata-only completion."""
        expected = io.StringIO(newline='')
        writer = csv.DictWriter(expected, fieldnames=COLUMNS, lineterminator='\r\n')
        writer.writeheader()
        writer.writerows(ROWS)
        expected_bytes = expected.getvalue().encode('utf-8')
        self.assertEqual(output.read_bytes(), expected_bytes)
        self.assertEqual(metadata['status'], 'complete')
        self.assertEqual(metadata['row_count'], len(ROWS))
        self.assertEqual(metadata['page_count'], 2)
        self.assertEqual(metadata['sha256'], hashlib.sha256(expected_bytes).hexdigest())
        self.assertNotIn('rows', metadata)
        self.assertNotIn('cursor', json.dumps(metadata))
        self.assertFalse(list(output.parent.glob(output.name + '.*.partial')))

    async def test_cli_catalog_is_bounded_and_preserves_cursor(self):
        """Discover one catalog page at a time, including the default limit of 100."""
        code, stdout, stderr = await self.cli('dashboard-datasets', '--search', 'SYNTHETIC', '--page-size', '1')
        self.assertEqual(code, 0, stderr)
        first = json.loads(stdout)
        self.assertEqual(first['rows'], [publication()])
        self.assertTrue(first['page']['has_more'])
        token = first['page']['next_cursor']
        code, stdout, stderr = await self.cli('dashboard-datasets', '--search', 'SYNTHETIC',
                                             '--page-size', '1', '--cursor', token)
        self.assertEqual(code, 0, stderr)
        self.assertEqual(json.loads(stdout)['rows'], [publication('DASHBOARD_SYNTHETIC_SECOND')])
        self.assertEqual(self.fixture.requests[-1][1]['cursor'], token)
        code, _, stderr = await self.cli('dashboard-datasets')
        self.assertEqual(code, 0, stderr)
        self.assertEqual(self.fixture.requests[-1][1]['limit'], 100)
        self.assertFalse((self.directory / 'exports').exists())

    async def test_cli_query_is_bounded_and_preserves_filters(self):
        """Forward precision-safe rows and opaque tokens without silently fetching more."""
        arguments = ['dashboard-query', '--dataset-name', DATASET, '--page-size', '2', *CLI_FILTERS]
        code, stdout, stderr = await self.cli(*arguments)
        self.assertEqual(code, 0, stderr)
        first = json.loads(stdout)
        self.assertEqual(first['rows'], ROWS[:2])
        self.assertEqual(len(self.fixture.requests), 1)
        token = first['page']['next_cursor']
        code, stdout, stderr = await self.cli(*arguments, '--cursor', token)
        self.assertEqual(code, 0, stderr)
        self.assertEqual(json.loads(stdout)['rows'], ROWS[2:])
        self.assertEqual(self.fixture.requests[-1][1],
                         dict(dataset_name=DATASET, **FILTERS, limit=2, cursor=token))
        self.assertFalse((self.directory / 'exports').exists())

    async def test_cli_and_stdio_complete_csv_match_independent_bytes(self):
        """Complete both user paths without exposing rows or continuation in results."""
        cli_output = self.directory / 'cli.csv'
        code, stdout, stderr = await self.cli('dashboard', '--dataset-name', DATASET,
            '--page-size', '2', *CLI_FILTERS, '--output', str(cli_output))
        self.assertEqual(code, 0, stderr)
        self.assert_csv(cli_output, json.loads(stdout))
        async with self.session() as session:
            tools = {tool.name: tool for tool in (await session.list_tools()).tools}
            self.assertTrue(tools['list_dashboard_datasets'].annotations.readOnlyHint)
            self.assertTrue(tools['query_dashboard_dataset'].annotations.readOnlyHint)
            self.assertFalse(tools['download_dashboard_dataset'].annotations.readOnlyHint)
            self.assertNotIn('cursor', tools['download_dashboard_dataset'].inputSchema['properties'])
            result = await session.call_tool('download_dashboard_dataset',
                dict(dataset_name=DATASET, filename='stdio.csv', **FILTERS, page_size=2, max_pages=10))
            self.assert_csv(self.directory / 'exports' / 'stdio.csv', self.payload(result))
        self.assertEqual(len([tool for tool, _ in self.fixture.requests if tool == 'query_dashboard_dataset']), 4)
        for tool, arguments in self.fixture.requests:
            if tool == 'query_dashboard_dataset':
                self.assertEqual({key: arguments[key] for key in FILTERS}, FILTERS)
                self.assertEqual(arguments['limit'], 2)

    async def test_stdio_bounded_catalog_and_query_forward_cursor(self):
        """Exercise SDK read tools with no local file side effect or automatic draining."""
        async with self.session() as session:
            catalog = self.payload(await session.call_tool('list_dashboard_datasets',
                {'search': 'SYNTHETIC', 'limit': 1}))
            token = catalog['page']['next_cursor']
            self.assertEqual(catalog['rows'], [publication()])
            next_catalog = self.payload(await session.call_tool('list_dashboard_datasets',
                {'search': 'SYNTHETIC', 'limit': 1, 'cursor': token}))
            self.assertEqual(next_catalog['rows'], [publication('DASHBOARD_SYNTHETIC_SECOND')])
            self.assertEqual(self.fixture.requests[-1][1]['cursor'], token)
            first = self.payload(await session.call_tool('query_dashboard_dataset',
                dict(dataset_name=DATASET, **FILTERS, limit=2)))
            self.assertEqual(first['rows'], ROWS[:2])
            token = first['page']['next_cursor']
            second = self.payload(await session.call_tool('query_dashboard_dataset',
                dict(dataset_name=DATASET, **FILTERS, limit=2, cursor=token)))
            self.assertEqual(second['rows'], ROWS[2:])
            self.assertEqual(self.fixture.requests[-1][1]['cursor'], token)
        self.assertEqual(len(self.fixture.requests), 4)
        self.assertFalse(list(self.directory.rglob('*.csv')))

    async def test_cli_rejects_invalid_and_private_names_without_completed_files(self):
        """Refuse unsafe identifiers and unpublished private datasets without publishing CSV."""
        for position, name in enumerate(('bad; DROP TABLE', 'ACCOUNT_HOLDINGS', 'DASHBOARD_PRIVATE_HOLDINGS')):
            with self.subTest(name=name):
                output = self.directory / ('invalid-' + str(position) + '.csv')
                code, stdout, stderr = await self.cli('dashboard', '--dataset-name', name, '--output', str(output))
                self.assertEqual(code, 1, stderr)
                self.assertNotIn('Traceback', stderr)
                self.assertEqual(stdout, '')
                self.assertFalse(output.exists())

    async def test_cli_failures_never_publish_completed_files(self):
        """Reject unavailable, errored, or changed-generation publications during export."""
        for mode in ('data_gap', 'error', 'generation'):
            with self.subTest(mode=mode):
                self.fixture.mode = mode
                self.fixture.requests.clear()
                output = self.directory / (mode + '.csv')
                code, stdout, stderr = await self.cli('dashboard', '--dataset-name', DATASET,
                    '--page-size', '2', '--output', str(output))
                self.assertEqual(code, 1, stderr)
                self.assertNotIn('Traceback', stderr)
                self.assertEqual(stdout, '')
                self.assertNotIn('PRIVATE_SENTINEL', stderr)
                self.assertFalse(output.exists())
                self.assertEqual(len([tool for tool, _ in self.fixture.requests
                                      if tool == 'query_dashboard_dataset']),
                                 2 if mode == 'generation' else 1)

    async def test_stdio_failures_never_publish_completed_files(self):
        """Keep data gaps, MCP errors, and generation changes out of completed files."""
        async with self.session() as session:
            for mode in ('data_gap', 'error', 'generation'):
                with self.subTest(mode=mode):
                    self.fixture.mode = mode
                    result = await session.call_tool('download_dashboard_dataset',
                        dict(dataset_name=DATASET, filename=mode + '.csv', page_size=2))
                    self.assertTrue(result.isError)
                    self.assertNotIn('PRIVATE_SENTINEL', str(result))
                    self.assertFalse((self.directory / 'exports' / (mode + '.csv')).exists())
            self.fixture.mode = 'ok'
            for name in ('bad; DROP TABLE', 'ACCOUNT_HOLDINGS', 'DASHBOARD_PRIVATE_HOLDINGS'):
                with self.subTest(name=name):
                    result = await session.call_tool('download_dashboard_dataset',
                        dict(dataset_name=name, filename='private.csv'))
                    self.assertTrue(result.isError)
                    self.assertFalse((self.directory / 'exports' / 'private.csv').exists())

    async def test_safe_basename_and_no_overwrite(self):
        """Confine stdio filenames and preserve existing destinations on both paths."""
        output = self.directory / 'existing.csv'
        output.write_bytes(b'existing synthetic data\r\n')
        code, stdout, _ = await self.cli('dashboard', '--dataset-name', DATASET, '--output', str(output))
        self.assertNotEqual(code, 0)
        self.assertEqual(stdout, '')
        self.assertEqual(output.read_bytes(), b'existing synthetic data\r\n')
        self.assertEqual(self.fixture.requests, [])
        async with self.session() as session:
            for filename in ('../escape.csv', '/escape.csv', 'nested/output.csv', 'nested\\output.csv'):
                with self.subTest(filename=filename):
                    result = await session.call_tool('download_dashboard_dataset',
                        dict(dataset_name=DATASET, filename=filename))
                    self.assertTrue(result.isError)
            destination = self.directory / 'exports' / 'existing.csv'
            destination.parent.mkdir(exist_ok=True)
            destination.write_bytes(b'existing synthetic data\r\n')
            result = await session.call_tool('download_dashboard_dataset',
                dict(dataset_name=DATASET, filename='existing.csv'))
            self.assertTrue(result.isError)
            self.assertEqual(destination.read_bytes(), b'existing synthetic data\r\n')
        self.assertFalse((self.directory / 'escape.csv').exists())
        self.assertEqual(self.fixture.requests, [])

    async def test_page_budget_and_caller_cursor_cannot_publish_truncated_csv(self):
        """Keep bounded exports incomplete and reject externally supplied continuation."""
        output = self.directory / 'budget.csv'
        code, stdout, _ = await self.cli('dashboard', '--dataset-name', DATASET,
            '--page-size', '1', '--max-pages', '1', '--output', str(output))
        self.assertNotEqual(code, 0)
        self.assertEqual(stdout, '')
        self.assertFalse(output.exists())
        async with self.session() as session:
            result = await session.call_tool('download_dashboard_dataset',
                dict(dataset_name=DATASET, filename='budget.csv', page_size=1, max_pages=1))
            self.assertTrue(result.isError)
            self.assertFalse((self.directory / 'exports' / 'budget.csv').exists())
        code, _, _ = await self.cli('dashboard', '--dataset-name', DATASET,
            '--cursor', 'caller-token', '--output', str(self.directory / 'cursor.csv'))
        self.assertNotEqual(code, 0)
        self.assertFalse((self.directory / 'cursor.csv').exists())
