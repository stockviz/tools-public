"""Offline transport security tests."""
import asyncio
import contextlib
import io
import json
import logging
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch

import httpx
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken
from mcp_consumer import transport


class StorageTests(unittest.IsolatedAsyncioTestCase):
    """Exercise actual SDK auth objects and filesystem persistence."""

    async def test_private_persistent_per_url_cache(self):
        """Keep tokens and registration private and URL isolated."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'state'
            store = transport.FileTokenStorage('https://example.com/mcp', root)
            token = OAuthToken(access_token='secret-access', refresh_token='secret-refresh')
            client = OAuthClientInformationFull(client_id='client', client_secret='secret-client', redirect_uris=['http://127.0.0.1:1234/callback'])
            self.assertIsNone(await store.get_tokens())
            await store.set_tokens(token)
            await store.set_client_info(client)
            again = transport.FileTokenStorage('https://example.com/mcp', root)
            self.assertEqual(await again.get_tokens(), token)
            self.assertEqual(await again.get_client_info(), client)
            self.assertIsNone(await transport.FileTokenStorage('https://other.example/mcp', root).get_tokens())
            for path in root.rglob('*'):
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700 if path.is_dir() else 0o600)
            self.assertEqual(stat.S_IMODE(root.stat().st_mode), 0o700)
            self.assertEqual(len(list(again.directory.iterdir())), 2)

    async def test_corrupt_cache_is_sanitized(self):
        """Do not expose malformed secret material in errors."""
        with tempfile.TemporaryDirectory() as tmp:
            store = transport.FileTokenStorage('https://example.com/mcp', Path(tmp))
            await store.set_tokens(OAuthToken(access_token='secret'))
            (store.directory / 'tokens.json').write_text('secret-invalid-json')
            with self.assertRaises(transport.TransportError) as caught:
                await store.get_tokens()
            self.assertNotIn('secret', str(caught.exception))

    async def test_persistent_expiry_allows_sdk_refresh(self):
        """Restore expiry across processes so refresh precedes the MCP request."""
        with tempfile.TemporaryDirectory() as tmp:
            store = transport.FileTokenStorage('https://example.com/mcp', Path(tmp))
            await store.set_tokens(OAuthToken(access_token='expired', refresh_token='refresh', expires_in=-1))
            await store.set_client_info(OAuthClientInformationFull(client_id='client', redirect_uris=['http://127.0.0.1:1/callback']))
            provider = transport.make_provider('https://example.com/mcp', transport.FileTokenStorage('https://example.com/mcp', Path(tmp)), 'http://127.0.0.1:1/callback', transport.noninteractive_redirect, None)
            await provider._initialize()
            self.assertFalse(provider.context.is_token_valid())
            self.assertTrue(provider.context.can_refresh_token())

    async def test_atomic_write_failure_preserves_prior_tokens(self):
        """A failed replacement must preserve valid old data and clean temps."""
        with tempfile.TemporaryDirectory() as tmp:
            store = transport.FileTokenStorage('https://example.com/mcp', Path(tmp))
            await store.set_tokens(OAuthToken(access_token='old'))
            with patch.object(transport.os, 'replace', side_effect=OSError('secret-failure')):
                with self.assertRaises(transport.TransportError) as caught:
                    await store.set_tokens(OAuthToken(access_token='new'))
            self.assertNotIn('secret', str(caught.exception))
            self.assertEqual((await store.get_tokens()).access_token, 'old')
            self.assertEqual([p.name for p in store.directory.iterdir()], ['tokens.json'])

    async def test_token_file_symlink_is_rejected(self):
        """Do not read another application's token cache through a symlink."""
        with tempfile.TemporaryDirectory() as tmp:
            store = transport.FileTokenStorage('https://example.com/mcp', Path(tmp) / 'state')
            target = Path(tmp) / 'outside'
            target.write_text(OAuthToken(access_token='secret').model_dump_json())
            (store.directory / 'tokens.json').symlink_to(target)
            with self.assertRaises(transport.TransportError):
                await store.get_tokens()

    async def test_symlink_cache_is_rejected(self):
        """Never follow a substituted cache directory."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'cache'
            target = Path(tmp) / 'target'
            target.mkdir()
            root.symlink_to(target)
            with self.assertRaises(transport.TransportError):
                transport.FileTokenStorage('https://example.com', root)


class ConnectionTests(unittest.IsolatedAsyncioTestCase):
    """Test SDK wiring offline and real loopback callback handling."""

    async def test_callback_validation_and_timeout(self):
        """Accept only the designated local callback with code and state."""
        async with transport.LoopbackCallback(timeout=0.15) as callback:
            async with httpx.AsyncClient(trust_env=False) as client:
                for suffix in ['/wrong?code=secret&state=s', '/callback?code=secret', '/callback?code=a&code=b&state=s']:
                    response = await client.get(callback.redirect_uri.replace('/callback', suffix))
                    self.assertEqual(response.status_code, 400)
                    self.assertNotIn('secret', response.text)
                response = await client.get(callback.redirect_uri + '?code=secret&state=expected')
                self.assertEqual(response.status_code, 200)
            self.assertEqual(await callback.wait(), ('secret', 'expected'))
        async with transport.LoopbackCallback(timeout=0.01) as callback:
            with self.assertRaisesRegex(transport.TransportError, 'timed out'):
                await callback.wait()

    async def test_noninteractive_never_opens_browser(self):
        """Tell unattended callers to run login rather than opening a browser."""
        with patch.object(transport.webbrowser, 'open') as browser:
            with self.assertRaisesRegex(transport.TransportError, 'run login'):
                await transport.noninteractive_redirect('https://example.com/?secret')
            browser.assert_not_called()

    async def test_connect_initializes_real_provider_and_sanitizes_errors(self):
        """Initialize before yielding and contain raw SDK or remote errors."""
        seen = {}

        @contextlib.asynccontextmanager
        async def stream(url, **kwargs):
            """Replace only the offline network boundary."""
            seen.update(kwargs)
            yield ('read', 'write', None)

        class Session:
            """Minimal session standing in for the unavailable remote service."""

            def __init__(self, *args):
                """Record the supplied streams."""
                self.ready = False

            async def __aenter__(self):
                """Open the mock session."""
                return self

            async def __aexit__(self, *args):
                """Close the mock session."""

            async def initialize(self):
                """Mark initialization complete."""
                self.ready = True

        with tempfile.TemporaryDirectory() as tmp, patch.object(transport, 'streamablehttp_client', stream), patch.object(transport, 'ClientSession', Session):
            async with transport.connect('https://example.com/mcp', Path(tmp)) as session:
                self.assertTrue(session.ready)
                provider = seen['auth']
                self.assertIsInstance(provider, transport.OAuthClientProvider)
                self.assertEqual(provider.context.client_metadata.scope, 'research:read')
                provider.context.client_metadata.scope = 'admin'
                self.assertEqual(provider.context.client_metadata.scope, 'research:read')
            with self.assertRaises(transport.TransportError) as caught:
                async with transport.connect('https://example.com/mcp', Path(tmp)):
                    raise RuntimeError('secret remote payload')
            self.assertNotIn('secret', str(caught.exception))
            self.assertIsNone(caught.exception.__cause__)

    async def test_interactive_browser_and_denial(self):
        """Print only public authorization URLs and sanitize OAuth denial."""
        output = io.StringIO()
        with contextlib.redirect_stderr(output), patch.object(transport.webbrowser, 'open', return_value=True) as browser:
            await transport.interactive_redirect('https://example.com/authorize?state=public&code_challenge=public')
            browser.assert_called_once()
            self.assertIn('https://example.com/authorize', output.getvalue())
            for url in ['https://example.com/authorize?code=secret', 'https://example.com/authorize#access_token=secret']:
                with self.assertRaises(transport.TransportError):
                    await transport.interactive_redirect(url)
            self.assertNotIn('secret', output.getvalue())
        async with transport.LoopbackCallback() as callback:
            async with httpx.AsyncClient(trust_env=False) as client:
                response = await client.get(callback.redirect_uri + '?error=secret-provider-error&state=s')
                self.assertEqual(response.status_code, 200)
                self.assertNotIn('secret', response.text)
            with self.assertRaisesRegex(transport.TransportError, 'denied'):
                await callback.wait()

    async def test_callback_rejects_host_method_and_replay(self):
        """Reject DNS rebinding, non-GET requests and repeated callbacks."""
        async with transport.LoopbackCallback() as callback:
            async with httpx.AsyncClient(trust_env=False) as client:
                url = callback.redirect_uri + '?code=secret&state=s'
                self.assertEqual((await client.get(url, headers={'Host': 'evil.example'})).status_code, 400)
                self.assertEqual((await client.post(url)).status_code, 400)
                self.assertEqual((await client.get(url)).status_code, 200)
                self.assertEqual((await client.get(url)).status_code, 400)
            self.assertEqual(await callback.wait(), ('secret', 's'))

    async def test_future_sdk_loggers_cannot_leak(self):
        """Cover loggers created lazily during discovery and response handling."""
        @contextlib.asynccontextmanager
        async def stream(url, **kwargs):
            """Emit a raw remote diagnostic from a newly created SDK logger."""
            logging.getLogger('mcp.client.lazy_secret_test').error('secret-token', exc_info=RuntimeError('secret-body'))
            raise RuntimeError('secret-response')
            yield
        sink = io.StringIO()
        handler = logging.StreamHandler(sink)
        root = logging.getLogger()
        root.addHandler(handler)
        try:
            with tempfile.TemporaryDirectory() as tmp, patch.object(transport, 'streamablehttp_client', stream):
                with self.assertRaises(transport.TransportError):
                    async with transport.connect('https://example.com/mcp', Path(tmp)):
                        pass
        finally:
            root.removeHandler(handler)
        self.assertNotIn('secret', sink.getvalue())

    async def test_real_sdk_oauth_flow_registration_tokens_and_scope(self):
        """Exercise actual SDK discovery and grants over an offline HTTP adapter."""
        requests = []
        state = {}

        async def redirect(url):
            """Capture public SDK state without opening a browser."""
            state.update(transport.parse_qs(transport.urlsplit(url).query))

        async def callback():
            """Return the SDK's expected state to exercise its validation."""
            return 'test-code', state['state'][0]

        def respond(request):
            """Replace only HTTP I/O with deterministic OAuth protocol responses."""
            requests.append(request)
            if request.url.path == '/mcp':
                return httpx.Response(200 if request.headers.get('authorization') == 'Bearer test-token' else 401)
            if 'oauth-protected-resource' in request.url.path:
                return httpx.Response(200, json={'resource': 'https://example.com/mcp', 'authorization_servers': ['https://example.com'], 'scopes_supported': ['admin', 'research:read']})
            if 'oauth-authorization-server' in request.url.path:
                return httpx.Response(200, json={'issuer': 'https://example.com', 'authorization_endpoint': 'https://example.com/authorize', 'token_endpoint': 'https://example.com/token', 'registration_endpoint': 'https://example.com/register', 'response_types_supported': ['code'], 'scopes_supported': ['admin']})
            if request.url.path == '/register':
                body = json.loads(request.content)
                self.assertEqual(body['scope'], 'research:read')
                return httpx.Response(201, json={**body, 'client_id': 'test-client'})
            if request.url.path == '/token':
                return httpx.Response(200, json={'access_token': 'test-token', 'refresh_token': 'test-refresh', 'token_type': 'Bearer', 'scope': 'research:read'})
            return httpx.Response(404)

        with tempfile.TemporaryDirectory() as tmp:
            storage = transport.FileTokenStorage('https://example.com/mcp', Path(tmp))
            provider = transport.make_provider('https://example.com/mcp', storage, 'http://127.0.0.1:1/callback', redirect, callback)
            async with httpx.AsyncClient(auth=provider, transport=httpx.MockTransport(respond)) as client:
                response = await client.get('https://example.com/mcp')
            self.assertEqual(response.status_code, 200)
            self.assertEqual(state['scope'], ['research:read'])
            self.assertEqual((await storage.get_tokens()).access_token, 'test-token')
            self.assertEqual((await storage.get_client_info()).client_id, 'test-client')
            self.assertTrue(any(request.url.path == '/register' for request in requests))

    async def test_sdk_state_mismatch_stays_secret_in_logs(self):
        """Use actual SDK state validation without emitting its raw exception."""
        with tempfile.TemporaryDirectory() as tmp:
            provider = transport.make_provider('https://example.com/mcp', transport.FileTokenStorage('https://example.com/mcp', Path(tmp)), 'http://127.0.0.1:1/callback', transport.noninteractive_redirect, None)
            async def redirect(url):
                """Avoid a browser in the SDK state-validation test."""
            async def callback():
                """Return a deliberately wrong state."""
                return 'secret-code', 'secret-wrong-state'
            provider.context.redirect_handler = redirect
            provider.context.callback_handler = callback
            provider.context.client_info = OAuthClientInformationFull(client_id='id', redirect_uris=['http://127.0.0.1:1/callback'])
            with self.assertRaises(Exception) as caught:
                await provider._perform_authorization_code_grant()
            self.assertIn('State parameter mismatch', str(caught.exception))
            record = logging.LogRecord('mcp.client.auth.oauth2', logging.ERROR, '', 0, 'secret', (), (type(caught.exception), caught.exception, None))
            transport.SecretSafeLogFilter().filter(record)
            self.assertNotIn('secret', record.getMessage())
            self.assertIsNone(record.exc_info)


class URLTests(unittest.TestCase):
    """Validate the endpoint before any network or storage operation."""

    def test_url_policy(self):
        """Allow HTTPS or local HTTP without URL credentials."""
        for url in ['https://example.com/mcp', 'http://127.0.0.1:8080/mcp', 'http://[::1]:8080/mcp', 'http://localhost:8080/mcp']:
            self.assertEqual(transport.validate_url(url), url)
        for url in ['http://example.com', 'ftp://example.com', 'https://u:secret@example.com', 'https://example.com/#secret', 'https://example.com/?secret=x', 'https:///mcp', 'https://example.com:bad', 'https://example.com/\n']:
            with self.subTest(url=url), self.assertRaises(transport.TransportError):
                transport.validate_url(url)
