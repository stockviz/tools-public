"""Keep release versions and remote AUM compatibility instructions consistent."""
import json
import re
import tomllib
import unittest
from pathlib import Path

from mcp_consumer import __version__


class ReleaseDocumentationTests(unittest.TestCase):
    """Check shipped instructions without claiming new local CLI or stdio tools."""

    def test_both_readmes_document_current_remote_aum_contract(self):
        """Require current version notes and selector-free examples for all three remote tools."""
        root = Path(__file__).resolve().parents[1]
        version = tomllib.loads((root / 'pyproject.toml').read_text())['project']['version']
        self.assertEqual(version, __version__)
        names = ('get_amfi_aum_ranking', 'get_amfi_aum_growth', 'get_amfi_category_aum_history')
        for filename in ('README.md', 'PUBLIC_README.md'):
            with self.subTest(filename=filename):
                text = (root / filename).read_text()
                self.assertIn('## Release ' + version, text)
                for name in names:
                    self.assertIn(name, text)
                self.assertIn('not new CLI subcommands or local stdio tools', text)
                self.assertIn('query_amfi_analytics', text)
                section = text.split('## Release ' + version, 1)[1].split('\n## ', 1)[0]
                examples = [json.loads(block) for block in re.findall(r'```json\n(.*?)\n```', section, re.S)]
                self.assertEqual({example['name'] for example in examples}, set(names))
                self.assertTrue(all('operation' not in example['arguments'] for example in examples))


if __name__ == '__main__':
    unittest.main()
