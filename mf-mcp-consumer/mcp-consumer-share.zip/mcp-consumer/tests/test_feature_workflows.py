"""Exercise real CLI/stdio/HTTP transports against explicitly synthetic MCP data.

This fixture is not the Cloudflare Worker or a production database. No consumer
transport, download engine, filesystem writer, or SDK session is mocked.
"""
import asyncio
import csv
import hashlib
import io
import json
import os
import socket
import sys
import tempfile
import threading
import time
import unittest
from datetime import timedelta
from pathlib import Path

import uvicorn
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.server.fastmcp import FastMCP
from mcp.shared.auth import OAuthToken
from mcp.types import CallToolResult, TextContent
from starlette.responses import JSONResponse

from mcp_consumer.transport import FileTokenStorage


ROOT = Path(__file__).resolve().parents[1]
FIXTURE_TOKEN = 'synthetic-integration-access-only'
NAV_CODE = '900001'
INDEX_NAME = 'SYNTHETIC "Quoted", INDEX TR'
NAV_COLUMNS = ['scheme_code', 'scheme_name', 'date', 'nav', 'auto_id']
INDEX_COLUMNS = ['index_name', 'date', 'close']
NAV_ROWS = [
    {'scheme_code': NAV_CODE, 'scheme_name': 'Synthetic "Quoted", Growth\nPlan',
     'date': '2021-01-04', 'nav': '100.000000000000000001', 'auto_id': '-9223372036854775808'},
    {'scheme_code': NAV_CODE, 'scheme_name': 'Synthetic "Quoted", Growth\nPlan',
     'date': '2021-01-04', 'nav': '100.000000000000000001', 'auto_id': '-9007199254740993'},
    {'scheme_code': NAV_CODE, 'scheme_name': 'Synthetic "Quoted", Growth\nPlan',
     'date': '2021-01-05', 'nav': '101.250000000000000001', 'auto_id': '9007199254740993'},
    {'scheme_code': NAV_CODE, 'scheme_name': 'Synthetic "Quoted", Growth\nPlan',
     'date': '2021-01-06', 'nav': None, 'auto_id': '9223372036854775807'},
    {'scheme_code': NAV_CODE, 'scheme_name': 'Synthetic "Quoted", Growth\nPlan',
     'date': '2021-01-07', 'nav': '102.125', 'auto_id': '1'},
]
INDEX_ROWS = [
    {'index_name': INDEX_NAME, 'date': day, 'close': value}
    for day, value in [('2021-01-04', '12345.000000000001'), ('2021-01-05', '12346.25'),
                       ('2021-01-06', '12347.125'), ('2021-01-07', '12348.5'),
                       ('2021-01-08', '12349.75')]
]


def opaque_cursor(tool, identity, start, end, limit, offset):
    """Make an intentionally opaque token that catches whitespace/Unicode rewriting."""
    return '  synthetic/+/=\\"☃:' + json.dumps([tool, identity, start, end, limit, offset]) + '  '


class BearerFixture:
    """Require an explicitly synthetic bearer without changing the consumer auth code."""

    def __init__(self, app):
        """Wrap only the fixture's real HTTP application."""
        self.app = app

    async def __call__(self, scope, receive, send):
        """Reject missing credentials at the HTTP boundary and pass ASGI lifespan through."""
        if scope['type'] == 'http' and scope['path'].rstrip('/') == '/mcp':
            headers = dict(scope['headers'])
            if headers.get(b'authorization') != ('Bearer ' + FIXTURE_TOKEN).encode():
                response = JSONResponse({'error': 'synthetic fixture requires authorization'}, status_code=401,
                                        headers={'WWW-Authenticate': 'Bearer'})
                await response(scope, receive, send)
                return
        await self.app(scope, receive, send)


class SyntheticHistoryServer:
    """Serve deterministic history pages over an actual loopback TCP connection."""

    def __init__(self):
        """Create isolated request recording and a stateless SDK MCP application."""
        self.requests = []
        self.server = FastMCP('Synthetic integration fixture', stateless_http=True,
                              json_response=True, log_level='CRITICAL')
        self.server.add_tool(self.get_nav_history)
        self.server.add_tool(self.get_index_history)

    def get_nav_history(self, scheme_code: str, start: str | None = None,
                        end: str | None = None, limit: int = 1000,
                        format: str = 'json', cursor: str | None = None) -> dict:
        """Return synthetic NAV pages, including explicitly requested failure scenarios."""
        return self.page('get_nav_history', scheme_code, start, end, limit, format, cursor)

    def get_index_history(self, index_name: str, start: str | None = None,
                          end: str | None = None, limit: int = 1000,
                          format: str = 'json', cursor: str | None = None) -> dict:
        """Return exact-name synthetic index pages through the SDK tool handler."""
        return self.page('get_index_history', index_name, start, end, limit, format, cursor)

    def page(self, tool, identity, start, end, limit, format, cursor):
        """Validate immutable context and simulate upstream failures without engine mocks."""
        arguments = dict(start=start, end=end, limit=limit, format=format, cursor=cursor)
        arguments['scheme_code' if tool == 'get_nav_history' else 'index_name'] = identity
        self.requests.append((tool, arguments))
        rows = NAV_ROWS if tool == 'get_nav_history' else INDEX_ROWS
        rows = [dict(row) for row in rows if (start is None or row['date'] >= start)
                and (end is None or row['date'] <= end)]
        if tool == 'get_nav_history':
            for row in rows:
                row['scheme_code'] = identity
        if identity == '900009':
            rows = []
        offset = 0
        if cursor is not None:
            matches = [value for value in range(limit, len(rows), limit)
                       if cursor == opaque_cursor(tool, identity, start, end, limit, value)]
            if not matches:
                raise ValueError('Synthetic continuation context mismatch')
            offset = matches[0]
        if identity in {'920001', '920002', '920003', '920004'} and (identity in {'920001', '920003'} or offset):
            text = ('MariaDB read unavailable (PROTOCOL_SEQUENCE_TIMEOUT)'
                    if identity in {'920001', '920002'} else
                    'MariaDB read unavailable (PROTOCOL_SEQUENCE_TIMEOUT) password=PRIVATE_SENTINEL')
            return CallToolResult(isError=True, content=[TextContent(type='text', text=text)])
        if identity == '900002' and offset:
            raise ValueError('Explicit synthetic second-page failure')
        selected = rows[offset:offset + limit]
        if identity == '900004' and offset and selected:
            selected[0]['scheme_code'] = '900099'
        more = offset + len(selected) < len(rows)
        continuation = opaque_cursor(tool, identity, start, end, limit, offset + len(selected)) if more else None
        if identity == '900003' and offset and more:
            continuation = cursor
        return {'status': 'ok', 'rows': selected,
                'page': {'limit': limit, 'returned_count': len(selected),
                         'has_more': more, 'next_cursor': continuation},
                'metadata': {'warnings': ['Explicitly synthetic integration fixture.']}}

    def start(self):
        """Bind an ephemeral port without a port-selection race and await server readiness."""
        self.listener = socket.socket()
        self.listener.bind(('127.0.0.1', 0))
        self.url = 'http://127.0.0.1:' + str(self.listener.getsockname()[1]) + '/mcp'
        config = uvicorn.Config(BearerFixture(self.server.streamable_http_app()),
                                log_level='critical', access_log=False, lifespan='on')
        self.http = uvicorn.Server(config)
        self.thread = threading.Thread(target=self.http.run, kwargs={'sockets': [self.listener]}, daemon=True)
        self.thread.start()
        deadline = time.monotonic() + 10
        while not self.http.started and self.thread.is_alive() and time.monotonic() < deadline:
            time.sleep(0.01)
        if not self.http.started:
            self.stop()
            raise RuntimeError('Synthetic MCP fixture did not start')

    def stop(self):
        """Stop and join the fixture so the test leaves no background server behind."""
        self.http.should_exit = True
        self.thread.join(timeout=10)
        self.listener.close()
        if self.thread.is_alive():
            raise RuntimeError('Synthetic MCP fixture did not shut down')


class ConsumerFeatureWorkflows(unittest.IsolatedAsyncioTestCase):
    """Test user-visible download workflows through CLI and local stdio subprocesses."""

    @classmethod
    def setUpClass(cls):
        """Start one real HTTP fixture for this serial unittest class."""
        cls.fixture = SyntheticHistoryServer()
        cls.fixture.start()

    @classmethod
    def tearDownClass(cls):
        """Close the HTTP fixture after the feature suite."""
        cls.fixture.stop()

    async def asyncSetUp(self):
        """Give every feature its own private config, cache, outputs, and request record."""
        self.temporary = tempfile.TemporaryDirectory(prefix='consumer-feature-')
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.config = self.directory / 'config.json'
        self.config.write_text(json.dumps({'server_url': self.fixture.url, 'state_dir': 'state',
                                           'output_dir': 'exports'}))
        self.config.chmod(0o600)
        self.fixture.requests.clear()
        storage = FileTokenStorage(self.fixture.url, self.directory / 'state')
        await storage.set_tokens(OAuthToken(access_token=FIXTURE_TOKEN, token_type='Bearer',
                                           scope='research:read', expires_in=3600))

    async def cli(self, *arguments):
        """Run the real installed module from a different working directory with a timeout."""
        environment = dict(os.environ, PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE='1')
        process = await asyncio.create_subprocess_exec(
            sys.executable, '-m', 'mcp_consumer', '--config', str(self.config), *arguments,
            cwd=self.directory, env=environment, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE)
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=20)
        except BaseException:
            if process.returncode is None:
                process.kill()
                await process.wait()
            raise
        self.assertNotIn(FIXTURE_TOKEN, stdout.decode() + stderr.decode())
        return process.returncode, stdout.decode(), stderr.decode()

    def assert_export(self, output, metadata, columns, rows, pages):
        """Compare every CSV value and byte checksum against an independent expected serialization."""
        expected = io.StringIO(newline='')
        writer = csv.DictWriter(expected, fieldnames=columns, lineterminator='\r\n')
        writer.writeheader()
        writer.writerows(rows)
        self.assertEqual(output.read_bytes(), expected.getvalue().encode())
        self.assertEqual(metadata['status'], 'complete')
        self.assertEqual(metadata['row_count'], len(rows))
        self.assertEqual(metadata['page_count'], pages)
        self.assertEqual(metadata['sha256'], hashlib.sha256(output.read_bytes()).hexdigest())
        self.assertEqual(metadata['first_date'], rows[0]['date'] if rows else None)
        self.assertEqual(metadata['last_date'], rows[-1]['date'] if rows else None)
        self.assertNotIn('rows', metadata)
        self.assertNotIn('cursor', json.dumps(metadata))
        self.assertFalse(list(output.parent.glob(output.name + '.*.partial')))

    async def test_cli_downloads_every_nav_page_without_numeric_or_cursor_rewriting(self):
        """Keep bigint ties, decimal text, nulls, CSV quoting, and opaque continuation bytes."""
        output = self.directory / 'exports' / 'nav.csv'
        code, stdout, _ = await self.cli('nav', '--scheme-code', NAV_CODE, '--page-size', '2',
                                       '--start', '2021-01-04', '--end', '2021-01-07', '--output', str(output))
        self.assertEqual(code, 0)
        self.assert_export(output, json.loads(stdout), NAV_COLUMNS, NAV_ROWS, 3)
        requests = self.fixture.requests
        self.assertEqual(len(requests), 3)
        for position, (tool, arguments) in enumerate(requests):
            self.assertEqual(tool, 'get_nav_history')
            self.assertEqual({key: value for key, value in arguments.items() if key != 'cursor'},
                             {'scheme_code': NAV_CODE, 'start': '2021-01-04', 'end': '2021-01-07',
                              'limit': 2, 'format': 'json'})
            self.assertEqual(arguments['cursor'], None if position == 0 else
                             opaque_cursor(tool, NAV_CODE, '2021-01-04', '2021-01-07', 2, position * 2))

    async def test_cli_index_export_honors_inclusive_dates(self):
        """Export exactly the bounded index rows through real SDK HTTP calls."""
        output = self.directory / 'index.csv'
        code, stdout, _ = await self.cli('index', '--index-name', INDEX_NAME, '--page-size', '2',
                                       '--start', '2021-01-05', '--end', '2021-01-07', '--output', str(output))
        self.assertEqual(code, 0)
        self.assert_export(output, json.loads(stdout), INDEX_COLUMNS, INDEX_ROWS[1:4], 2)

    async def test_cli_empty_history_is_a_verified_header_only_export(self):
        """Distinguish a successful zero-row response from an upstream error."""
        output = self.directory / 'empty.csv'
        code, stdout, _ = await self.cli('nav', '--scheme-code', '900009', '--output', str(output))
        self.assertEqual(code, 0)
        self.assert_export(output, json.loads(stdout), NAV_COLUMNS, [], 1)

    async def test_cli_missing_authorization_fails_without_publishing_or_leaking_credentials(self):
        """Exercise a real HTTP authentication rejection without launching a browser."""
        storage = FileTokenStorage(self.fixture.url, self.directory / 'state')
        (storage.directory / 'tokens.json').unlink()
        output = self.directory / 'unauthorized.csv'
        code, stdout, stderr = await self.cli('nav', '--scheme-code', NAV_CODE, '--output', str(output))
        self.assertEqual(code, 1)
        self.assertEqual(stdout, '')
        self.assertIn('login', stderr)
        self.assertFalse(output.exists())
        self.assertFalse(list(self.directory.glob('unauthorized.csv.*.partial')))
        self.assertEqual(self.fixture.requests, [])

    async def test_cli_refuses_to_overwrite_without_requesting_history(self):
        """Preserve an existing destination and avoid issuing any history tool call."""
        output = self.directory / 'existing.csv'
        output.write_bytes(b'original user data\r\n')
        code, stdout, stderr = await self.cli('nav', '--scheme-code', NAV_CODE, '--output', str(output))
        self.assertEqual(code, 1)
        self.assertEqual(stdout, '')
        self.assertIn('already exists', stderr)
        self.assertEqual(output.read_bytes(), b'original user data\r\n')
        self.assertEqual(self.fixture.requests, [])

    async def test_cli_plain_timeout_and_hostile_errors_preserve_partials(self):
        """Expose only recognized timeouts through the actual CLI/HTTP path."""
        for scheme in ('920001', '920002', '920003', '920004'):
            with self.subTest(scheme=scheme):
                self.fixture.requests.clear()
                output = self.directory / (scheme + '.csv')
                code, stdout, stderr = await self.cli('nav', '--scheme-code', scheme,
                    '--page-size', '2', '--output', str(output))
                self.assertEqual(code, 1)
                self.assertEqual(stdout, '')
                self.assertNotIn('PRIVATE_SENTINEL', stderr)
                self.assertEqual('code=query_timeout' in stderr, scheme in {'920001', '920002'})
                self.assertIn('Incomplete file:', stderr)
                self.assertFalse(output.exists())
                partials = list(self.directory.glob(scheme + '.csv.*.partial'))
                self.assertEqual(len(partials), 1)
                with partials[0].open(newline='') as handle:
                    rows = list(csv.DictReader(handle))
                expected = 0 if scheme in {'920001', '920003'} else 2
                self.assertEqual(len(rows), expected)
                self.assertEqual([row['auto_id'] for row in rows],
                                 [row['auto_id'] for row in NAV_ROWS[:expected]])
                self.assertEqual(len(self.fixture.requests), 1 if expected == 0 else 2)

    async def test_stdio_plain_timeout_and_hostile_errors_preserve_partials(self):
        """Expose safe diagnostics through SDK/stdio/HTTP without retrying failed queries."""
        parameters = StdioServerParameters(command=sys.executable,
            args=['-m', 'mcp_consumer', '--config', str(self.config), 'serve'],
            cwd=str(self.directory), env={'PYTHONPATH': str(ROOT), 'PYTHONDONTWRITEBYTECODE': '1'})
        with (self.directory / 'timeout.stderr').open('w+') as errors:
            async with stdio_client(parameters, errlog=errors) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=20)) as session:
                    await session.initialize()
                    for scheme in ('920001', '920002', '920003', '920004'):
                        with self.subTest(scheme=scheme):
                            self.fixture.requests.clear()
                            response = await session.call_tool('download_nav_history',
                                {'scheme_code': scheme, 'filename': scheme + '.csv', 'page_size': 2})
                            self.assertTrue(response.isError)
                            text = ''.join(block.text for block in response.content if block.type == 'text')
                            self.assertNotIn('PRIVATE_SENTINEL', text)
                            self.assertEqual('code=query_timeout' in text, scheme in {'920001', '920002'})
                            self.assertIn('Incomplete file:', text)
                            output = self.directory / 'exports' / (scheme + '.csv')
                            self.assertFalse(output.exists())
                            partials = list(output.parent.glob(output.name + '.*.partial'))
                            self.assertEqual(len(partials), 1)
                            with partials[0].open(newline='') as handle:
                                rows = list(csv.DictReader(handle))
                            expected = 0 if scheme in {'920001', '920003'} else 2
                            self.assertEqual(len(rows), expected)
                            self.assertEqual([row['auto_id'] for row in rows],
                                             [row['auto_id'] for row in NAV_ROWS[:expected]])
                            self.assertEqual(len(self.fixture.requests), 1 if expected == 0 else 2)
            errors.seek(0)
            self.assertNotIn('PRIVATE_SENTINEL', errors.read())

    async def test_cli_upstream_failure_retains_only_verified_partial_rows(self):
        """Never publish a complete file after an actual second-page MCP tool error."""
        output = self.directory / 'failed.csv'
        code, stdout, stderr = await self.cli('nav', '--scheme-code', '900002', '--page-size', '2',
                                             '--output', str(output))
        self.assertEqual(code, 1)
        self.assertEqual(stdout, '')
        self.assertIn('Incomplete file:', stderr)
        self.assertFalse(output.exists())
        partials = list(self.directory.glob('failed.csv.*.partial'))
        self.assertEqual(len(partials), 1)
        with partials[0].open(newline='') as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), 2)
        self.assertEqual([row['auto_id'] for row in rows], [row['auto_id'] for row in NAV_ROWS[:2]])
        self.assertEqual(len(self.fixture.requests), 2)

    async def test_cli_rejects_repeated_cursor_and_cross_instrument_rows(self):
        """Stop corrupt continuation workflows rather than silently deduplicating or mixing funds."""
        for scheme, message in [('900003', 'cursor repeated'), ('900004', 'different scheme')]:
            with self.subTest(scheme=scheme):
                self.fixture.requests.clear()
                output = self.directory / (scheme + '.csv')
                code, stdout, stderr = await self.cli('nav', '--scheme-code', scheme, '--page-size', '2',
                                                     '--output', str(output))
                self.assertEqual(code, 1)
                self.assertEqual(stdout, '')
                self.assertIn(message, stderr)
                self.assertFalse(output.exists())
                self.assertEqual(len(self.fixture.requests), 2)

    async def test_cli_page_budget_exhaustion_does_not_publish_a_complete_csv(self):
        """Stop at the caller's page cap even when the server advertises more history."""
        output = self.directory / 'budget.csv'
        code, stdout, stderr = await self.cli('nav', '--scheme-code', NAV_CODE, '--page-size', '2',
                                             '--max-pages', '1', '--output', str(output))
        self.assertEqual(code, 1)
        self.assertEqual(stdout, '')
        self.assertIn('Page budget exhausted', stderr)
        self.assertFalse(output.exists())
        self.assertEqual(len(self.fixture.requests), 1)

    async def test_six_instrument_comparison_keeps_parallel_exports_isolated(self):
        """Complete a current comparison workflow without mixing concurrent output files."""
        schemes = ['910001', '910002', '910003', '910004', '910005', '910006']
        results = await asyncio.gather(*[
            self.cli('nav', '--scheme-code', scheme, '--page-size', '2',
                     '--output', str(self.directory / (scheme + '.csv')))
            for scheme in schemes])
        for scheme, (code, stdout, _) in zip(schemes, results):
            with self.subTest(scheme=scheme):
                self.assertEqual(code, 0)
                rows = [{**row, 'scheme_code': scheme} for row in NAV_ROWS]
                self.assert_export(self.directory / (scheme + '.csv'), json.loads(stdout),
                                   NAV_COLUMNS, rows, 3)
        self.assertEqual(len(self.fixture.requests), 18)
        self.assertEqual({arguments['scheme_code'] for _, arguments in self.fixture.requests}, set(schemes))

    async def test_stdio_extension_downloads_both_histories_and_confines_filenames(self):
        """Exercise SDK→stdio subprocess→real HTTP→CSV and keep tool results metadata-only."""
        parameters = StdioServerParameters(command=sys.executable,
            args=['-m', 'mcp_consumer', '--config', str(self.config), 'serve'],
            cwd=str(self.directory), env={'PYTHONPATH': str(ROOT), 'PYTHONDONTWRITEBYTECODE': '1'})
        with (self.directory / 'stdio.stderr').open('w+') as errors:
            async with stdio_client(parameters, errlog=errors) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=20)) as session:
                    await session.initialize()
                    tools = (await session.list_tools()).tools
                    self.assertEqual({tool.name for tool in tools},
                                     {'download_nav_history', 'download_index_history',
                                      'download_equity_history', 'list_equities'})
                    for tool in tools:
                        if tool.name != 'list_equities':
                            self.assertNotIn('cursor', tool.inputSchema['properties'])
                        self.assertFalse(tool.annotations.destructiveHint)
                        self.assertEqual(tool.annotations.readOnlyHint, tool.name == 'list_equities')
                    for tool, arguments, columns, rows, filename in [
                        ('download_nav_history', {'scheme_code': NAV_CODE}, NAV_COLUMNS, NAV_ROWS, 'nav.csv'),
                        ('download_index_history', {'index_name': INDEX_NAME}, INDEX_COLUMNS, INDEX_ROWS, 'index.csv')]:
                        response = await session.call_tool(tool, {**arguments, 'filename': filename, 'page_size': 2})
                        self.assertFalse(response.isError)
                        self.assertEqual(len(response.content), 1)
                        self.assertEqual(response.content[0].type, 'text')
                        metadata = response.structuredContent or json.loads(response.content[0].text)
                        self.assert_export(self.directory / 'exports' / filename, metadata, columns, rows, 3)
                    before = len(self.fixture.requests)
                    rejected = await session.call_tool('download_nav_history',
                                                       {'scheme_code': NAV_CODE, 'filename': '../escape.csv'})
                    self.assertTrue(rejected.isError)
                    self.assertFalse((self.directory / 'escape.csv').exists())
                    self.assertEqual(len(self.fixture.requests), before)
            errors.seek(0)
            self.assertNotIn(FIXTURE_TOKEN, errors.read())


if __name__ == '__main__':
    unittest.main()
