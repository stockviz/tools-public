"""Opt-in, read-only live MCP→CLI/stdio→CSV feature acceptance.

Set MCP_E2E_CONFIG to an operator-owned consumer config. No credentials or endpoint
are embedded here. Default discovery skips this gate; ordinary tests stay offline.
This verifies transport/data parity, not independent native-database correctness.
"""
import asyncio
import csv
import hashlib
import io
import json
import os
import sys
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from mcp_consumer.cli import parser, resolve_config
from mcp_consumer.transport import connect


ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(os.environ.get('MCP_E2E_CONFIG'), 'Live gate requires explicit MCP_E2E_CONFIG')
class LiveHistoryFeatures(unittest.IsolatedAsyncioTestCase):
    """Compare bounded live exports with a separate SDK pagination walk."""

    async def asyncSetUp(self):
        """Use only explicitly selected consumer configuration and temporary export paths."""
        self.temporary = tempfile.TemporaryDirectory(prefix='live-consumer-feature-')
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        self.config = Path(os.environ['MCP_E2E_CONFIG']).expanduser().resolve()
        self.settings = resolve_config(parser().parse_args([
            '--config', str(self.config), 'nav', '--scheme-code', '105758',
            '--output', str(self.directory / 'unused.csv')]))
        self.start = os.environ.get('MCP_E2E_START', '2021-01-04')
        self.end = os.environ.get('MCP_E2E_END', '2021-01-08')

    def value(self, response):
        """Parse the SDK wire result independently of the production download engine."""
        self.assertFalse(response.isError, 'Remote tool returned an error')
        if response.structuredContent is not None:
            return response.structuredContent
        self.assertEqual(len(response.content), 1)
        self.assertEqual(response.content[0].type, 'text')
        return json.loads(response.content[0].text)

    async def independent_rows(self, tool, arguments):
        """Follow a bounded number of real pages without calling the consumer downloader."""
        rows, seen, pages = [], set(), 0
        values = {**arguments, 'start': self.start, 'end': self.end,
                  'limit': 2, 'format': 'json', 'cursor': None}
        async with connect(self.settings.url, self.settings.state_dir,
                           legacy_registration=self.settings.legacy_registration) as session:
            names = {item.name for item in (await session.list_tools()).tools}
            self.assertTrue({'get_nav_history', 'get_index_history'}.issubset(names))
            for _ in range(20):
                page = self.value(await session.call_tool(tool, values))
                self.assertEqual(page['status'], 'ok')
                self.assertEqual(page['page']['returned_count'], len(page['rows']))
                self.assertEqual(page['page']['limit'], 2)
                self.assertLessEqual(len(page['rows']), 2)
                rows.extend(page['rows'])
                pages += 1
                if not page['page']['has_more']:
                    self.assertIsNone(page['page']['next_cursor'])
                    break
                cursor = page['page']['next_cursor']
                self.assertIsInstance(cursor, str)
                self.assertNotIn(cursor, seen)
                seen.add(cursor)
                values = {**values, 'cursor': cursor}
            else:
                self.fail('Live verification exceeded its bounded page budget')
        self.assertGreater(pages, 1, 'Select a window with enough observations to exercise pagination')
        for row in rows:
            self.assertLessEqual(self.start, row['date'])
            self.assertLessEqual(row['date'], self.end)
        return rows, pages

    async def verify_history(self, tool, arguments, command, flag, identity, columns):
        """Require SDK, CLI, and real local stdio exports to produce exactly the same CSV bytes."""
        rows, pages = await self.independent_rows(tool, arguments)
        output = self.directory / 'cli.csv'
        environment = dict(os.environ, PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE='1')
        process = await asyncio.create_subprocess_exec(
            sys.executable, '-m', 'mcp_consumer', '--config', str(self.config), command,
            flag, identity, '--start', self.start, '--end', self.end, '--page-size', '2',
            '--output', str(output), cwd=self.directory, env=environment,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=90)
        except BaseException:
            if process.returncode is None:
                process.kill()
                await process.wait()
            raise
        self.assertEqual(process.returncode, 0, 'Live CLI failed; raw output suppressed for credential safety')
        metadata = json.loads(stdout)
        expected = io.StringIO(newline='')
        writer = csv.DictWriter(expected, fieldnames=columns, lineterminator='\r\n')
        writer.writeheader()
        writer.writerows(rows)
        expected_bytes = expected.getvalue().encode()
        self.assertEqual(output.read_bytes(), expected_bytes)
        self.assertEqual(metadata['row_count'], len(rows))
        self.assertEqual(metadata['page_count'], pages)
        self.assertEqual(metadata['sha256'], hashlib.sha256(expected_bytes).hexdigest())
        self.assertNotIn('rows', metadata)
        self.assertNotIn('cursor', json.dumps(metadata))

        # CLI flags deliberately confine this test's exports, regardless of the user's config output_dir.
        parameters = StdioServerParameters(command=sys.executable,
            args=['-m', 'mcp_consumer', '--config', str(self.config), 'serve',
                  '--output-dir', str(self.directory / 'stdio')],
            cwd=str(self.directory), env={'PYTHONPATH': str(ROOT), 'PYTHONDONTWRITEBYTECODE': '1'})
        with (self.directory / 'stdio.stderr').open('w') as errors:
            async with stdio_client(parameters, errlog=errors) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=timedelta(seconds=90)) as session:
                    await session.initialize()
                    result = await session.call_tool('download_nav_history' if command == 'nav'
                        else 'download_index_history', {**arguments, 'filename': 'history.csv',
                            'start': self.start, 'end': self.end, 'page_size': 2})
                    local_metadata = self.value(result)
                    self.assertEqual(local_metadata['status'], 'complete')
                    self.assertEqual(local_metadata['row_count'], len(rows))
                    self.assertEqual(local_metadata['page_count'], pages)
                    self.assertEqual(local_metadata['sha256'], metadata['sha256'])
                    self.assertNotIn('rows', local_metadata)
                    self.assertNotIn('cursor', json.dumps(local_metadata))
        self.assertEqual((self.directory / 'stdio' / 'history.csv').read_bytes(), expected_bytes)

    async def test_live_nav_sdk_cli_and_stdio_exports_match(self):
        """Accept a real multi-page NAV export without printing source data or credentials."""
        code = os.environ.get('MCP_E2E_NAV_CODE', '105758')
        await asyncio.wait_for(self.verify_history('get_nav_history', {'scheme_code': code},
            'nav', '--scheme-code', code, ['scheme_code', 'scheme_name', 'date', 'nav', 'auto_id']),
            timeout=180)

    async def test_live_index_sdk_cli_and_stdio_exports_match(self):
        """Accept a real multi-page index export through both public consumer entry points."""
        name = os.environ.get('MCP_E2E_INDEX_NAME', 'NIFTY SMALLCAP 250 TR')
        await asyncio.wait_for(self.verify_history('get_index_history', {'index_name': name},
            'index', '--index-name', name, ['index_name', 'date', 'close']), timeout=180)


if __name__ == '__main__':
    unittest.main()
