"""Synthetic dashboard contracts: no network, credentials or local configuration."""
import copy
import csv
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any
from unittest.mock import patch

from mcp_consumer import dashboard
from mcp_consumer.download import DownloadError


SCHEMA = [["ROW_ID", "BIGINT"], ["NAME", "TEXT"], ["DAY", "DATE"], ["VALUE", "DECIMAL(24,8)"]]


def publication() -> dict[str, Any]:
    """Make one synthetic publication generation."""
    return dict(dataset_name="DASHBOARD_SAMPLE", row_count="2", metadata={"quality": "ok"},
                refreshed_at="2026-01-01 12:00:00.000001", content_digest="a" * 64, schema=copy.deepcopy(SCHEMA))


def row(key="1", **values):
    """Make one exact-text observation."""
    return {"ROW_ID": key, "NAME": "quoted,\"text\"\nnext", "DAY": "2026-01-01", "VALUE": "9007199254740993.12345678", **values}


def page(rows, more=False, cursor=None, limit=100) -> dict[str, Any]:
    """Make a synthetic query envelope."""
    return dict(status="ok", dataset_name="DASHBOARD_SAMPLE", metadata=publication(), rows=rows,
                page=dict(limit=limit, returned_count=len(rows), has_more=more, next_cursor=cursor))


class Remote:
    """Record calls while replaying controlled synthetic MCP results."""

    def __init__(self, *pages):
        """Keep isolated response values and call records."""
        self.pages = list(pages)
        self.calls = []

    async def __call__(self, tool, args):
        """Return the next envelope in the SDK's structured wrapper."""
        self.calls.append((tool, copy.deepcopy(args)))
        return SimpleNamespace(structuredContent=copy.deepcopy(self.pages.pop(0)), isError=False)


class ValidationTests(unittest.TestCase):
    """Exercise request bounds before any remote call."""

    def test_defaults_and_literal_cursor(self):
        """Default to 100 and never decode opaque cursor text."""
        self.assertEqual(dashboard.validate_dashboard_catalog({}), {"limit": 100, "cursor": None})
        args = dashboard.validate_dashboard_query({"dataset_name": "DASHBOARD_SAMPLE", "cursor": " opaque "})
        self.assertEqual(args["cursor"], " opaque ")
        self.assertEqual(args["limit"], 100)
        self.assertEqual(dashboard.validate_dashboard_catalog({"cursor": "x" * 8192})["cursor"], "x" * 8192)

    def test_invalid_requests(self):
        """Reject unsafe identifiers, unpaired filters and invalid calendar bounds."""
        cases = [{"dataset_name": "DASHBOARD_CATALOG"}, {"dataset_name": "DASHBOARD_x"},
                 {"limit": True}, {"limit": 201}, {"cursor": "x" * 8193}, {"unknown": 1},
                 {"entity_column": "NAME"}, {"entity": "x"}, {"entity_column": "a" * 65, "entity": "x"},
                 {"date_column": "DAY"}, {"start": "2026-01-01"},
                 {"date_column": "DAY", "start": "2026-02-30"},
                 {"date_column": "DAY", "start": "2026-02-01", "end": "2026-01-01"}]
        for extra in cases:
            with self.subTest(extra=extra), self.assertRaises(DownloadError):
                dashboard.validate_dashboard_query({"dataset_name": "DASHBOARD_SAMPLE", **extra})
        with self.assertRaises(DownloadError):
            dashboard.validate_dashboard_query({"dataset_name": "DASHBOARD_SAMPLE", "cursor": None}, allow_cursor=False)
        for args in ({"search": ""}, {"search": "x" * 257}, {"limit": 0}, {"dataset_name": "DASHBOARD_SAMPLE"}):
            with self.subTest(args=args), self.assertRaises(DownloadError):
                dashboard.validate_dashboard_catalog(args)


class DashboardTests(unittest.IsolatedAsyncioTestCase):
    """Verify bounded inspection and fail-closed complete dynamic exports."""

    async def test_one_page_query_and_catalog(self):
        """Inspect only one page and retain bounded data for the caller."""
        remote = Remote(page([row()], True, "opaque"))
        value = await dashboard.dashboard_query(remote, {"dataset_name": "DASHBOARD_SAMPLE"})
        self.assertEqual(value["rows"][0]["VALUE"], row()["VALUE"])
        self.assertEqual(len(remote.calls), 1)
        catalog = page([publication()])
        catalog.pop("metadata")
        catalog.pop("dataset_name")
        remote = Remote(catalog)
        self.assertEqual((await dashboard.dashboard_catalog(remote, {}))["rows"], [publication()])
        self.assertEqual(remote.calls[0][0], "list_dashboard_datasets")

    async def test_catalog_exposes_unavailable_publications_but_query_fails(self):
        """Keep unavailable publications discoverable without claiming usable source data."""
        unavailable = publication()
        unavailable["metadata"] = {"quality": "unavailable", "warnings": ["Source missing"]}
        catalog = page([unavailable])
        catalog.pop("metadata")
        catalog.pop("dataset_name")
        self.assertEqual((await dashboard.dashboard_catalog(Remote(catalog), {}))["rows"], [unavailable])
        query = page([])
        query["metadata"] = unavailable
        with self.assertRaises(DownloadError):
            await dashboard.dashboard_query(Remote(query), {"dataset_name": "DASHBOARD_SAMPLE"})

    async def test_non_ascii_schema_type_is_rejected(self):
        """Reject Unicode digits that are not SQL type syntax."""
        value = page([row()])
        value["metadata"]["schema"][-1][1] = "DECIMAL(2١,8)"
        with self.assertRaises(DownloadError):
            await dashboard.dashboard_query(Remote(value), {"dataset_name": "DASHBOARD_SAMPLE"})

    async def test_complete_csv_precision_null_quoting_and_metadata_only(self):
        """Publish all facts with exact numeric text, schema order and blank NULL cells."""
        remote = Remote(page([row()], True, " opaque "), page([row("2", VALUE=None)]))
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "facts.csv"
            result = await dashboard.download_dashboard(remote, {"dataset_name": "DASHBOARD_SAMPLE"}, output)
            with output.open(newline="") as handle:
                records = list(csv.reader(handle))
            self.assertEqual(records[0], [column for column, _ in SCHEMA])
            self.assertEqual(records[1], list(row().values()))
            self.assertEqual(records[2][-1], "")
            self.assertEqual(result["sha256"], hashlib.sha256(output.read_bytes()).hexdigest())
            self.assertEqual(result["row_count"], 2)
            self.assertEqual(result["page_count"], 2)
            self.assertEqual(result["schema"], SCHEMA)
            self.assertEqual(result["metadata"], publication())
            self.assertNotIn("rows", result)
            self.assertNotIn("cursor", json.dumps(result))
            self.assertIn("NULL", " ".join(result["warnings"]))
            self.assertEqual(remote.calls[1][1], {**remote.calls[0][1], "cursor": " opaque "})

    async def test_zero_rows_and_duplicate_facts(self):
        """Allow a terminal empty table and preserve identical facts on distinct keys."""
        for rows in ([], [row(), row("2")]):
            with self.subTest(rows=len(rows)), tempfile.TemporaryDirectory() as directory:
                response = page(rows)
                response["metadata"]["row_count"] = str(len(rows))
                result = await dashboard.download_dashboard(Remote(response), {"dataset_name": "DASHBOARD_SAMPLE"}, Path(directory) / "out.csv")
                self.assertEqual(result["row_count"], len(rows))

    async def test_malformed_envelopes_and_rows(self):
        """Reject malformed publication, wrong dataset, scalar damage and filter violations."""
        bad = []
        for field, value in (("dataset_name", "DASHBOARD_OTHER"), ("status", "data_gap"), ("error", {"message": "private"})):
            item = page([row()]); item[field] = value; bad.append(item)
        for replacement in (row("0"), row("9223372036854775808"), row("01"), row(VALUE=1.5),
                            row(NAME=[]), row(DAY="2026-02-30"), {"ROW_ID": "1"}):
            bad.append(page([replacement]))
        for field, value in (("schema", [["ROW_ID", "BIGINT"], ["row_id", "TEXT"]]),
                             ("schema", [["ROW_ID", "TEXT"]]), ("content_digest", "bad"),
                             ("refreshed_at", "bad"), ("row_count", "-1"), ("dataset_name", "DASHBOARD_OTHER")):
            item = page([row()]); item["metadata"][field] = value; bad.append(item)
        for item in bad:
            with self.subTest(item=item), self.assertRaises(DownloadError):
                await dashboard.dashboard_query(Remote(item), {"dataset_name": "DASHBOARD_SAMPLE"})
        for filters in ({"entity_column": "VALUE", "entity": "1"}, {"entity_column": "NAME", "entity": "absent"},
                        {"date_column": "NAME", "start": "2026-01-01"}, {"date_column": "DAY", "start": "2026-01-02"},
                        {"entity_column": "ROW_ID", "entity": "01"}, {"entity_column": "ROW_ID", "entity": "2"}):
            with self.subTest(filters=filters), self.assertRaises(DownloadError):
                await dashboard.dashboard_query(Remote(page([row()])), {"dataset_name": "DASHBOARD_SAMPLE", **filters})

    async def test_generation_key_cursor_and_page_budget_failures_retain_partial(self):
        """Never publish on generation changes, key regressions, loops or truncation."""
        cases = []
        for field, value in (("schema", SCHEMA + [["EXTRA", "TEXT"]]), ("content_digest", "b" * 64),
                             ("refreshed_at", "2026-01-02 12:00:00.000001")):
            second = page([row("2")]); second["metadata"][field] = value
            cases.append(([page([row()], True, "next"), second], 10))
        cases.extend([([page([row()], True, "next"), page([row()], False)], 10),
                      ([page([row()], True, "next"), page([row("2")], True, "next")], 10),
                      ([page([row()], True, "x" * 4097)], 10),
                      ([page([row()], True, "next")], 1)])
        for pages, maximum in cases:
            with self.subTest(pages=pages), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "out.csv"
                with self.assertRaises(DownloadError):
                    await dashboard.download_dashboard(Remote(*pages), {"dataset_name": "DASHBOARD_SAMPLE"}, output, max_pages=maximum)
                self.assertFalse(output.exists())
                self.assertEqual(len(list(Path(directory).glob("*.partial"))), 1)

    async def test_collision_and_symlink_never_fetch(self):
        """Refuse existing regular files and dangling symbolic links before network work."""
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "out.csv"
            output.write_text("keep")
            remote = Remote()
            with self.assertRaises(DownloadError):
                await dashboard.download_dashboard(remote, {"dataset_name": "DASHBOARD_SAMPLE"}, output)
            self.assertEqual(output.read_text(), "keep")
            output.unlink(); output.symlink_to("missing.csv")
            with self.assertRaises(DownloadError):
                await dashboard.download_dashboard(remote, {"dataset_name": "DASHBOARD_SAMPLE"}, output)
            self.assertEqual(remote.calls, [])

    async def test_shared_retry_budget_across_pages(self):
        """Spend a single 30-second retry allowance across the entire export."""
        first = {"error": {"code": "download_rate_limited", "category": "page_rate", "retry_after_seconds": 20}}
        second = {"error": {"code": "download_rate_limited", "category": "page_rate", "retry_after_seconds": 11}}
        remote = Remote(first, page([row()], True, "next"), second)
        with tempfile.TemporaryDirectory() as directory, patch("mcp_consumer.download.asyncio.sleep") as sleep:
            output = Path(directory) / "out.csv"
            with self.assertRaises(DownloadError):
                await dashboard.download_dashboard(remote, {"dataset_name": "DASHBOARD_SAMPLE"}, output)
            self.assertFalse(output.exists())
            self.assertEqual(sleep.await_count, 1)
            self.assertEqual(len(remote.calls), 3)
            self.assertEqual(remote.calls[0], remote.calls[1])

    async def test_atomic_publication_collision_retains_partial(self):
        """Refuse a destination created after the initial existence check."""
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "out.csv"
            response = page([row()])
            response["metadata"]["row_count"] = "1"
            remote = Remote(response)

            async def racing(tool, args):
                """Create the competing file while the response is in flight."""
                output.write_text("racing writer")
                return await remote(tool, args)

            with self.assertRaises(DownloadError):
                await dashboard.download_dashboard(racing, {"dataset_name": "DASHBOARD_SAMPLE"}, output)
            self.assertEqual(output.read_text(), "racing writer")
            self.assertEqual(len(list(Path(directory).glob("*.partial"))), 1)

    async def test_catalog_rejects_duplicates_wrong_search_and_bad_counts(self):
        """Validate bounded discovery rows as strictly as dataset publications."""
        for rows, arguments in (([publication(), publication()], {}), ([publication()], {"search": "absent"})):
            value = page(rows)
            value.pop("metadata")
            value.pop("dataset_name")
            with self.subTest(arguments=arguments), self.assertRaises(DownloadError):
                await dashboard.dashboard_catalog(Remote(value), arguments)
        value = page([row()])
        value["page"]["returned_count"] = 2
        with self.assertRaises(DownloadError):
            await dashboard.dashboard_query(Remote(value), {"dataset_name": "DASHBOARD_SAMPLE"})

    async def test_datetime_integer_entity_and_exact_bounds(self):
        """Accept inclusive timestamp windows and signed integer matching without coercion."""
        value = page([row("9223372036854775807", DAY="2026-01-01 23:59:59.999999")])
        value["metadata"]["schema"][2][1] = "DATETIME(6)"
        arguments = dict(dataset_name="DASHBOARD_SAMPLE", entity_column="ROW_ID", entity="9223372036854775807",
                         date_column="DAY", start="2026-01-01", end="2026-01-01")
        result = await dashboard.dashboard_query(Remote(value), arguments)
        self.assertEqual(result["rows"][0]["ROW_ID"], arguments["entity"])

    async def test_quota_retry_and_fail_closed_errors(self):
        """Use existing safe retry policy and never turn quota/data gaps into empty success."""
        transient = {"error": {"code": "download_rate_limited", "category": "page_rate", "retry_after_seconds": 0}}
        remote = Remote(transient, page([]))
        await dashboard.dashboard_query(remote, {"dataset_name": "DASHBOARD_SAMPLE"})
        self.assertEqual(len(remote.calls), 2)
        for value in ({"status": "data_gap"}, {"status": "error"},
                      {"error": {"code": "download_rate_limited", "category": "daily", "retry_after_seconds": 0}}):
            with self.subTest(value=value), self.assertRaises(DownloadError):
                await dashboard.dashboard_query(Remote(value), {"dataset_name": "DASHBOARD_SAMPLE"})
