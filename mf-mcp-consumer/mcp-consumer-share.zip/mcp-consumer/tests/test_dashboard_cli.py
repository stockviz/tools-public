"""Verify dashboard CLI and stdio adapters expose distinct bounded read/export operations."""
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from mcp_consumer.cli import parser, execute
from mcp_consumer.server import build_server


class DashboardCliTests(unittest.IsolatedAsyncioTestCase):
    """Keep bounded discovery/query separate from complete dynamic CSV downloads."""

    async def test_catalog_command_dispatches_one_page(self):
        """Forward opaque catalog continuation without interpreting it."""
        args = parser().parse_args(['dashboard-datasets', '--search', 'MF', '--page-size', '7', '--cursor', 'opaque'])
        args.url, args.state_dir = 'https://example.test/mcp', Path('state')
        with patch('mcp_consumer.cli.run_dashboard_catalog', new=AsyncMock(return_value={'status': 'ok'})) as run:
            await execute(args)
        self.assertEqual(run.await_args.args[2], {'search': 'MF', 'limit': 7, 'cursor': 'opaque'})

    async def test_query_command_dispatches_filters(self):
        """Return one bounded dataset page without writing files."""
        args = parser().parse_args(['dashboard-query', '--dataset-name', 'DASHBOARD_MF_RETURNS', '--entity-column', 'ENTITY', '--entity', '123', '--date-column', 'AS_OF', '--start', '2021-01-01', '--page-size', '2'])
        args.url, args.state_dir = 'https://example.test/mcp', Path('state')
        with patch('mcp_consumer.cli.run_dashboard_query', new=AsyncMock(return_value={'status': 'ok'})) as run:
            await execute(args)
        self.assertEqual(run.await_args.args[2]['dataset_name'], 'DASHBOARD_MF_RETURNS')
        self.assertEqual(run.await_args.args[2]['entity'], '123')
        self.assertEqual(run.await_args.args[2]['limit'], 2)

    async def test_export_command_dispatches_complete_download(self):
        """Keep cursor management inside the complete exporter."""
        args = parser().parse_args(['dashboard', '--dataset-name', 'DASHBOARD_ETF_REGRESSION', '--page-size', '2', '--max-pages', '9', '--output', 'result.csv'])
        args.url, args.state_dir = 'https://example.test/mcp', Path('state')
        with patch('mcp_consumer.cli.run_dashboard_download', new=AsyncMock(return_value={'status': 'complete'})) as run:
            await execute(args)
        self.assertEqual(run.await_args.args[3], Path('result.csv'))
        self.assertEqual(run.await_args.kwargs, {'max_pages': 9})
        self.assertNotIn('cursor', run.await_args.args[2])

    async def test_stdio_exposes_three_dashboard_tools(self):
        """Advertise bounded reads and one metadata-only file writer."""
        tools = {tool.name: tool for tool in await build_server('https://example.test/mcp', Path('state'), Path('exports')).list_tools()}
        for name in ('list_dashboard_datasets', 'query_dashboard_dataset', 'download_dashboard_dataset'):
            self.assertIn(name, tools)
        self.assertTrue(tools['query_dashboard_dataset'].annotations.readOnlyHint)
        self.assertFalse(tools['download_dashboard_dataset'].annotations.readOnlyHint)
        self.assertNotIn('cursor', tools['download_dashboard_dataset'].inputSchema['properties'])
