"""Verify shareable defaults and private deployment configuration."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from mcp_consumer.cli import parser, resolve_config
from mcp_consumer.download import DownloadError


class ConfigTests(unittest.TestCase):
    """Keep endpoints and user paths out of packaged source defaults."""

    def test_endpoint_is_required(self):
        """Do not contact the original author's service by default."""
        with self.assertRaises(DownloadError):
            resolve_config(parser().parse_args(['login']))

    def test_config_relative_paths_and_cli_overrides(self):
        """Resolve paths beside configuration, independent of Goose's working directory."""
        with tempfile.TemporaryDirectory() as tmp:
            config = Path(tmp) / 'config.json'
            config.write_text(json.dumps({'server_url':'https://mcp.example.com/mcp',
                                         'state_dir':'./private-state', 'output_dir':'./exports',
                                         'legacy_registration':True}))
            args = resolve_config(parser().parse_args(['--config',str(config),'serve']))
            self.assertEqual(args.url, 'https://mcp.example.com/mcp')
            self.assertEqual(args.state_dir, Path(tmp) / 'private-state')
            self.assertEqual(args.output_dir, Path(tmp) / 'exports')
            self.assertTrue(args.legacy_registration)
            args = resolve_config(parser().parse_args(['--config',str(config),'--url','https://override.example/mcp','login']))
            self.assertEqual(args.url, 'https://override.example/mcp')

    def test_config_rejects_unknown_fields_credentials_and_bad_types(self):
        """A public config schema must never silently accept embedded credentials."""
        for value in [{'server_url':'https://user:password@example.com/mcp'},
                      {'server_url':'https://mcp.example.com/mcp','access_token':'not-a-real-token'},
                      {'server_url':'https://mcp.example.com/mcp','legacy_registration':'false'},
                      {'server_url':'https://mcp.example.com/mcp','output_dir':5}]:
            with self.subTest(value=value), tempfile.TemporaryDirectory() as tmp:
                config = Path(tmp) / 'config.json'; config.write_text(json.dumps(value))
                with self.assertRaises(DownloadError):
                    resolve_config(parser().parse_args(['--config',str(config),'login']))

    def test_invalid_config_never_echoes_input(self):
        """Malformed JSON can contain sensitive text; do not include it in errors."""
        with tempfile.TemporaryDirectory() as tmp:
            config = Path(tmp) / 'config.json';config.write_text('private-value-invalid-json')
            with self.assertRaises(DownloadError) as error:
                resolve_config(parser().parse_args(['--config',str(config),'login']))
            self.assertNotIn('private-value', str(error.exception))


if __name__ == '__main__':
    unittest.main()
