"""Exercise an allowlisted share bundle rather than zipping a live working tree."""
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

from build_share import SHARE_FILES, build, publish


class ShareTests(unittest.TestCase):
    """Ensure private configuration and runtime files never enter the bundle."""

    def test_build_is_a_one_shot_command(self):
        """Do not expose a background watch mode for milestone publication."""
        script=Path(__file__).resolve().parents[1]/'build_share.py'
        result=subprocess.run([sys.executable,str(script),'--help'],capture_output=True,text=True)
        self.assertEqual(result.returncode,0)
        self.assertNotIn('--watch',result.stdout)

    def test_bundle_excludes_private_and_runtime_files(self):
        """Package source only even when sensitive-looking local artifacts exist."""
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'project';root.mkdir()
            for name in SHARE_FILES:
                (root / name).write_text('public source\n')
            for directory in ['mcp_consumer','tests','.venv','exports','.private-state']:
                (root / directory).mkdir()
            (root / 'mcp_consumer/__init__.py').write_text('')
            (root / 'tests/test_example.py').write_text('')
            for name in ['config.json','.env','.private-state/tokens.json','exports/private.csv','.venv/private']:
                (root / name).write_text('PRIVATE_SENTINEL')
            result = build(root, Path(tmp) / 'share.zip')
            with zipfile.ZipFile(result['path']) as archive:
                names=archive.namelist()
                self.assertTrue(names)
                self.assertIn('mcp-consumer/config.json', names)
                self.assertNotIn('mcp-consumer/.env', names)
                self.assertNotIn('mcp-consumer/config.example.json', names)
                self.assertFalse(any('PRIVATE_SENTINEL' in archive.read(name).decode() for name in names))
                self.assertTrue(all(name.startswith('mcp-consumer/') for name in names))

    def test_ready_config_is_generated_without_reading_operator_config(self):
        """Ship fixed public defaults even if local config is missing or unreadable."""
        expected = {'server_url': 'https://' + 'mutual-fund-mcp.stockviz' + '.workers.dev/mcp',
                    'output_dir': './exports'}
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in SHARE_FILES:
                (root / name).write_text('public source\n')
            private = root / 'config.json'
            for variant in ('missing', 'private', 'symlink'):
                with self.subTest(variant=variant):
                    private.unlink(missing_ok=True)
                    if variant == 'private':
                        private.write_text('PRIVATE_SENTINEL: not valid JSON')
                    elif variant == 'symlink':
                        private.symlink_to(root / 'absent-private-config')
                    result = build(root, root / 'share.zip')
                    with zipfile.ZipFile(result['path']) as archive:
                        self.assertNotIn('mcp-consumer/config.example.json', archive.namelist())
                        self.assertEqual(json.loads(archive.read('mcp-consumer/config.json')), expected)
                        extracted = root / 'clean-extraction'
                        archive.extractall(extracted)
                    from mcp_consumer.cli import parser, resolve_config
                    shipped = extracted / 'mcp-consumer/config.json'
                    args = resolve_config(parser().parse_args(['--config', str(shipped), 'serve']))
                    self.assertEqual(args.url, expected['server_url'])
                    self.assertFalse(hasattr(args, "legacy_registration"))
                    self.assertEqual(args.output_dir, shipped.parent / 'exports')
                    self.assertFalse(args.state_dir.is_relative_to(extracted))
                    custom = resolve_config(parser().parse_args([
                        '--config', str(shipped), '--url', 'https://other.example/mcp', 'login']))
                    self.assertEqual(custom.url, 'https://other.example/mcp')
                    self.assertFalse(hasattr(custom, "legacy_registration"))
                    if variant == 'private':
                        self.assertEqual(private.read_text(), 'PRIVATE_SENTINEL: not valid JSON')
                    elif variant == 'symlink':
                        self.assertTrue(private.is_symlink())

    def test_public_endpoint_exception_does_not_allow_other_hosts_or_url_suffixes(self):
        """The public endpoint exception is exact, not a deployment-host bypass."""
        endpoint = 'https://' + 'mutual-fund-mcp.stockviz' + '.workers.dev/mcp'
        blocked = ['https://' + 'private-service' + '.workers.dev/mcp',
                   endpoint + '?token=private', endpoint + '/private',
                   endpoint.replace('/mcp', '/admin'), endpoint.replace('https:', 'http:')]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name in SHARE_FILES:
                (root / name).write_text('public source\n')
            for value in blocked:
                with self.subTest(value=value):
                    (root / 'README.md').write_text(value)
                    with self.assertRaises(ValueError):
                        build(root, root / 'share.zip')
            (root / 'README.md').write_text('Endpoint: `' + endpoint + '`\n')
            build(root, root / 'share.zip')

    def test_publish_updates_zip_readme_and_preserves_unchanged_files(self):
        """Sync both public files only when their actual contents change."""
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'source';root.mkdir()
            for name in SHARE_FILES:
                (root/name).write_text('public source\n')
            public=Path(tmp)/'public'
            first=publish(root,public)
            self.assertTrue(first['public_zip_changed'])
            self.assertEqual((public/'README.md').read_text(),(root/'PUBLIC_README.md').read_text())
            original=(public/'mcp-consumer-share.zip').stat().st_mtime_ns
            second=publish(root,public)
            self.assertFalse(second['public_zip_changed'])
            self.assertFalse(second['public_readme_changed'])
            self.assertEqual((public/'mcp-consumer-share.zip').stat().st_mtime_ns,original)
            (root/'PUBLIC_README.md').write_text('updated public instructions\n')
            third=publish(root,public)
            self.assertTrue(third['public_zip_changed'])
            self.assertTrue(third['public_readme_changed'])
            self.assertNotEqual(first['sha256'],third['sha256'])

    def test_failed_scan_does_not_replace_last_good_publication(self):
        """A failed source scan leaves both previous public artifacts intact."""
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'source';root.mkdir()
            for name in SHARE_FILES:
                (root/name).write_text('public source\n')
            public=Path(tmp)/'public';publish(root,public)
            old_zip=(public/'mcp-consumer-share.zip').read_bytes()
            old_readme=(public/'README.md').read_bytes()
            (root/'PUBLIC_README.md').write_text('cd '+ '/'+'home/example-person/private')
            with self.assertRaises(ValueError):
                publish(root,public)
            self.assertEqual((public/'mcp-consumer-share.zip').read_bytes(),old_zip)
            self.assertEqual((public/'README.md').read_bytes(),old_readme)

    def test_personal_paths_fail_the_source_scan(self):
        """Fail closed when an allowlisted source file embeds a home-directory path."""
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for name in SHARE_FILES:
                (root/name).write_text('public source\n')
            (root/'README.md').write_text('cd ' + '/' + 'home/example-person/private-project')
            with self.assertRaises(ValueError):
                build(root,root/'share.zip')


if __name__ == '__main__':
    unittest.main()
