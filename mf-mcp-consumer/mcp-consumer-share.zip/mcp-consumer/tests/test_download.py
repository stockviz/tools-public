"""Exercise deterministic pagination, exact CSV output and fail-closed publication."""
import csv
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from mcp_consumer.download import DownloadError, download


class Pages:
    """Return scripted MCP pages while retaining exact submitted arguments."""

    def __init__(self, pages):
        """Keep responses independent of the downloader under test."""
        self.pages = iter(pages)
        self.calls = []

    async def __call__(self, name, arguments):
        """Represent the SDK's text-content response without an LLM."""
        self.calls.append((name, dict(arguments)))
        value = next(self.pages)
        if isinstance(value, Exception):
            raise value
        return SimpleNamespace(isError=False, structuredContent=None,
                               content=[SimpleNamespace(type="text", text=json.dumps(value))])


def nav(day="2025-01-01", auto_id="-9223372036854775808", value="123.45000000000001"):
    """Create explicit synthetic unit-test observations, not acceptance data."""
    return dict(scheme_code="105758", scheme_name='A, "Fund"\nGrowth', date=day,
                nav=value, auto_id=auto_id)


def page(rows, cursor=None, limit=2):
    """Match the service's documented page envelope."""
    return dict(status="ok", rows=rows,
                page=dict(limit=limit, returned_count=len(rows), has_more=cursor is not None,
                          next_cursor=cursor), metadata={"warnings": ["Not a consistent snapshot"]})


class DownloadTests(unittest.IsolatedAsyncioTestCase):
    """Verify that model-visible text never participates in the data path."""

    def setUp(self):
        """Keep artifacts isolated per test."""
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "nav.csv"
        self.args = dict(scheme_code="105758", limit=2, start="2025-01-01", end="2025-12-31")

    async def test_two_pages_preserve_cursor_and_decimal_strings(self):
        """Forward opaque tokens literally and retain same-date signed-ID ties."""
        token = 'opaque/token+with=padding'
        client = Pages([page([nav()], token), page([nav(auto_id="-9223372036854775807")])])
        result = await download(client, "get_nav_history", self.args, self.path)
        self.assertEqual(result["row_count"], 2)
        self.assertEqual(result["page_count"], 2)
        self.assertEqual(client.calls[1][1]["cursor"], token)
        self.assertEqual(client.calls[0][1]["format"], "json")
        self.assertEqual({k:v for k,v in client.calls[0][1].items() if k != "cursor"},
                         {k:v for k,v in client.calls[1][1].items() if k != "cursor"})
        with self.path.open(newline="") as handle:
            rows = list(csv.DictReader(handle))
        self.assertEqual(rows[0], nav())
        self.assertEqual(rows[1]["auto_id"], "-9223372036854775807")
        self.assertEqual(len(result["sha256"]), 64)
        self.assertEqual(result["status"], "complete")

    async def test_failure_never_publishes_final_file(self):
        """Retain only a clearly partial artifact after a remote failure."""
        client = Pages([page([nav()], "next"), RuntimeError("upstream secret")])
        with self.assertRaises(DownloadError) as error:
            await download(client, "get_nav_history", self.args, self.path)
        self.assertFalse(self.path.exists())
        self.assertNotIn("upstream secret", str(error.exception))
        self.assertTrue(list(self.path.parent.glob("*.partial")))

    async def test_repeated_cursor_rejected(self):
        """Stop loops even if the server returns fresh-looking rows."""
        client = Pages([page([nav()], "same"), page([nav("2025-01-02")], "same")])
        with self.assertRaises(DownloadError):
            await download(client, "get_nav_history", self.args, self.path)
        self.assertFalse(self.path.exists())

    async def test_bad_count_rejected(self):
        """Do not turn an inconsistent page into a successful CSV."""
        response = page([nav()]); response["page"]["returned_count"] = 9
        with self.assertRaises(DownloadError):
            await download(Pages([response]), "get_nav_history", self.args, self.path)

    async def test_wrong_series_and_out_of_window_rejected(self):
        """Bind every observation to the requested series and date bounds."""
        for row in [dict(nav(), scheme_code="other"), nav("2024-12-31")]:
            with self.subTest(row=row):
                with self.assertRaises(DownloadError):
                    await download(Pages([page([row])]), "get_nav_history", self.args, self.path)

    async def test_duplicate_key_rejected_not_silently_dropped(self):
        """Preserve genuine distinct ties but reject repeated exact keys."""
        with self.assertRaises(DownloadError):
            await download(Pages([page([nav(), nav()])]), "get_nav_history", self.args, self.path)

    async def test_existing_destination_untouched(self):
        """Refuse overwriting an earlier successful export."""
        self.path.write_text("existing")
        client = Pages([])
        with self.assertRaises(DownloadError):
            await download(client, "get_nav_history", self.args, self.path)
        self.assertEqual(self.path.read_text(), "existing")
        self.assertFalse(client.calls)

    async def test_empty_success_writes_header_with_explicit_zero_count(self):
        """A genuine empty server result differs from a failed empty substitute."""
        result = await download(Pages([page([])]), "get_nav_history", self.args, self.path)
        self.assertEqual(result["row_count"], 0)
        self.assertEqual(self.path.read_text().splitlines(), ["scheme_code,scheme_name,date,nav,auto_id"])

    async def test_unavailable_and_tool_errors_rejected(self):
        """Never convert service errors or data gaps into empty success."""
        response = page([]); response["status"] = "unavailable"
        with self.assertRaises(DownloadError):
            await download(Pages([response]), "get_nav_history", self.args, self.path)

    async def test_max_pages_is_a_failure_not_truncation(self):
        """A budget stop must leave no completed artifact."""
        with self.assertRaises(DownloadError):
            await download(Pages([page([nav()], "more")]), "get_nav_history", self.args,
                           self.path, max_pages=1)
        self.assertFalse(self.path.exists())

    async def test_tool_error_payload_is_not_exposed(self):
        """Return a safe failure even if a remote tool's error contains secrets."""
        async def call(name, arguments):
            """Simulate an untrusted upstream error envelope."""
            return SimpleNamespace(isError=True, content=[SimpleNamespace(type="text", text="secret-value")])
        with self.assertRaises(DownloadError) as error:
            await download(call, "get_nav_history", self.args, self.path)
        self.assertNotIn("secret-value", str(error.exception))
        self.assertFalse(self.path.exists())

    async def test_structured_content_is_supported(self):
        """Read modern structured MCP results without text extraction."""
        async def call(name, arguments):
            """Represent a structured SDK response."""
            return SimpleNamespace(isError=False, structuredContent=page([nav()]), content=[])
        result = await download(call, "get_nav_history", self.args, self.path)
        self.assertEqual(result["row_count"], 1)

    async def test_bad_page_flags_and_numeric_float_rejected(self):
        """Reject ambiguous envelopes and numeric precision already lost upstream."""
        variants = []
        value = page([nav()]); value["page"]["has_more"] = "false"; variants.append(value)
        value = page([nav()]); value["page"]["limit"] = 1; variants.append(value)
        value = page([nav()]); value["page"]["next_cursor"] = "unexpected"; variants.append(value)
        variants.append(page([dict(nav(), nav=1.2)]))
        variants.append(page([nav(auto_id="9223372036854775808")]))
        for value in variants:
            with self.subTest(value=value):
                with self.assertRaises(DownloadError):
                    await download(Pages([value]), "get_nav_history", self.args, self.path)
                self.assertFalse(self.path.exists())

    async def test_completed_export_does_not_claim_to_be_a_partial_page(self):
        """Drop only the obsolete per-page warning after all pages are assembled."""
        value = page([nav()])
        value["metadata"]["warnings"] = ["This is a partial history page, not the entire requested window.", "Mirror ownership is not freshness"]
        result = await download(Pages([value]), "get_nav_history", self.args, self.path)
        self.assertFalse(any(item.startswith("This is a partial history page,") for item in result["warnings"]))
        self.assertIn("Mirror ownership is not freshness", result["warnings"])

    async def test_index_export(self):
        """Keep index names and closing-price strings unchanged."""
        row = dict(index_name="NIFTY SMALLCAP 250 TR", date="2025-01-01", close="12345.6700")
        result = await download(Pages([page([row])]), "get_index_history",
                                dict(index_name=row["index_name"], limit=2), self.path)
        self.assertEqual(result["row_count"], 1)
        with self.path.open(newline="") as handle:
            self.assertEqual(list(csv.DictReader(handle)), [row])

    async def test_invalid_requests_rejected_before_io(self):
        """Validate immutable filters before creating files or calling the server."""
        for args in [dict(self.args, limit=0), dict(self.args, end="2024-01-01"),
                     dict(self.args, start="2025-02-30"), dict(self.args, cursor="resume"),
                     dict(self.args, scheme_code="105758;DROP")]:
            with self.subTest(args=args):
                client = Pages([])
                with self.assertRaises(DownloadError):
                    await download(client, "get_nav_history", args, self.path)
                self.assertFalse(client.calls)


if __name__ == "__main__":
    unittest.main()
