# MCP history CSV consumer

Download complete NAV and index histories to local CSV files without copying
rows or pagination cursors through a language model. The package provides a CLI
and a local stdio MCP extension for Goose and other MCP clients.

## Why this exists

A large tool response visible in a conversation is not automatically a local
file that a shell can read. Some harnesses save large responses to temporary
files, but that behavior can differ between pages. Copying rows or opaque
cursors through model-generated text can corrupt the download.

This consumer receives responses through the MCP SDK, writes each page and
passes the original cursor directly to the next request. The model supplies the
initial series, dates and filename; it receives only the completed file's path,
counts and checksum.

The server must expose the compatible `get_nav_history` and `get_index_history`
contracts described below and authorize `research:read`. This is not a universal
exporter for arbitrary MCP tools. The consumer does not connect to a database or
write data back to the remote service.

## Install and configure

Use Python 3.11 or later on Linux/macOS. The credential store uses POSIX ownership
and permission checks. Install on the machine where the files should live.
Replace `/path/to/mcp-consumer` and `<PROJECT_DIR>` below with your installation
location. They are placeholders, not paths to the original author's machine.

```sh
cd /path/to/mcp-consumer
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python -m pip install -e .
cp config.example.json config.json
```

Edit your local `config.json` before connecting:

```json
{
  "server_url": "https://mcp.example.com/mcp",
  "state_dir": "./.private-state",
  "output_dir": "./exports",
  "legacy_registration": false
}
```

`mcp.example.com` is a placeholder. Obtain the actual endpoint from your server
operator. There is no built-in production endpoint and no shared account.

Configuration fields:

- `server_url`: HTTPS MCP endpoint. Local testing also permits loopback HTTP.
  Embedded URL credentials, query strings and fragments are rejected.
- `state_dir`: your private OAuth cache. Relative paths resolve beside the
  config file; `~` expands to your own home directory. If omitted, the program
  derives a per-user state directory at runtime.
- `output_dir`: the directory where the local MCP extension may create CSVs.
  Relative paths resolve beside the config file, not Goose's working directory.
- `legacy_registration`: normally `false`. Enable only if your server operator
  confirms the legacy registration behavior described below.

Only these fields are accepted. Do not put tokens, passwords or client secrets
in configuration. `config.json` is ignored by Git and excluded from share bundles.
Global `--url`, `--state-dir` and
`--legacy-registration`/`--no-legacy-registration` options go before the
subcommand and override configuration. The `serve --output-dir` option goes
after `serve`. You may also omit `--config` and
supply `--url` explicitly; `serve` then needs `--output-dir`.

## Authorize your own account

```sh
.venv/bin/stockviz-mcp-consumer --config config.json login
```

Complete browser authorization on the same machine. Each user authorizes their
own account; the program does not read Goose's or Hermes's credential caches.
It requests only `research:read`. OAuth directories use mode 0700 and files use
mode 0600. Never share that cache or paste credentials into a conversation.

Downloads do not open a login flow. If authorization expires and the server
cannot refresh it, run `login` again in a terminal.

Some legacy servers return a public client ID with an empty `redirect_uris`
array. For those servers only, set `legacy_registration` to `true`. The adapter
calls the configured origin's `/oauth/register`, uses the actually returned ID
and configures the SDK with the redirect metadata this client requested. It does
not rewrite server responses, invent an ID or bypass PKCE/state validation.
Standard SDK registration is the default; no deployment hostname is hard-coded.

## CLI downloads

Replace the angle-bracket placeholders with a real scheme code or exact index
name from your server's catalog.

```sh
.venv/bin/stockviz-mcp-consumer --config config.json nav \
  --scheme-code '<SCHEME_CODE>' \
  --start 2020-01-01 --end 2025-12-31 \
  --output ./exports/fund.csv

.venv/bin/stockviz-mcp-consumer --config config.json index \
  --index-name '<EXACT_INDEX_NAME>' \
  --start 2020-01-01 \
  --output ./exports/index.csv
```

Date bounds are inclusive. Omit `--start` for available history and `--end` for
latest available observations. Returned first/last dates are observed dates.
`--output` is an explicit local path, relative to the CLI's working directory.

Page size defaults to 1,000; `--page-size` accepts 1 through 1,000 and stays fixed
throughout a download. `--max-pages` defaults to 10,000. Exceeding it is an error,
not successful truncation. This version does not resume partial downloads.

Success prints a small JSON report with `status: complete`, absolute `path`,
`row_count`, `page_count`, observed dates, SHA-256, source URL, filters and data
warnings. This runtime report can contain your local paths and endpoint: review
it before sharing. A genuine empty server result creates a header-only CSV with
an explicit zero count. Errors return nonzero and do not publish a completed CSV.

## Add to Goose

Run `login` first under the OS account that will run the extension. Use
`goose configure` → `Add Extension` → `Command-line Extension`, or add a custom
stdio extension in Goose Desktop. Use this command, replacing both placeholders:

```text
<PROJECT_DIR>/.venv/bin/stockviz-mcp-consumer --config <PROJECT_DIR>/config.json serve
```

The configured `output_dir` limits where the model can write. Start with a tool
timeout of 300 seconds; longer downloads may need a larger timeout. Do not put
OAuth tokens into Goose's extension settings.

The extension exposes:

- `download_nav_history(scheme_code, filename, start, end, page_size, max_pages)`
- `download_index_history(index_name, filename, start, end, page_size, max_pages)`

The series identifier and filename are required; dates are optional. The model
cannot supply a cursor. Filenames must be CSV basenames such as `fund.csv`,
without directories. Existing files and symlinks are never replaced.

Ask Goose to use the local downloader and report its path/count/checksum rather
than copying remote page results through the conversation. Goose's shell and the
extension must share the filesystem. A path on an SSH host or inside a container
is not automatically accessible from the desktop host.

These tools write local files and are not marked read-only, although their remote
calls only read market data. Goose configuration is not modified automatically.

Extension reference:
https://block.github.io/goose/docs/getting-started/using-extensions

## Data and failure guarantees

The consumer requests JSON rows and writes UTF-8 CSV with CRLF record endings.
It quotes commas, quotes and embedded newlines. Numeric strings never pass
through floats. SQL nulls become empty fields.

NAV columns: `scheme_code,scheme_name,date,nav,auto_id`.
Index columns: `index_name,date,close`.

For each page it checks status, counts, size, series identity and dates. NAV keys
must increase by `(date, signed AUTO_ID)`; index dates must increase. Distinct
same-date NAV rows are retained; repeated exact keys and cursors fail rather
than being silently deduplicated. Cursor strings are never trimmed or repaired.

The consumer writes a uniquely named `*.partial` file, flushes it, reads back its
header and row count, and computes SHA-256 before publishing. A same-directory
hard link atomically refuses an existing destination. The filesystem must support
hard links. On failure, the clearly named partial file remains incomplete; fix
the cause and restart from the beginning.

These checks verify received pages, not independent database reconciliation.
A server mirror refresh can change data between pages; restart after a refresh
when snapshot consistency matters. Raw NAV is not distribution-adjusted or a
total-return series. Use server-side metric tools for summaries when available.

## Test and share

```sh
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python build_share.py
```

The build runs the offline tests and scans a stable source snapshot before
publishing. It creates `dist/mcp-consumer-share.zip` from an explicit source
allowlist. It includes this README, public usage instructions, package metadata,
dependency lock, example configuration, source and tests. It excludes local
configuration, `.venv`, OAuth
caches, exports, logs, bytecode, package-install metadata and other runtime files.
It also rejects recognizable personal directory paths, deployment hostnames and
common credential formats in selected source files. This is a guardrail, not a
guarantee that every possible secret format can be recognized.

Share that ZIP, not your entire working directory. `.gitignore` is not a privacy
filter for an arbitrary ZIP or copied directory. Recipients must create their
own environment, configure their endpoint and complete their own login. Runtime
files deliberately remain local; a virtual environment contains absolute paths
and must not be distributed.

## Milestone publication for maintainers

To copy the ZIP and a usage README to a distribution directory, create an ignored
`build.local.json` in the source project. Replace this example destination with
your own location:

```json
{
  "publish_dir": "../public/mf-mcp-consumer"
}
```

Run `.venv/bin/python build_share.py`. When the local build configuration exists,
each build also updates `mcp-consumer-share.zip` and `README.md` in that directory.
The public README comes from `PUBLIC_README.md` in the source project. Edit that
source file, not its generated public copy. `--publish-dir` overrides the local
setting; without either setting the build only writes local `dist` output.

Run the script after completing a milestone. It runs once and exits; source
edits alone do not publish anything. There is no watcher, daemon or background
service.

Tests and privacy scans must pass; otherwise the last good public release stays
in place. A source edit during verification also skips that build rather than
publishing an untested snapshot. The ZIP and README are each replaced atomically,
and unchanged content is not rewritten. The pair is not a filesystem transaction.

The local publication path remains excluded from the shared ZIP.

Tests use explicitly synthetic data and dummy token strings, not real credentials
or user records. Offline correctness and live service integration are separate
gates. Exports and environment-specific acceptance records are not distributed.
