# MCP history CSV consumer

Download complete NAV, index and raw equity histories to local CSV files without copying
rows or pagination cursors through a language model. The package provides a CLI
and a local stdio MCP extension for Goose and other MCP clients.

## Release 0.2.0: mixed authentication and refresh

The StockViz server permits public handshake and tool discovery. Discovery alone
is not authentication. This release makes `login` exercise the protected tool-call
boundary and check its own persisted OAuth credentials before reporting success.
The login probe requests no history rows.

New production access tokens last 24 hours. The server also issues a rotating
refresh token with a 30-day absolute lifetime. The consumer refreshes access when
its saved expiry requires it and persists the replacement refresh token. It also
keeps discovered OAuth endpoint metadata privately, so a restarted process uses
the correct token endpoint. Activity
and rotation do not extend the original refresh deadline. Previously issued
access tokens keep their original expiry.

An older cache may contain only an access token. Its next expiry then requires
a browser login before automatic refresh becomes available. To reauthorize
immediately, select a new private `--state-dir` for login and keep that same
state directory for later commands/Goose; a still-valid cached access token does
not force a fresh login. After obtaining a refresh credential, CLI downloads and
the stdio extension refresh noninteractively. Rejected refresh credentials are
removed from this cache; run `login` again. Discovery success alone does not
remove the authentication requirement.

Keep one operation at a time for a shared OAuth cache. Refresh tokens are single
use: concurrent refreshes or retrying an already-consumed token can revoke the
whole refresh family. Do not copy or share the cache, force retries, or place
credentials in config files. Revoking a refresh family does not invalidate
already-issued access tokens before their own expiry.

To upgrade, extract the new ZIP into a clean directory and follow the install
commands below. Point Goose at the newly installed executable. Keep your own
existing private config/cache if appropriate; do not copy someone else's state.

## Why this exists

A large tool response visible in a conversation is not automatically a local
file that a shell can read. Some harnesses save large responses to temporary
files, but that behavior can differ between pages. Copying rows or opaque
cursors through model-generated text can corrupt the download.

This consumer receives responses through the MCP SDK, writes each page and
passes the original cursor directly to the next request. The model supplies the
initial series, dates and filename; it receives only the completed file's path,
counts and checksum.

The server must expose the compatible `get_nav_history`, `get_index_history`,
`get_equity_history` and `list_equities`
contracts described below and authorize `research:read`. This is not a universal
exporter for arbitrary MCP tools. The consumer does not connect to a database or
write data back to the remote service.

## Install and configure

Use Python 3.11 or later on Linux/macOS (POSIX). Install on the same machine
and under the same OS account that will run Goose and own the CSV files. In a
terminal, start in the directory containing the downloaded ZIP:

```sh
unzip mcp-consumer-share.zip
cd mcp-consumer
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python -m pip install -e .
```

The ZIP has one outer project folder, `mcp-consumer/` (hyphen). Its child
`mcp_consumer/` (underscore) is the Python package, not the installation root.
Run the remaining terminal commands from the outer folder, which contains
`pyproject.toml` and `config.json`. If you already extracted the ZIP, open that
folder rather than extracting again. The ZIP deliberately excludes `.venv`;
installation creates `.venv/bin/stockviz-mcp-consumer`. Use this same environment
for login and Goose. Do not point Goose at a virtual environment from another
machine or a directory you later move.

The distribution includes a ready-to-use `config.json` for the public StockViz
PortfolioManagerMf service. You do not need to copy or edit it before login:

```json
{
  "server_url": "https://mutual-fund-mcp.stockviz.workers.dev/mcp",
  "output_dir": "./exports"
}
```

Each user must authorize their own account. The shipped config omits `state_dir`,
so OAuth uses your per-user home state directory. Relative output paths resolve
beside the config file. To use another compatible service, edit `server_url` or
pass `--url`. Standard OAuth client registration is used by default.

Configuration fields:

- `server_url`: HTTPS MCP endpoint. Local testing also permits loopback HTTP.
  Embedded URL credentials, query strings and fragments are rejected.
- `state_dir`: your private OAuth cache. Relative paths resolve beside the
  config file; `~` expands to your own home directory. If omitted, the program
  derives a per-user state directory at runtime.
- `output_dir`: the directory where the local MCP extension may create CSVs.
  Relative paths resolve beside the config file, not Goose's working directory.

Only these fields are accepted. Do not put tokens, passwords or client secrets
in configuration. Your local `config.json` stays ignored by Git. The builder never
reads or copies it: it generates the shipped `config.json` from fixed public defaults.
Global `--url` and `--state-dir` options go before the subcommand and override
configuration. The `serve --output-dir` option goes
after `serve`. You may also omit `--config` and
supply `--url` explicitly; `serve` then needs `--output-dir`.

## Authorize your own account

StockViz PortfolioManagerMf uses standard SDK OAuth client registration. Sign in
directly with the shipped config:

```sh
.venv/bin/stockviz-mcp-consumer --config config.json login
```

Complete browser authorization on the same machine. Each user authorizes their
own account; the program does not read Goose's or Hermes's credential caches.
It requests only `research:read`. OAuth directories use mode 0700 and files use
mode 0600. Never share that cache or paste credentials into a conversation.

Downloads do not open a login flow. If authorization expires and the server
cannot refresh it, run `login` again in a terminal.

The SDK handles OAuth registration and reuses this consumer's cached credentials.
The endpoint comes from config or `--url`, not a hard-coded client runtime default.

## CLI downloads

Replace the angle-bracket placeholders with a real scheme code or exact index
name from your server's catalog.

```sh
.venv/bin/stockviz-mcp-consumer --config config.json nav \
  --scheme-code '<SCHEME_CODE>' \
  --start 2020-01-01 --end 2025-12-31 \
  --output ./exports/fund.csv

.venv/bin/stockviz-mcp-consumer --config config.json index \
  --index-name '<EXACT_INDEX_NAME>' \
  --start 2020-01-01 \
  --output ./exports/index.csv
```

Date bounds are inclusive. Omit `--start` for available history and `--end` for
latest available observations. Returned first/last dates are observed dates.
`--output` is an explicit local path, relative to the CLI's working directory.

Page size defaults to 1,000; `--page-size` accepts 1 through 1,000 and stays fixed
throughout a download. `--max-pages` defaults to 10,000. Exceeding it is an error,
not successful truncation. This version does not resume partial downloads.

### Equity catalog and export

```sh
.venv/bin/stockviz-mcp-consumer --config config.json equities \
  --search RELIANCE --series EQ --page-size 2

.venv/bin/stockviz-mcp-consumer --config config.json equity \
  --symbol RELIANCE --series EQ \
  --start 2026-10-19 --end 2026-10-22 --page-size 2 \
  --output ./exports/reliance-eq.csv
```

`equities` returns one catalog page with symbol/series, first/last dates and source
observation counts. Optional `--cursor` forwards the returned token literally;
keep search, series and page size unchanged. The default catalog page size is
250 (maximum 1,000). A symbol can have several series; never infer EQ from symbol
alone. History export handles all cursors internally and returns metadata only.
Broad catalogs may scan the whole date-indexed source and time out even with a
small page size. Prefer narrow, inclusive history dates. Catalog and equity
history use the same remote account quotas as NAV/index reads and the same fixed
retry policy below; switching tools or processes does not bypass those quotas.

### Server safeguards and retries

Recognized structured MCP errors may arrive as JSON text or `structuredContent`.
The consumer retries only explicit transient `concurrency`, `page_rate`, and
`policy_unavailable` failures with a valid nonnegative `retry_after_seconds`.
There are at most **three attempts per page** and **30 seconds of retry waiting
per complete export**, shared across all pages. These limits are fixed; no
configuration or tool parameters increase them. Each retry sends the same
filters and exact opaque cursor; failed attempts do not count as pages.

A surfaced SDK HTTP 429 is retried only when it supplies a valid `Retry-After`
(integer seconds or an HTTP date), under the same limits. Authentication errors,
query timeouts, unknown failures and malformed retry hints are not retried.
SDK exceptions and arbitrary remote error messages are never echoed. The exact
plain-text MCP error `MariaDB read unavailable (PROTOCOL_SEQUENCE_TIMEOUT)` is
reported as `code=query_timeout, category=query_timeout` rather than invalid JSON.
It stops immediately without an automatic retry or a completed CSV.

Long waits (for example, 300 seconds), daily quotas, exhausted attempts or an
exhausted wait budget stop without publishing a completed CSV. Diagnostics
include recognized code/category, validated retry delay/reset time and the
retained partial-file path. Unknown categories are reported as `unknown` and
never retried. Fix the cause or wait until the reported reset before explicitly
starting a new export; partial files cannot be resumed automatically.

The stdio extension shares two whole-export slots across all three download tools.
Additional calls queue before opening their download sessions; slots remain held
through page retries and are released on success, failure or cancellation.
Cancellation propagates rather than becoming a retry or success, and an active
export's incomplete bytes remain partial. Separate CLI/server processes do not
share this queue and remain subject to the remote server's limits. Queued time,
network time and filesystem work are not part of the retry-wait budget; configure
client tool timeouts accordingly.

Success prints a small JSON report with `status: complete`, absolute `path`,
`row_count`, `page_count`, observed dates, SHA-256, source URL, filters and data
warnings. This runtime report can contain your local paths and endpoint: review
it before sharing. A genuine empty server result creates a header-only CSV with
an explicit zero count. Errors return nonzero and do not publish a completed CSV.

## Add to Goose

Run `login` first on this machine under the OS account that runs Goose. From
the outer `mcp-consumer/` project folder, generate a command with absolute paths
and the quoting Goose needs, including when your installation path has spaces:

```sh
GOOSE_COMMAND="$(.venv/bin/python - <<'PY'
from pathlib import Path
import shlex

root = Path.cwd().resolve()
executable = root / ".venv/bin/stockviz-mcp-consumer"
config = root / "config.json"
if not executable.is_file() or not config.is_file():
    raise SystemExit("Run this from the installed project root after pip install -e .")
print(shlex.join([str(executable), "--config", str(config), "serve"]))
PY
)"
printf '%s\n' "$GOOSE_COMMAND"
goose session --with-extension "$GOOSE_COMMAND"
```

The last line starts a Goose CLI session with the local extension. For a
persistent setup, run `goose configure` → `Add Extension` → `Command-line
Extension`. Paste the **entire printed line**, including its quotes, into the
command field. In Goose Desktop, add a custom STDIO extension and paste that
same line into **Command**. Set the timeout to **300 seconds** initially and
leave environment variables empty. Longer or queued downloads may need a larger
timeout. Do not enter the remote HTTP MCP URL for this local downloader.

Goose does not expand placeholders, `~`, or shell variables in a pasted Command.
Paste the printed absolute command, not `$GOOSE_COMMAND` or the generator above.
Keep its quotes: an unquoted path containing spaces can produce "Failed to start
extension" or "No such file or directory". If a file is missing, check that you
installed from the outer project folder and that both the executable and
`config.json` still exist at the printed paths. After moving the project,
recreate `.venv` with the install steps and generate the command again.

Running the printed `serve` command manually normally stays quiet while waiting
for MCP messages on stdin; this is not a hung download. Press Ctrl-C to stop it,
then let Goose launch it. The configured `output_dir` resolves beside
`config.json`, independent of Goose's working directory; the default is the
project's `exports/`. Do not put OAuth tokens in Goose's settings.

The extension exposes:

- `download_nav_history(scheme_code, filename, start, end, page_size, max_pages)`
- `download_index_history(index_name, filename, start, end, page_size, max_pages)`
- `download_equity_history(symbol, series, filename, start, end, page_size, max_pages)`
- `list_equities(search, series, limit, cursor)` reads one bounded catalog page;
  optional search is a literal case-insensitive symbol substring, series is exact.

The series identifier and filename are required; dates are optional. The model
cannot supply a history cursor. Catalog continuation accepts the exact returned
cursor with unchanged search, series and limit. Filenames must be CSV basenames such as `fund.csv`,
without directories. Existing files and symlinks are never replaced.

Ask Goose to use the local downloader and report its path/count/checksum rather
than copying remote page results through the conversation. Goose's shell and the
extension must share the filesystem. A path on an SSH host or inside a container
is not automatically accessible from the desktop host.

These tools write local files and are not marked read-only, although their remote
calls only read market data. Goose configuration is not modified automatically.


### Ask Goose to use the downloader

Enable the extension in the current session. After adding it permanently, start
a new session if its tools are not available. Name the local tool explicitly,
especially if you also enabled the remote StockViz MCP extension. Remote
`get_equity_history` returns one page; local `download_equity_history` saves the
complete requested history and returns file metadata.

Paste any of these prompts into Goose. They are chat prompts, not shell commands.
Use a new filename each time: the downloader never overwrites an existing file.

#### Check that the tools are available

```text
Show me the available tools from the local StockViz CSV downloader extension.
Confirm that download_nav_history, download_index_history,
download_equity_history and list_equities are available. Do not download yet.
```

#### Download a short equity window

```text
Use the local download_equity_history tool for symbol "RELIANCE", series "EQ",
start "2026-10-19", end "2026-10-22", filename "reliance-eq-window.csv",
and page_size 2. Let the tool handle every page. Return the completed path,
row count, page count and SHA-256; do not copy history rows into chat.
```

#### Discover an equity before downloading

```text
Use the local list_equities tool with search "RELIANCE", series "EQ" and limit 10.
Show the returned symbol/series pairs and date coverage. Do not assume the
catalog is complete if has_more is true, and do not download anything yet.
```

Catalog lookups can time out even with a small limit. For history downloads,
always use an explicit symbol and series; do not guess a series from the symbol.

#### Download a mutual fund's NAV

```text
Use the local download_nav_history tool for scheme_code "103734",
filename "quantum-liquid-nav.csv" and start "2020-01-01". Omit end to use
available observations through the latest stored date. Return only the completed
file metadata and any data warnings, not the NAV rows or pagination tokens.
```

Use the exact scheme code for the intended plan/option. This downloader does not
resolve fund names or choose between Direct, Regular, Growth and distribution
options.

#### Download an index

```text
Use the local download_index_history tool for index_name "NIFTY SMALLCAP 250 TR",
filename "smallcap250-tr-2021.csv", start "2021-01-04" and end "2021-01-08".
Return the saved path, row count, actual first/last dates and SHA-256.
Do not substitute a similarly named price-return index.
```

Use an exact index catalog name. The local extension has no index-catalog tool;
obtain the name from the remote server's catalog if you do not know it.

#### Download available equity history

```text
Use the local download_equity_history tool for symbol "RELIANCE", series "EQ"
and filename "reliance-eq-available.csv". Omit start and end to request all
available observations. Return the completed metadata and warnings only.
If a quota, timeout or page-budget error occurs, report the failure and partial
file path; do not describe an incomplete export as complete.
```

Full-history requests can take longer and hit remote quotas. Start with a short
window to check the setup. Increasing Goose's timeout does not increase the
server's quotas or the downloader's retry/page budgets.

#### Compare two saved CSVs

```text
Use the local download_nav_history tool to save scheme_code "103734" as
"quantum-liquid-2021.csv", and download_index_history to save index_name
"NIFTY SMALLCAP 250 TR" as "smallcap250-tr-compare-2021.csv". For both, use
start "2021-01-04" and end "2021-01-08". Return both completed file reports.
Do not calculate returns from partial tool pages or invent missing observations.
```

Any later analysis must open the completed CSVs using a separate file-reading or
analysis tool. These download tools only save files; they do not calculate
performance. NAV is not distribution-adjusted, and raw equity prices are not
corporate-action-adjusted.

### Files and troubleshooting

Supply CSV basenames such as `fund.csv`, not `exports/fund.csv` or an absolute
path. Files go into the configured `output_dir`, by default `exports/` beside
`config.json`. Goose can access them only if it shares that filesystem.

If Goose cannot find a tool, check that this local STDIO extension is enabled in
the current session and started without errors, then start a new session. If it
calls the remote paginated tool instead, repeat the exact local `download_*`
name. For authorization failures, rerun the documented `login` command in a
terminal under the same OS account; downloads do not open browser login.
For an existing-file error, choose a new filename. For timeouts or quota errors,
report the failure and follow the documented retry guidance instead of claiming
success.

## Data and failure guarantees

The consumer requests JSON rows and writes UTF-8 CSV with CRLF record endings.
It quotes commas, quotes and embedded newlines. Numeric strings never pass
through floats. SQL nulls become empty fields. Equity `num_transactions` may be a native
signed SQL integer; the CSV writer preserves it as integer text.

NAV columns: `scheme_code,scheme_name,date,nav,auto_id`.
Index columns: `index_name,date,close`.
Equity columns, in order:
`symbol,series,date,open,high,low,close,last,previous_close,total_traded_quantity,total_traded_value,num_transactions`.

Equity identity requires both symbol and series. Values are raw stored OHLC and
activity, not adjusted prices or total returns. Nullable fields become empty CSV
cells. DOUBLE strings preserve the database's textual representation, not invented
arbitrary precision. Equity dates must strictly increase; duplicate date groups
return `data_gap` on the server, including lookahead duplicates. Any failed page
leaves only a partial file, even if earlier pages succeeded. Mirror ownership does
not establish freshness. There is no equity summary tool: require every history
page to succeed before deriving a window summary. Completed exports remove only
the obsolete per-page partial-history warning and retain source/freshness caveats.

For each page it checks status, counts, size, series identity and dates. NAV keys
must increase by `(date, signed AUTO_ID)`; index dates must increase. Distinct
same-date NAV rows are retained; repeated exact keys and cursors fail rather
than being silently deduplicated. Cursor strings are never trimmed or repaired.

The consumer writes a uniquely named `*.partial` file, flushes it, reads back its
header and row count, and computes SHA-256 before publishing. A same-directory
hard link atomically refuses an existing destination. The filesystem must support
hard links. On failure, the clearly named partial file remains incomplete; fix
the cause and restart from the beginning.

These checks verify received pages, not independent database reconciliation.
A server mirror refresh can change data between pages; restart after a refresh
when snapshot consistency matters. Raw NAV is not distribution-adjusted or a
total-return series. Use server-side metric tools for summaries when available.

## Test and share

Install the build tools once before running the offline installation regression.
It creates a fresh virtual environment from an extracted source ZIP, reuses the
test environment's dependencies without network access, installs the package,
and initializes stdio from an unrelated directory with spaces in its path.
It executes the Goose command generator from both shipped READMEs.

```sh
.venv/bin/python -m pip install 'setuptools>=68' wheel
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python build_share.py
```

The build runs the offline tests and scans a stable source snapshot before
publishing. It creates `dist/mcp-consumer-share.zip` from an explicit source
allowlist. It includes this README, public usage instructions, package metadata,
dependency lock, generated public `config.json`, source and tests. It excludes
operator configuration, `.venv`, OAuth
caches, exports, logs, bytecode, package-install metadata and other runtime files.
It also rejects recognizable personal directory paths, deployment hostnames and
common credential formats in selected source files. Only the exact public service
URL shown above is allowlisted; other deployment URLs remain blocked. This is a
guardrail, not a guarantee that every possible secret format can be recognized.

Share that ZIP, not your entire working directory. `.gitignore` is not a privacy
filter for an arbitrary ZIP or copied directory. Recipients must create their
own environment and complete their own login; the shipped endpoint is ready to
use. Runtime files deliberately remain local; a virtual environment contains absolute paths
and must not be distributed.

## Feature integration tests

Run the local feature workflows independently:

```sh
.venv/bin/python -m unittest discover -s tests -p test_feature_workflows.py -v
.venv/bin/python -m unittest discover -s tests -p 'test_equity*.py' -v
```

These tests launch real CLI and stdio subprocesses and a temporary loopback HTTP
MCP server. They exercise the actual SDK, OAuth-cache reads, downloader, and CSV
filesystem publication without patching those components. The remote history data
and bearer token are explicitly synthetic. This is consumer integration coverage,
not proof of the Cloudflare Worker, native MariaDB, or an external OAuth provider.
The fixture server shuts down when the suite exits; no background service remains.

Coverage includes complete NAV/index pagination, inclusive dates, exact bigint and
decimal strings, CSV quoting and nulls, a six-instrument parallel comparison,
metadata-only stdio results, path confinement, existing-file protection, missing
authorization, second-page failures, invalid continuation progress, cross-instrument
rows, page budgets, and successful empty histories.

Live acceptance is a separate opt-in gate. Sign in with this consumer first, then
replace `PATH_TO_PRIVATE_CONFIG` with your private config path:

```sh
MCP_E2E_CONFIG=PATH_TO_PRIVATE_CONFIG .venv/bin/python -m unittest discover -s tests -p test_live_features.py -v
```

The live tests compare an independent SDK pagination walk with real CLI and stdio
exports for NAV, index and equity history. They use a short date window and page size two
to exercise continuation without downloading full histories. They do not mutate
server data; authentication can update this consumer's private token cache.
Without `MCP_E2E_CONFIG`, default discovery explicitly skips these three tests. Once
selected, connection, authorization, or data failures fail the gate rather than
turning into skips. The tests do not start browser login.

Optional live selectors are `MCP_E2E_NAV_CODE`, `MCP_E2E_INDEX_NAME`,
`MCP_E2E_START`, and `MCP_E2E_END`. Defaults use a public scheme/index and the
inclusive January 4–8, 2021 window. Select a window with more than two observations
for each instrument. The independent walk allows at most twenty pages per
instrument; keep the window small. These checks compare live transport/export
paths, not independently queried native-database values or snapshot consistency.

The equity gate always uses `RELIANCE` / `EQ`, inclusive `2026-10-19` through
`2026-10-22`, page size two and at most twenty pages per path. The NAV/index date
environment overrides do not widen this equity window. Run just that gate with:

```sh
MCP_E2E_CONFIG=PATH_TO_PRIVATE_CONFIG .venv/bin/python -m unittest discover -s tests -p test_live_features.py -k equity -v
```

Run live acceptance only after the operator deploys the server tools. A passing
offline fixture test is not live acceptance.

## Milestone publication for maintainers

To copy the ZIP and a usage README to a distribution directory, create an ignored
`build.local.json` in the source project. Replace this example destination with
your own location:

```json
{
  "publish_dir": "../public/mf-mcp-consumer"
}
```

Run `.venv/bin/python build_share.py`. When the local build configuration exists,
each build also updates `mcp-consumer-share.zip` and `README.md` in that directory.
The public README comes from `PUBLIC_README.md` in the source project. Edit that
source file, not its generated public copy. `--publish-dir` overrides the local
setting; without either setting the build only writes local `dist` output.

Run the script after completing a milestone. It runs once and exits; source
edits alone do not publish anything. There is no watcher, daemon or background
service.

Tests and privacy scans must pass; otherwise the last good public release stays
in place. A source edit during verification also skips that build rather than
publishing an untested snapshot. The ZIP and README are each replaced atomically,
and unchanged content is not rewritten. The pair is not a filesystem transaction.

The local publication path remains excluded from the shared ZIP.

Tests use explicitly synthetic data and dummy token strings, not real credentials
or user records. Offline correctness and live service integration are separate
gates. Exports and environment-specific acceptance records are not distributed.
