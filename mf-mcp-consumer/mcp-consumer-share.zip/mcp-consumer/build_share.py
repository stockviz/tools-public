"""Test, build and publish a source-only archive after a completed milestone."""
import argparse
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path


SHARE_FILES = ('README.md', 'PUBLIC_README.md', 'pyproject.toml', 'requirements.lock.txt',
               'config.example.json', '.gitignore', 'build_share.py')
UNSAFE = (
    re.compile(r'/(?:home|mnt|Users)/[^\s\"\']+'),
    re.compile(r'[a-z0-9.-]+\.workers\.dev', re.IGNORECASE),
    re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    re.compile(r'(?:ghp_|github_pat_|sk-)[A-Za-z0-9_-]{20,}'),
    re.compile(r'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}'),
)


def archive_snapshot(root: Path) -> tuple[bytes, int, bytes]:
    """Read and scan one allowlisted snapshot without copying private runtime files."""
    root = root.resolve()
    files = [root / name for name in SHARE_FILES]
    files += sorted((root / 'mcp_consumer').glob('*.py'))
    files += sorted((root / 'tests').glob('test_*.py'))
    payloads = []
    for file in files:
        if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(root):
            raise ValueError('Share source is missing, symlinked or outside the project')
        data = file.read_bytes()
        if any(pattern.search(data.decode('utf-8')) for pattern in UNSAFE):
            raise ValueError('Potential personal path, deployment hostname or credential in share source: ' + file.name)
        payloads.append((file.relative_to(root).as_posix(), data))
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in payloads:
            info = zipfile.ZipInfo('mcp-consumer/' + name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return buffer.getvalue(), len(payloads), dict(payloads)['PUBLIC_README.md']


def write_if_changed(path: Path, data: bytes) -> bool:
    """Atomically replace changed content while preserving unchanged file timestamps."""
    if path.is_symlink():
        raise ValueError('Refusing a symlinked publication target')
    if path.exists() and path.read_bytes() == data:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            os.fchmod(handle.fileno(), 0o644)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)
    return True


def build(root: Path, destination: Path) -> dict:
    """Build a deterministic ZIP, replacing it only after successful source scans."""
    data, count, _ = archive_snapshot(root)
    changed = write_if_changed(destination.absolute(), data)
    return {'path': str(destination.absolute()), 'file_count': count, 'changed': changed,
            'sha256': hashlib.sha256(data).hexdigest()}


def publish_snapshot(root: Path, public_dir: Path | None, snapshot: tuple) -> dict:
    """Publish a single validated snapshot to local dist and an optional public folder."""
    data, count, readme = snapshot
    destination = root / 'dist' / 'mcp-consumer-share.zip'
    changed = write_if_changed(destination, data)
    result = {'path': str(destination), 'file_count': count, 'changed': changed,
              'sha256': hashlib.sha256(data).hexdigest()}
    if public_dir is not None:
        public_dir = public_dir.absolute()
        result['public_zip_changed'] = write_if_changed(public_dir / destination.name, data)
        result['public_readme_changed'] = write_if_changed(public_dir / 'README.md', readme)
        result['public_directory'] = str(public_dir)
    return result


def publish(root: Path, public_dir: Path) -> dict:
    """Scan before touching either public artifact, preserving the last good release on failure."""
    root = root.resolve()
    return publish_snapshot(root, public_dir, archive_snapshot(root))


def publication_directory(root: Path, config: Path, override: Path | None) -> Path | None:
    """Keep machine-specific publication paths in ignored local configuration."""
    value = None
    if config.exists():
        contents = json.loads(config.read_text(encoding='utf-8'))
        if not isinstance(contents, dict) or set(contents) != {'publish_dir'}:
            raise ValueError('Build configuration must contain only publish_dir')
        if not isinstance(contents['publish_dir'], str) or not contents['publish_dir'].strip():
            raise ValueError('publish_dir must be a nonempty path string')
        value = Path(contents['publish_dir']).expanduser()
        if not value.is_absolute():
            value = config.parent / value
    elif config != root / 'build.local.json':
        raise ValueError('Explicit build configuration does not exist')
    return override.expanduser().absolute() if override is not None else value


def main() -> int:
    """Test and publish one stable source snapshot, then exit."""
    root = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, help='Local build JSON; defaults to build.local.json when present')
    parser.add_argument('--publish-dir', type=Path, help='Override the configured publication directory')
    args = parser.parse_args()
    config = args.config.expanduser().absolute() if args.config is not None else root / 'build.local.json'
    try:
        public = publication_directory(root, config, args.publish_dir)
        snapshot = archive_snapshot(root)
        result = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
                                cwd=root, capture_output=True, text=True)
        if result.returncode:
            print('Tests failed; publication skipped. Run unittest directly for diagnostics.', file=sys.stderr)
            return 1
        if archive_snapshot(root)[0] != snapshot[0]:
            print('Source changed during verification; publication skipped. Retry the build.', file=sys.stderr)
            return 1
        report = publish_snapshot(root, public, snapshot)
        report['tests'] = 'passed'
        print(json.dumps(report, indent=2), flush=True)
        return 0
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError) as error:
        print('Build/publication failed: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
