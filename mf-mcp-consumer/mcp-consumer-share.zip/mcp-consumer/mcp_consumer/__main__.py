"""Allow python -m mcp_consumer as well as the installed entry point."""
from mcp_consumer.cli import main

raise SystemExit(main())
