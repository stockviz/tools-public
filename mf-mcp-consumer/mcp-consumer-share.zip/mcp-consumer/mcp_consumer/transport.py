"""Authenticated MCP transport with a private, consumer-owned OAuth cache."""
import asyncio
from contextlib import asynccontextmanager, contextmanager
import hashlib
import ipaddress
import json
import logging
import os
from pathlib import Path
import stat
import sys
import tempfile
import threading
import time
from typing import cast
from urllib.parse import parse_qs, urlsplit
import webbrowser

from mcp import ClientSession
from mcp.client.auth import OAuthClientProvider
from mcp.client.streamable_http import streamablehttp_client
from mcp.shared.auth import OAuthClientInformationFull, OAuthClientMetadata, OAuthMetadata, OAuthToken
from mcp.shared.exceptions import McpError


class TransportError(RuntimeError):
    """A public error containing no remote response or credential material."""


def validate_url(url: str) -> str:
    """Permit credential-free HTTPS and explicitly local HTTP endpoints."""
    try:
        parts = urlsplit(url)
        port = parts.port
        host = parts.hostname
        local = host == 'localhost' or (host is not None and ipaddress.ip_address(host).is_loopback)
    except ValueError:
        local = False
    try:
        parts = urlsplit(url)
        port = parts.port
        if (not parts.hostname or parts.username is not None or parts.password is not None
                or parts.query or parts.fragment or '?' in url or '#' in url
                or any(ord(c) <= 32 or ord(c) == 127 for c in url)
                or '\\' in url or parts.scheme not in ('http', 'https')
                or (parts.scheme == 'http' and not local)):
            raise ValueError
    except (ValueError, TypeError):
        raise TransportError('Invalid MCP URL: use HTTPS or loopback HTTP without credentials, query, or fragment.') from None
    return url


def _private_directory(path: Path) -> None:
    """Create or secure an owned directory without accepting symlinks."""
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise TransportError('OAuth cache directory is unsafe.')
    path.chmod(0o700)


class FileTokenStorage:
    """Persist SDK tokens and client registration in an isolated URL cache."""

    def __init__(self, url: str, state_dir: Path):
        """Use only the explicitly supplied state directory."""
        validate_url(url)
        try:
            root = Path(state_dir)
            _private_directory(root)
            self.directory = root / hashlib.sha256(url.encode()).hexdigest()
            _private_directory(self.directory)
        except Exception:
            raise TransportError('Cannot prepare private OAuth cache.') from None

    def _read(self, name, model):
        """Read a protected JSON object without exposing parsing errors."""
        try:
            fd = os.open(self.directory / name, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(fd, 'r') as handle:
                info = os.fstat(handle.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid():
                    raise ValueError
                os.fchmod(handle.fileno(), 0o600)
                payload = json.load(handle)
                if name == 'tokens.json':
                    self.expires_at = payload.pop('_expires_at', None)
                    if self.expires_at is not None and not isinstance(self.expires_at, (int, float)):
                        raise ValueError
                return model.model_validate(payload)
        except FileNotFoundError:
            return None
        except Exception:
            raise TransportError('Cannot read OAuth cache; remove the consumer cache and run login again.') from None

    def _write(self, name, value):
        """Atomically replace a mode-0600 JSON file in its private directory."""
        temporary = None
        try:
            fd, temporary = tempfile.mkstemp(prefix='.oauth-', dir=self.directory)
            with os.fdopen(fd, 'w') as handle:
                os.fchmod(handle.fileno(), 0o600)
                payload = value.model_dump(mode='json')
                if name == 'tokens.json':
                    payload['_expires_at'] = time.time() + value.expires_in if value.expires_in is not None else None
                handle.write(json.dumps(payload))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, self.directory / name)
        except Exception:
            raise TransportError('Cannot persist OAuth cache.') from None
        finally:
            if temporary is not None:
                Path(temporary).unlink(missing_ok=True)

    async def get_tokens(self) -> OAuthToken | None:
        """Load the SDK token object, if present."""
        return self._read('tokens.json', OAuthToken)

    async def set_tokens(self, tokens: OAuthToken) -> None:
        """Persist the SDK token object."""
        self._write('tokens.json', tokens)

    async def get_metadata(self):
        """Restore discovered endpoints so reload never guesses a token URL."""
        return self._read('metadata.json', OAuthMetadata)

    async def set_metadata(self, metadata):
        """Persist validated SDK discovery alongside its client registration."""
        self._write('metadata.json', metadata)

    async def clear_tokens(self):
        """Discard rejected refresh credentials before another connection retries."""
        try:
            (self.directory / 'tokens.json').unlink(missing_ok=True)
        except OSError:
            raise TransportError('Cannot clear rejected OAuth cache; remove the consumer cache and run login again.') from None

    async def get_client_info(self) -> OAuthClientInformationFull | None:
        """Load the SDK client registration, if present."""
        return self._read('client.json', OAuthClientInformationFull)

    async def set_client_info(self, client_info: OAuthClientInformationFull) -> None:
        """Persist the SDK client registration."""
        self._write('client.json', client_info)


class SecretSafeLogFilter(logging.Filter):
    """Remove SDK exception bodies and HTTP URL details from logs."""

    def filter(self, record):
        """Retain only a fixed diagnostic marker, never raw arguments."""
        record.msg = 'MCP transport diagnostic (details suppressed for credential safety).'
        record.args = ()
        record.exc_info = None
        record.exc_text = None
        record.stack_info = None
        return True


_log_lock = threading.RLock()
_log_users = 0
_previous_factory = logging.getLogRecordFactory()


def _safe_record_factory(*args, **kwargs):
    """Sanitize records before any handler, including lazily created loggers."""
    record = _previous_factory(*args, **kwargs)
    if record.name.startswith(('mcp.', 'httpx', 'httpcore')):
        SecretSafeLogFilter().filter(record)
    return record


@contextmanager
def _safe_diagnostics():
    """Install a reference-counted log sanitizer for concurrent connections."""
    global _log_users, _previous_factory
    with _log_lock:
        if _log_users == 0:
            _previous_factory = logging.getLogRecordFactory()
            logging.setLogRecordFactory(_safe_record_factory)
        _log_users += 1
    try:
        yield
    finally:
        with _log_lock:
            _log_users -= 1
            if _log_users == 0 and logging.getLogRecordFactory() is _safe_record_factory:
                logging.setLogRecordFactory(_previous_factory)


class ReadOnlyMetadata(OAuthClientMetadata):
    """Prevent SDK discovery or step-up from broadening the requested scope."""

    def __setattr__(self, name, value):
        """Pin scope assignments made by SDK 1.26 discovery to read access."""
        super().__setattr__(name, 'research:read' if name == 'scope' else value)


class PersistentOAuthProvider(OAuthClientProvider):
    """Restore token expiry missing from the SDK's default storage loading."""

    async def _initialize(self):
        """Load SDK objects and their persisted absolute expiry timestamp."""
        await super()._initialize()
        self.context.token_expiry_time = getattr(self.context.storage, 'expires_at', None)
        self.context.oauth_metadata = await cast(FileTokenStorage, self.context.storage).get_metadata()

    async def _handle_token_response(self, response):
        """Keep the discovered token endpoint across SDK provider lifetimes."""
        if self.context.oauth_metadata is not None:
            await cast(FileTokenStorage, self.context.storage).set_metadata(self.context.oauth_metadata)
        await super()._handle_token_response(response)

    async def _handle_refresh_response(self, response):
        """Fail closed and forget rejected credentials rather than rotating blindly."""
        if await super()._handle_refresh_response(response):
            return True
        await cast(FileTokenStorage, self.context.storage).clear_tokens()
        raise TransportError('Authentication expired; run login again.')


def make_provider(url, storage, redirect_uri, redirect_handler, callback_handler):
    """Build the SDK provider with explicit read scope and isolated storage."""
    metadata = ReadOnlyMetadata(
        redirect_uris=[redirect_uri], scope='research:read',
        client_name='PortfolioManagerMf MCP consumer', token_endpoint_auth_method='none',
        grant_types=['authorization_code', 'refresh_token'], response_types=['code'],
    )
    return PersistentOAuthProvider(
        server_url=url, client_metadata=metadata, storage=storage,
        redirect_handler=redirect_handler, callback_handler=callback_handler,
    )


async def authenticate_login(session, url, state_dir):
    """Trigger OAuth with a validation-only probe, then require a valid cache."""
    try:
        # Missing scheme_code fails before data access or quota consumption.
        await session.call_tool('get_nav_history', {})
    except McpError as error:
        if error.error.code != -32602:
            raise TransportError('Authentication probe failed; run login again.') from None
    storage = FileTokenStorage(url, state_dir)
    tokens = await storage.get_tokens()
    expiry = getattr(storage, 'expires_at', None)
    if (tokens is None or not tokens.access_token or expiry is None
            or expiry <= time.time() or 'research:read' not in (tokens.scope or '').split()
            or await storage.get_client_info() is None):
        raise TransportError('Authentication required; run login first.')


async def noninteractive_redirect(url):
    """Reject interactive authorization without disclosing its URL."""
    raise TransportError('Authentication required; run login first.')


async def interactive_redirect(url):
    """Show the public authorization URL and attempt to launch a browser."""
    parts = urlsplit(url)
    if parts.fragment or any(ord(c) <= 32 or ord(c) == 127 for c in url):
        raise TransportError('Unsafe authorization redirect rejected.')
    validate_url(parts._replace(query='', fragment='').geturl())
    params = parse_qs(parts.query)
    if any(key in params for key in ('code', 'access_token', 'refresh_token', 'client_secret')):
        raise TransportError('Unsafe authorization redirect rejected.')
    print('Authorize in your browser: ' + url, file=sys.stderr)
    try:
        await asyncio.to_thread(webbrowser.open, url)
    except Exception:
        pass


class LoopbackCallback:
    """Receive one OAuth response on an ephemeral IPv4 loopback listener."""

    def __init__(self, timeout=180.0):
        """Configure a bounded callback wait without starting a listener."""
        self.timeout = timeout
        self.server = None
        self.connections = set()

    async def __aenter__(self):
        """Bind only 127.0.0.1 and advertise the exact callback URI."""
        self.result = asyncio.get_running_loop().create_future()
        self.server = await asyncio.start_server(self._handle, '127.0.0.1', 0, limit=8192)
        port = self.server.sockets[0].getsockname()[1]
        self.authority = f'127.0.0.1:{port}'
        self.redirect_uri = f'http://{self.authority}/callback'
        return self

    async def __aexit__(self, *args):
        """Close the listener and any outstanding callback connections."""
        self.server.close()
        await self.server.wait_closed()
        for task in list(self.connections):
            task.cancel()
        if self.connections:
            await asyncio.gather(*self.connections, return_exceptions=True)
        self.result.cancel()

    async def _handle(self, reader, writer):
        """Validate peer, Host, path, method, and unambiguous callback fields."""
        task = asyncio.current_task()
        self.connections.add(task)
        status = 400
        try:
            peer = writer.get_extra_info('peername')
            raw = await asyncio.wait_for(reader.readuntil(b'\r\n\r\n'), timeout=5)
            lines = raw.decode('ascii').split('\r\n')
            method, target, version = lines[0].split(' ')
            hosts = [line.split(':', 1)[1].strip() for line in lines[1:] if line.lower().startswith('host:')]
            parts = urlsplit(target)
            values = parse_qs(parts.query, keep_blank_values=True, strict_parsing=True)
            if (peer[0] != '127.0.0.1' or hosts != [self.authority]
                    or method != 'GET' or version not in ('HTTP/1.1', 'HTTP/1.0')
                    or parts.path != '/callback' or parts.scheme or parts.netloc or parts.fragment
                    or self.result.done()):
                raise ValueError
            if 'error' in values:
                self.result.set_result(None)
                status = 200
            elif all(len(values.get(key, [])) == 1 and values[key][0] for key in ('code', 'state')):
                self.result.set_result((values['code'][0], values['state'][0]))
                status = 200
            body = b'Authorization response received. You may close this window.' if status == 200 else b'Invalid callback.'
            writer.write(f'HTTP/1.1 {status} Response\r\nContent-Type: text/plain\r\nCache-Control: no-store\r\nConnection: close\r\nContent-Length: {len(body)}\r\n\r\n'.encode() + body)
            await writer.drain()
        except (Exception, asyncio.CancelledError):
            if not writer.is_closing():
                writer.write(b'HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n')
        finally:
            writer.close()
            await writer.wait_closed()
            self.connections.discard(task)

    async def wait(self):
        """Return code/state to the SDK, which validates the OAuth state."""
        try:
            result = await asyncio.wait_for(asyncio.shield(self.result), self.timeout)
        except TimeoutError:
            raise TransportError('OAuth callback timed out; run login again.') from None
        if result is None:
            raise TransportError('OAuth authorization was denied; run login again.')
        return result


@asynccontextmanager
async def connect(url: str, state_dir: Path, interactive: bool = False):
    """Yield an initialized authenticated session; contain unsafe remote errors."""
    validate_url(url)
    storage = FileTokenStorage(url, state_dir)
    # SDK 1.26 can log raw state mismatches and remote error bodies.
    with _safe_diagnostics():
        try:
            if interactive:
                async with LoopbackCallback() as callback:
                    provider = make_provider(url, storage, callback.redirect_uri, interactive_redirect, callback.wait)
                    async with streamablehttp_client(url, auth=provider) as (read, write, _):
                        async with ClientSession(read, write) as session:
                            await session.initialize()
                            yield session
            else:
                provider = make_provider(url, storage, 'http://127.0.0.1:1/callback', noninteractive_redirect, None)
                async with streamablehttp_client(url, auth=provider) as (read, write, _):
                    async with ClientSession(read, write) as session:
                        await session.initialize()
                        yield session
        except Exception:
            raise TransportError('MCP connection or request failed; check the endpoint and run login if authentication is required.') from None
