"""Expose complete local downloads to Goose through a small stdio MCP extension."""
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from mcp_consumer.client import run_download


def safe_output(root: Path, filename: str) -> Path:
    """Confine model-chosen CSV basenames to the operator-configured directory."""
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or not filename.endswith(".csv") or any(ord(char) < 32 for char in filename)):
        raise ValueError("filename must be a CSV basename, without directories or control characters")
    return Path(root).resolve() / filename


def build_server(url: str, state_dir: Path, output_dir: Path, legacy_registration: bool = False) -> FastMCP:
    """Register only bounded local-file writers; never expose credentials or cursors."""
    server = FastMCP("StockViz CSV downloader")
    annotations = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True)

    @server.tool(annotations=annotations)
    async def download_nav_history(scheme_code: str, filename: str, start: str | None = None,
                                   end: str | None = None, page_size: int = 1000,
                                   max_pages: int = 10000) -> dict:
        """Save every NAV page to a local CSV; return its path, counts and SHA-256, not rows."""
        return await run_download(url, state_dir, "get_nav_history",
                                  dict(scheme_code=scheme_code, start=start, end=end, limit=page_size),
                                  safe_output(output_dir, filename), max_pages=max_pages, legacy_registration=legacy_registration)

    @server.tool(annotations=annotations)
    async def download_index_history(index_name: str, filename: str, start: str | None = None,
                                     end: str | None = None, page_size: int = 1000,
                                     max_pages: int = 10000) -> dict:
        """Save every exact-name index history page to one verified local CSV."""
        return await run_download(url, state_dir, "get_index_history",
                                  dict(index_name=index_name, start=start, end=end, limit=page_size),
                                  safe_output(output_dir, filename), max_pages=max_pages, legacy_registration=legacy_registration)

    return server
