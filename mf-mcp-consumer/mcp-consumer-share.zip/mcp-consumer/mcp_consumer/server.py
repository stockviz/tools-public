"""Expose complete local downloads to Goose through a small stdio MCP extension."""
import asyncio
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from mcp_consumer.client import run_download


def safe_output(root: Path, filename: str) -> Path:
    """Confine model-chosen CSV basenames to the operator-configured directory."""
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or not filename.endswith(".csv") or any(ord(char) < 32 for char in filename)):
        raise ValueError("filename must be a CSV basename, without directories or control characters")
    return Path(root).resolve() / filename


def build_server(url: str, state_dir: Path, output_dir: Path, legacy_registration: bool = False) -> FastMCP:
    """Register metadata-only file writers sharing two complete-export execution slots."""
    server = FastMCP("StockViz CSV downloader")
    # Shared by both tools for this stdio server; queue whole exports, not individual pages.
    downloads = asyncio.Semaphore(2)
    annotations = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True)

    @server.tool(annotations=annotations)
    async def download_nav_history(scheme_code: str, filename: str, start: str | None = None,
                                   end: str | None = None, page_size: int = 1000,
                                   max_pages: int = 10000) -> dict:
        """Queue a complete NAV export and return metadata only, releasing its slot on cancellation."""
        async with downloads:
            return await run_download(url, state_dir, "get_nav_history",
                                      dict(scheme_code=scheme_code, start=start, end=end, limit=page_size),
                                      safe_output(output_dir, filename), max_pages=max_pages, legacy_registration=legacy_registration)

    @server.tool(annotations=annotations)
    async def download_index_history(index_name: str, filename: str, start: str | None = None,
                                     end: str | None = None, page_size: int = 1000,
                                     max_pages: int = 10000) -> dict:
        """Queue a complete exact-name index export without returning rows or opaque cursors."""
        async with downloads:
            return await run_download(url, state_dir, "get_index_history",
                                      dict(index_name=index_name, start=start, end=end, limit=page_size),
                                      safe_output(output_dir, filename), max_pages=max_pages, legacy_registration=legacy_registration)

    return server
