"""Expose complete local downloads to Goose through a small stdio MCP extension."""
import asyncio
from pathlib import Path

from mcp.server.fastmcp import FastMCP
from mcp.types import ToolAnnotations

from mcp_consumer.client import run_download, run_equity_catalog, run_dashboard_catalog, run_dashboard_query, run_dashboard_download


def safe_output(root: Path, filename: str) -> Path:
    """Confine model-chosen CSV basenames to the operator-configured directory."""
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or not filename.endswith(".csv") or any(ord(char) < 32 for char in filename)):
        raise ValueError("filename must be a CSV basename, without directories or control characters")
    return Path(root).resolve() / filename


def build_server(url: str, state_dir: Path, output_dir: Path) -> FastMCP:
    """Register bounded research reads and file writers sharing two complete-export slots."""
    server = FastMCP("StockViz CSV downloader")
    # Shared by all download tools; queue whole exports, not individual pages.
    downloads = asyncio.Semaphore(2)
    annotations = ToolAnnotations(readOnlyHint=False, destructiveHint=False, openWorldHint=True)

    @server.tool(annotations=annotations)
    async def download_nav_history(scheme_code: str, filename: str, start: str | None = None,
                                   end: str | None = None, page_size: int = 1000,
                                   max_pages: int = 10000) -> dict:
        """Queue a complete NAV export and return metadata only, releasing its slot on cancellation."""
        async with downloads:
            return await run_download(url, state_dir, "get_nav_history",
                                      dict(scheme_code=scheme_code, start=start, end=end, limit=page_size),
                                      safe_output(output_dir, filename), max_pages=max_pages)

    @server.tool(annotations=annotations)
    async def download_index_history(index_name: str, filename: str, start: str | None = None,
                                     end: str | None = None, page_size: int = 1000,
                                     max_pages: int = 10000) -> dict:
        """Queue a complete exact-name index export without returning rows or opaque cursors."""
        async with downloads:
            return await run_download(url, state_dir, "get_index_history",
                                      dict(index_name=index_name, start=start, end=end, limit=page_size),
                                      safe_output(output_dir, filename), max_pages=max_pages)

    @server.tool(annotations=annotations)
    async def download_equity_history(symbol: str, series: str, filename: str,
                                      start: str | None = None, end: str | None = None,
                                      page_size: int = 1000, max_pages: int = 10000) -> dict:
        """Export all raw unadjusted equity pages for an explicit symbol/series pair to CSV."""
        async with downloads:
            return await run_download(url, state_dir, "get_equity_history",
                dict(symbol=symbol, series=series, start=start, end=end, limit=page_size),
                safe_output(output_dir, filename), max_pages=max_pages)

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
    async def list_equities(search: str | None = None, series: str | None = None,
                            limit: int = 250, cursor: str | None = None) -> dict:
        """Read one bounded catalog page; broad scans can time out. Keep continuation filters fixed."""
        return await run_equity_catalog(url, state_dir,
            dict(search=search, series=series, limit=limit, cursor=cursor))

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
    async def list_dashboard_datasets(search: str | None = None, limit: int = 100,
                                      cursor: str | None = None) -> dict:
        """Discover one bounded page of all published public dashboard datasets and their schemas; follow unchanged cursors."""
        return await run_dashboard_catalog(url, state_dir, dict(search=search, limit=limit, cursor=cursor))

    @server.tool(annotations=ToolAnnotations(readOnlyHint=True, destructiveHint=False, openWorldHint=True))
    async def query_dashboard_dataset(dataset_name: str, entity_column: str | None = None,
                                      entity: str | None = None, date_column: str | None = None,
                                      start: str | None = None, end: str | None = None,
                                      limit: int = 100, cursor: str | None = None) -> dict:
        """Read at most 200 dashboard rows with published schema and provenance; exact dataset name, paired entity/date filters, unchanged cursor."""
        return await run_dashboard_query(url, state_dir, dict(dataset_name=dataset_name,
            entity_column=entity_column, entity=entity, date_column=date_column,
            start=start, end=end, limit=limit, cursor=cursor))

    @server.tool(annotations=annotations)
    async def download_dashboard_dataset(dataset_name: str, filename: str,
                                         entity_column: str | None = None, entity: str | None = None,
                                         date_column: str | None = None, start: str | None = None,
                                         end: str | None = None, page_size: int = 100,
                                         max_pages: int = 10000) -> dict:
        """Export every filtered dashboard page to a new CSV with dynamic published columns; return file metadata only, never rows or cursors."""
        async with downloads:
            return await run_dashboard_download(url, state_dir, dict(dataset_name=dataset_name,
                entity_column=entity_column, entity=entity, date_column=date_column,
                start=start, end=end, limit=page_size), safe_output(output_dir, filename), max_pages=max_pages)

    return server
