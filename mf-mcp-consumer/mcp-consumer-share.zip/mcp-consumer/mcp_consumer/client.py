"""Connect the verified CSV writer to its own authenticated MCP session."""
from pathlib import Path

from mcp_consumer.catalog import equity_catalog, validate_catalog
from mcp_consumer.dashboard import dashboard_catalog, dashboard_query, download_dashboard, validate_dashboard_catalog, validate_dashboard_query
from mcp_consumer.download import DownloadError, download, validate_request
from mcp_consumer.transport import connect


async def run_download(url: str, state_dir: Path, tool: str, arguments: dict,
                       output: Path, max_pages: int = 10000) -> dict:
    """Download using noninteractive OAuth; interactive consent belongs to login."""
    validate_request(tool, arguments)
    failure = None
    try:
        async with connect(url, state_dir, interactive=False) as session:
            try:
                result = await download(session.call_tool, tool, arguments, output, max_pages=max_pages)
            except DownloadError as error:
                # Preserve safe export diagnostics without throwing through the SDK sanitizer.
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    return {**result, "source_url": url}


async def _run_dashboard(url, state_dir, operation, arguments, **options):
    """Preserve safe dashboard failures across the SDK's connection sanitizer."""
    failure = None
    result = None
    try:
        async with connect(url, state_dir, interactive=False) as session:
            try:
                result = await operation(session.call_tool, arguments, **options)
            except DownloadError as error:
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    if result is None:
        raise DownloadError("Dashboard operation returned no result")
    return {**result, "source_url": url}


async def run_dashboard_catalog(url: str, state_dir: Path, arguments: dict) -> dict:
    """Discover one catalog page through this consumer's own OAuth session."""
    validate_dashboard_catalog(arguments)
    return await _run_dashboard(url, state_dir, dashboard_catalog, arguments)


async def run_dashboard_query(url: str, state_dir: Path, arguments: dict) -> dict:
    """Read one validated dataset page without local file writes."""
    validate_dashboard_query(arguments)
    return await _run_dashboard(url, state_dir, dashboard_query, arguments)


async def run_dashboard_download(url: str, state_dir: Path, arguments: dict,
                                 output: Path, max_pages: int = 10000) -> dict:
    """Export every dashboard page with internal cursor management and no auth fallback."""
    validate_dashboard_query(arguments, allow_cursor=False)
    return await _run_dashboard(url, state_dir, download_dashboard, arguments, output=output, max_pages=max_pages)


async def run_equity_catalog(url: str, state_dir: Path, arguments: dict) -> dict:
    """Read a catalog page using only this client's OAuth, preserving safe failures."""
    validate_catalog(arguments)
    failure = None
    try:
        async with connect(url, state_dir, interactive=False) as session:
            try:
                result = await equity_catalog(session.call_tool, arguments)
            except DownloadError as error:
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    return {**result, "source_url": url}
