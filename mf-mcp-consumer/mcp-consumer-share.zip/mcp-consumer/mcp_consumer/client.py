"""Connect the verified CSV writer to its own authenticated MCP session."""
from pathlib import Path

from mcp_consumer.download import DownloadError, download, validate_request
from mcp_consumer.transport import connect


async def run_download(url: str, state_dir: Path, tool: str, arguments: dict,
                       output: Path, max_pages: int = 10000, legacy_registration: bool = False) -> dict:
    """Download using noninteractive OAuth; interactive consent belongs to login."""
    validate_request(tool, arguments)
    failure = None
    try:
        async with connect(url, state_dir, interactive=False, legacy_registration=legacy_registration) as session:
            try:
                result = await download(session.call_tool, tool, arguments, output, max_pages=max_pages)
            except DownloadError as error:
                # Preserve safe export diagnostics without throwing through the SDK sanitizer.
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    return {**result, "source_url": url}
