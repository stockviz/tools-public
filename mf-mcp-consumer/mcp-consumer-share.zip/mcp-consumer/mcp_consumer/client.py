"""Connect the verified CSV writer to its own authenticated MCP session."""
from pathlib import Path

from mcp_consumer.catalog import equity_catalog, validate_catalog
from mcp_consumer.download import DownloadError, download, validate_request
from mcp_consumer.transport import connect


async def run_download(url: str, state_dir: Path, tool: str, arguments: dict,
                       output: Path, max_pages: int = 10000, legacy_registration: bool = False) -> dict:
    """Download using noninteractive OAuth; interactive consent belongs to login."""
    validate_request(tool, arguments)
    failure = None
    try:
        async with connect(url, state_dir, interactive=False, legacy_registration=legacy_registration) as session:
            try:
                result = await download(session.call_tool, tool, arguments, output, max_pages=max_pages)
            except DownloadError as error:
                # Preserve safe export diagnostics without throwing through the SDK sanitizer.
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    return {**result, "source_url": url}


async def run_equity_catalog(url: str, state_dir: Path, arguments: dict,
                              legacy_registration: bool = False) -> dict:
    """Read a catalog page using only this client's OAuth, preserving safe failures."""
    validate_catalog(arguments)
    failure = None
    try:
        async with connect(url, state_dir, interactive=False, legacy_registration=legacy_registration) as session:
            try:
                result = await equity_catalog(session.call_tool, arguments)
            except DownloadError as error:
                failure = error
    except Exception:
        raise DownloadError("MCP connection or authorization failed. Check the endpoint and run login interactively; no raw SDK error is exposed") from None
    if failure is not None:
        raise failure
    return {**result, "source_url": url}
