"""Bounded public dashboard inspection and verified dynamic-schema CSV exports.

NULL uses the existing CSV blank-cell convention: NULL and empty text are ambiguous.
Opaque request cursors accept the remote 8192-character bound; returned continuation
pages deliberately retain check_page's stricter 4096-character compatibility bound.
"""
import csv
import hashlib
import math
import os
import re
import tempfile
from datetime import date, datetime
from pathlib import Path
from typing import Any

from mcp_consumer.download import DownloadError, check_page, fetch_page


IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]{0,63}")
DATASET = re.compile(r"DASHBOARD_[A-Z0-9_]{1,54}")
SQL_TYPE = re.compile(r"(?:BIGINT|INT|INTEGER|SMALLINT|TINYINT|DOUBLE|FLOAT|REAL|BOOLEAN|DATE|DATETIME(?:\([0-6]\))?|TIMESTAMP(?:\([0-6]\))?|TEXT|LONGTEXT|MEDIUMTEXT|(?:VAR)?CHAR\([1-9]\d{0,4}\)|DECIMAL\([1-9]\d?,\d{1,2}\))", re.ASCII)
INTEGER_BITS = {"BIGINT": 64, "INT": 32, "INTEGER": 32, "SMALLINT": 16, "TINYINT": 8}
NULL_WARNING = "CSV NULL and empty string both use a blank cell and cannot be distinguished; text is not spreadsheet-coerced or escaped."


def _name(value: Any) -> None:
    """Require an exact public non-catalog dashboard table name."""
    if not isinstance(value, str) or not DATASET.fullmatch(value) or value == "DASHBOARD_CATALOG":
        raise DownloadError("Invalid dashboard dataset_name")


def _text(value: Any, field: str, maximum: int = 256) -> None:
    """Bound literal strings without stripping or normalizing them."""
    if (not isinstance(value, str) or any(0xD800 <= ord(char) <= 0xDFFF for char in value)
            or not 1 <= len(value.encode("utf-16-le")) // 2 <= maximum):
        raise DownloadError(f"Invalid dashboard {field}")


def _day(value: Any) -> str:
    """Check a real canonical ISO calendar day."""
    try:
        if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
            raise ValueError
    except (ValueError, TypeError):
        raise DownloadError("Invalid dashboard ISO date") from None
    return value


def _common(arguments: dict, allowed: set) -> dict:
    """Reject unknown fields and bound the shared page/cursor request."""
    if not isinstance(arguments, dict) or set(arguments) - allowed:
        raise DownloadError("Unsupported dashboard request field")
    args = {key: value for key, value in arguments.items() if value is not None}
    size = args.get("limit", 100)
    if type(size) is not int or not 1 <= size <= 200:
        raise DownloadError("Dashboard limit must be an integer from 1 to 200")
    if "cursor" in args:
        _text(args["cursor"], "cursor", 8192)
    return {**args, "limit": size, "cursor": args.get("cursor")}


def validate_dashboard_catalog(arguments: dict) -> dict:
    """Validate one bounded catalog discovery request."""
    args = _common(arguments, {"search", "limit", "cursor"})
    if "search" in args:
        _text(args["search"], "search")
    return args


def validate_dashboard_query(arguments: dict, allow_cursor: bool = True) -> dict:
    """Validate immutable dataset filters and optional opaque continuation."""
    if not allow_cursor and isinstance(arguments, dict) and "cursor" in arguments:
        raise DownloadError("Download cursors are managed internally")
    args = _common(arguments, {"dataset_name", "entity_column", "entity", "date_column", "start", "end", "limit", "cursor"})
    _name(args.get("dataset_name"))
    for key in ("entity_column", "date_column"):
        if key in args and (not isinstance(args[key], str) or not IDENTIFIER.fullmatch(args[key])):
            raise DownloadError("Invalid dashboard filter column")
    if ("entity_column" in args) != ("entity" in args):
        raise DownloadError("entity_column and entity must be supplied together")
    if "entity" in args:
        _text(args["entity"], "entity")
    if ("date_column" in args) != ("start" in args or "end" in args):
        raise DownloadError("date_column requires start or end and vice versa")
    for key in ("start", "end"):
        if key in args:
            _day(args[key])
    if "start" in args and "end" in args and args["start"] > args["end"]:
        raise DownloadError("start must not be after end")
    return args


def _json_value(value: Any, depth: int = 0) -> None:
    """Reject non-JSON or unbounded-depth publication metadata."""
    if depth > 30:
        raise DownloadError("Dashboard metadata is nested too deeply")
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if isinstance(value, list):
        for child in value:
            _json_value(child, depth + 1)
        return
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        for child in value.values():
            _json_value(child, depth + 1)
        return
    raise DownloadError("Dashboard publication metadata is not JSON")


def _publication(value: Any) -> dict:
    """Validate the catalog's exact publication identity, schema and generation."""
    fields = {"dataset_name", "row_count", "metadata", "refreshed_at", "content_digest", "schema"}
    if not isinstance(value, dict) or set(value) != fields:
        raise DownloadError("Invalid dashboard publication envelope")
    _name(value["dataset_name"])
    if not isinstance(value["row_count"], str) or not re.fullmatch(r"0|[1-9][0-9]*", value["row_count"]):
        raise DownloadError("Invalid dashboard publication row_count")
    if not isinstance(value["content_digest"], str) or not re.fullmatch(r"[a-f0-9]{64}", value["content_digest"]):
        raise DownloadError("Invalid dashboard publication digest")
    refreshed = value["refreshed_at"]
    try:
        if not isinstance(refreshed, str) or not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}", refreshed):
            raise ValueError
        datetime.strptime(refreshed, "%Y-%m-%d %H:%M:%S.%f")
    except ValueError:
        raise DownloadError("Invalid dashboard publication refreshed_at") from None
    schema = value["schema"]
    if not isinstance(schema, list) or not 1 <= len(schema) <= 256:
        raise DownloadError("Invalid dashboard schema")
    names = set()
    for column in schema:
        if (not isinstance(column, list) or len(column) != 2 or not all(isinstance(part, str) for part in column)
                or not IDENTIFIER.fullmatch(column[0]) or not SQL_TYPE.fullmatch(column[1])
                or column[0].upper() in names):
            raise DownloadError("Invalid or duplicate dashboard schema column")
        names.add(column[0].upper())
    if ["ROW_ID", "BIGINT"] not in schema:
        raise DownloadError("Dashboard schema requires ROW_ID BIGINT")
    _json_value(value["metadata"])
    return value


def _integer(value: Any, bits: int, positive: bool = False) -> int:
    """Read canonical signed SQL integer text without float precision loss."""
    if not isinstance(value, str) or not re.fullmatch(r"0|-?[1-9][0-9]*", value) or len(value) > 20:
        raise DownloadError("Dashboard integer must be canonical exact text")
    number = int(value)
    if not -(2 ** (bits - 1)) <= number < 2 ** (bits - 1) or (positive and number <= 0):
        raise DownloadError("Dashboard integer exceeds its SQL range")
    return number


def _filters(args: dict, fields: dict) -> None:
    """Require schema-compatible literal entity and inclusive date filters."""
    if "entity_column" in args:
        kind = fields.get(args["entity_column"], "")
        if kind in INTEGER_BITS:
            _integer(args["entity"], INTEGER_BITS[kind])
        elif not re.fullmatch(r"(?:(?:LONG|MEDIUM)?TEXT|(?:VAR)?CHAR\([1-9][0-9]*\))", kind):
            raise DownloadError("Entity column must be advertised textual or integer data")
    if "date_column" in args and not re.fullmatch(r"DATE|DATETIME(?:\([0-6]\))?|TIMESTAMP(?:\([0-6]\))?", fields.get(args["date_column"], "")):
        raise DownloadError("Date column must be advertised date data")


def _row(row: Any, fields: dict, args: dict) -> int:
    """Check exact row shape, scalar SQL text, dates and returned filter matches."""
    if not isinstance(row, dict) or set(row) != set(fields):
        raise DownloadError("Dashboard row columns differ from advertised schema")
    for key, kind in fields.items():
        value = row[key]
        if value is None:
            continue
        if kind == "BOOLEAN":
            if type(value) not in (str, bool, int) or value not in ("0", "1", 0, 1):
                raise DownloadError("Invalid dashboard boolean")
        elif not isinstance(value, str):
            raise DownloadError("Dashboard values must remain scalar database text or NULL")
        elif kind in INTEGER_BITS:
            _integer(value, INTEGER_BITS[kind])
        elif kind == "DATE":
            _day(value)
        elif kind.startswith(("DATETIME", "TIMESTAMP")):
            try:
                if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}[ T][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?", value):
                    raise ValueError
                datetime.fromisoformat(value)
            except ValueError:
                raise DownloadError("Invalid dashboard datetime") from None
        elif kind.startswith(("DOUBLE", "FLOAT", "REAL", "DECIMAL")):
            if not re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", value):
                raise DownloadError("Invalid dashboard numeric text")
    if "entity_column" in args:
        key = args["entity_column"]
        value = row[key]
        if value is None or (value != args["entity"] if fields[key] in INTEGER_BITS else args["entity"].lower() not in value.lower()):
            raise DownloadError("Dashboard row does not match requested entity")
    if "date_column" in args:
        value = row[args["date_column"]]
        if value is None or ("start" in args and value[:10] < args["start"]) or ("end" in args and value[:10] > args["end"]):
            raise DownloadError("Dashboard row is outside requested date window")
    return _integer(row["ROW_ID"], 64, positive=True)


def _checked_query(value: dict, args: dict) -> tuple:
    """Validate one bounded dataset page and its within-page key ordering."""
    if value.get("status") != "ok" or "error" in value or value.get("dataset_name") != args["dataset_name"]:
        raise DownloadError("Dashboard query failed or returned the wrong dataset")
    publication = _publication(value.get("metadata"))
    if isinstance(publication["metadata"], dict) and publication["metadata"].get("quality") == "unavailable":
        raise DownloadError("Dashboard publication quality is unavailable")
    if publication["dataset_name"] != args["dataset_name"]:
        raise DownloadError("Dashboard publication belongs to a different dataset")
    rows, more, cursor = check_page(value, args["limit"])
    if more and cursor == args["cursor"]:
        raise DownloadError("Dashboard continuation cursor repeated")
    fields = dict(publication["schema"])
    _filters(args, fields)
    previous = 0
    for row in rows:
        current = _row(row, fields, args)
        if current <= previous:
            raise DownloadError("Dashboard ROW_ID did not increase")
        previous = current
    return rows, more, cursor, publication


async def dashboard_catalog(call_tool, arguments: dict) -> dict:
    """Return one validated catalog page, not an unbounded catalog walk."""
    args = validate_dashboard_catalog(arguments)
    value, _ = await fetch_page(call_tool, "list_dashboard_datasets", args, 30.0)
    if value.get("status") != "ok" or "error" in value:
        raise DownloadError("Dashboard catalog unavailable")
    rows, more, cursor = check_page(value, args["limit"])
    if more and cursor == args["cursor"]:
        raise DownloadError("Dashboard catalog continuation repeated")
    previous = ""
    for row in rows:
        publication = _publication(row)
        name = publication["dataset_name"]
        if name <= previous or ("search" in args and args["search"].lower() not in name.lower()):
            raise DownloadError("Dashboard catalog identity order or search mismatch")
        previous = name
    return value


async def dashboard_query(call_tool, arguments: dict) -> dict:
    """Return one validated bounded dataset page for model inspection."""
    args = validate_dashboard_query(arguments)
    value, _ = await fetch_page(call_tool, "query_dashboard_dataset", args, 30.0)
    _checked_query(value, args)
    return value


def _warnings(value: dict, publication: dict) -> set:
    """Collect bounded public warning strings without including row or cursor values."""
    result = set()
    metadata = publication["metadata"]
    for source in (value, metadata if isinstance(metadata, dict) else {}):
        warnings = source.get("warnings", [])
        if isinstance(warnings, list):
            for warning in warnings[:50]:
                if isinstance(warning, str) and len(warning) <= 4096:
                    result.add(warning)
    return result


async def download_dashboard(call_tool, arguments: dict, output: Path, max_pages: int = 10000) -> dict:
    """Stream a generation-stable CSV, verify bytes, and atomically publish metadata only."""
    args = validate_dashboard_query(arguments, allow_cursor=False)
    request = {key: value for key, value in args.items() if key != "cursor"}
    if type(max_pages) is not int or max_pages < 1:
        raise DownloadError("max_pages must be a positive integer")
    output = Path(output).absolute()
    if output.exists() or output.is_symlink():
        raise DownloadError("Destination already exists; choose a new filename")
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=output.name + ".", suffix=".partial", dir=output.parent)
    partial = Path(temporary)
    pages, count, previous = 0, 0, 0
    publication, columns = None, None
    seen = set()
    warnings = {NULL_WARNING}
    wait_remaining = 30.0
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            writer = None
            while True:
                if pages >= max_pages:
                    raise DownloadError("Page budget exhausted before export completion")
                value, wait_remaining = await fetch_page(call_tool, "query_dashboard_dataset", args, wait_remaining)
                rows, more, cursor, current = _checked_query(value, args)
                if publication is None:
                    publication = current
                    columns = [name for name, _ in current["schema"]]
                    writer = csv.DictWriter(handle, fieldnames=columns, lineterminator="\r\n")
                    writer.writeheader()
                elif current != publication:
                    raise DownloadError("Dashboard publication generation or schema changed; restart export")
                pages += 1
                for row in rows:
                    key = _integer(row["ROW_ID"], 64, positive=True)
                    if key <= previous:
                        raise DownloadError("Dashboard ROW_ID repeated or did not increase")
                    previous = key
                    assert writer is not None
                    writer.writerow(row)
                    count += 1
                handle.flush()
                warnings.update(_warnings(value, current))
                if not more:
                    break
                signature = hashlib.sha256(cursor.encode("utf-8")).hexdigest()
                if signature in seen:
                    raise DownloadError("Dashboard continuation cursor repeated")
                seen.add(signature)
                args = {**args, "cursor": cursor}
            if not any(key in request for key in ("entity_column", "date_column")) and count != int(publication["row_count"]):
                raise DownloadError("Complete dashboard row count differs from published catalog")
            os.fsync(handle.fileno())
        with partial.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, strict=True)
            if reader.fieldnames != columns or sum(1 for _ in reader) != count:
                raise DownloadError("CSV readback did not match verified rows")
        with partial.open("rb") as handle:
            digest = hashlib.file_digest(handle, "sha256").hexdigest()
        os.link(partial, output)
        partial.unlink()
        return dict(status="complete", path=str(output), row_count=count, page_count=pages,
                    sha256=digest, tool="query_dashboard_dataset", request=request,
                    dataset_name=request["dataset_name"], schema=publication["schema"],
                    metadata=publication, warnings=sorted(warnings))
    except Exception as error:
        reason = str(error) if isinstance(error, DownloadError) else "Transport, filesystem or response processing failed"
        raise DownloadError(f"{reason}. Incomplete file: {partial}") from None
