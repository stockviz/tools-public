"""Stream authorized market-history pages to a verified local CSV without an LLM."""
import csv
import hashlib
import json
import os
import re
import tempfile
from datetime import date
from pathlib import Path
from typing import Any, Awaitable, Callable


COLUMNS = {
    "get_nav_history": ["scheme_code", "scheme_name", "date", "nav", "auto_id"],
    "get_index_history": ["index_name", "date", "close"],
}


class DownloadError(Exception):
    """Report a failed export without exposing upstream payloads or credentials."""


def validate_request(tool: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Validate one immutable first-page request and explicitly select JSON rows."""
    if tool not in COLUMNS:
        raise DownloadError("Only NAV and index history downloads are supported")
    allowed = {"scheme_code", "start", "end", "limit"} if tool == "get_nav_history" else {"index_name", "start", "end", "limit"}
    if set(arguments) - allowed:
        raise DownloadError("Unsupported request field; cursors are managed internally")
    values = {key: value for key, value in arguments.items() if value is not None}
    size = values.get("limit", 1000)
    if type(size) is not int or not 1 <= size <= 1000:
        raise DownloadError("Page size must be an integer from 1 to 1000")
    if tool == "get_nav_history":
        code = values.get("scheme_code")
        if not isinstance(code, str) or not re.fullmatch(r"[1-9][0-9]*", code) or int(code) > 2147483647:
            raise DownloadError("Scheme code must be a canonical positive SQL integer string")
    else:
        name = values.get("index_name")
        if not isinstance(name, str) or not 1 <= len(name) <= 256 or any(ord(char) < 32 for char in name):
            raise DownloadError("Supply an exact nonempty index name without control characters")
    for key in ("start", "end"):
        if key in values:
            try:
                if date.fromisoformat(values[key]).isoformat() != values[key]:
                    raise ValueError()
            except (TypeError, ValueError):
                raise DownloadError(f"{key} must be a real ISO calendar date") from None
    if "start" in values and "end" in values and values["start"] > values["end"]:
        raise DownloadError("start must not be after end")
    return {**values, "limit": size, "format": "json", "cursor": None}


def unpack(result: Any) -> dict[str, Any]:
    """Extract SDK structured content or one JSON text block without transcription."""
    if getattr(result, "isError", False):
        raise DownloadError("Remote MCP tool returned an error; no complete CSV was published")
    value = getattr(result, "structuredContent", None)
    if value is None:
        blocks = [item.text for item in getattr(result, "content", []) if getattr(item, "type", None) == "text"]
        if len(blocks) != 1:
            raise DownloadError("Expected one JSON result from the remote MCP tool")
        try:
            value = json.loads(blocks[0])
        except (TypeError, ValueError):
            raise DownloadError("Remote tool result was not valid JSON") from None
    if not isinstance(value, dict) or value.get("status") != "ok":
        raise DownloadError("Remote market data is unavailable or did not return status=ok")
    return value


def checked_key(row: dict[str, Any], tool: str, args: dict[str, Any]) -> tuple:
    """Check row shape, source identity, date bounds and exact signed sort keys."""
    if not isinstance(row, dict) or set(row) != set(COLUMNS[tool]):
        raise DownloadError("Remote row columns do not match the history contract")
    if any(value is not None and not isinstance(value, str) for value in row.values()):
        raise DownloadError("Remote history fields must remain strings or null, not floats")
    day = row["date"]
    try:
        if date.fromisoformat(day).isoformat() != day:
            raise ValueError()
    except (TypeError, ValueError):
        raise DownloadError("Remote observation has an invalid date") from None
    if (args.get("start") and day < args["start"]) or (args.get("end") and day > args["end"]):
        raise DownloadError("Remote observation falls outside the requested date window")
    if tool == "get_nav_history":
        if row["scheme_code"] != args["scheme_code"]:
            raise DownloadError("Remote observation belongs to a different scheme")
        identifier = row["auto_id"]
        if not isinstance(identifier, str) or not re.fullmatch(r"0|-?[1-9][0-9]*", identifier):
            raise DownloadError("Remote AUTO_ID is not an exact signed integer string")
        number = int(identifier)
        if not -(2**63) <= number < 2**63:
            raise DownloadError("Remote AUTO_ID is outside the signed-bigint range")
        return day, number
    if row["index_name"] != args["index_name"]:
        raise DownloadError("Remote observation belongs to a different index")
    return (day,)


def check_page(value: dict[str, Any], size: int) -> tuple[list, bool, str | None]:
    """Require internally consistent counts and explicit continuation semantics."""
    rows, page = value.get("rows"), value.get("page")
    if not isinstance(rows, list) or not isinstance(page, dict):
        raise DownloadError("Remote result has no valid rows/page envelope")
    if type(page.get("limit")) is not int or page["limit"] != size:
        raise DownloadError("Remote page size changed during the export")
    if type(page.get("returned_count")) is not int or page["returned_count"] != len(rows) or len(rows) > size:
        raise DownloadError("Remote page row count is inconsistent")
    more, cursor = page.get("has_more"), page.get("next_cursor")
    if type(more) is not bool:
        raise DownloadError("Remote has_more is not a boolean")
    if more and (not rows or not isinstance(cursor, str) or not cursor or len(cursor) > 4096):
        raise DownloadError("Remote continuation has no usable opaque cursor or no progress")
    if not more and cursor is not None:
        raise DownloadError("Final page unexpectedly contains a continuation cursor")
    return rows, more, cursor


async def download(call_tool: Callable[..., Awaitable[Any]], tool: str, arguments: dict[str, Any],
                   output: Path, max_pages: int = 10000) -> dict[str, Any]:
    """Persist every page, verify the CSV, then publish without replacing any file."""
    args = validate_request(tool, arguments)
    if type(max_pages) is not int or max_pages < 1:
        raise DownloadError("max_pages must be a positive integer")
    output = Path(output).absolute()
    if output.exists() or output.is_symlink():
        raise DownloadError("Destination already exists; choose a new filename")
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=output.name + ".", suffix=".partial", dir=output.parent)
    partial = Path(temporary)
    rows_written, pages = 0, 0
    first_date, last_date, previous = None, None, None
    seen = set()
    warnings = {"Pages are not a consistent snapshot during a server mirror refresh; restart the export after a refresh if needed."}
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=COLUMNS[tool], lineterminator="\r\n")
            writer.writeheader()
            while True:
                if pages >= max_pages:
                    raise DownloadError("Page budget exhausted before export completion")
                value = unpack(await call_tool(tool, dict(args)))
                rows, more, cursor = check_page(value, args["limit"])
                pages += 1
                for row in rows:
                    key = checked_key(row, tool, args)
                    if previous is not None and key <= previous:
                        raise DownloadError("Remote keys repeated or did not increase; no rows were silently deduplicated")
                    previous = key
                    first_date = first_date or row["date"]
                    last_date = row["date"]
                    writer.writerow(row)
                    rows_written += 1
                handle.flush()
                for warning in value.get("metadata", {}).get("warnings", []):
                    if (isinstance(warning, str) and len(warnings) < 50
                            and not warning.startswith("This is a partial history page,")):
                        # That warning describes individual pages, not this fully assembled CSV.
                        warnings.add(warning)
                if not more:
                    break
                digest = hashlib.sha256(cursor.encode("utf-8")).hexdigest()
                if digest in seen:
                    raise DownloadError("Remote continuation cursor repeated")
                seen.add(digest)
                # Pass the original string object through; never decode, trim or repair it.
                args = {**args, "cursor": cursor}
            os.fsync(handle.fileno())
        with partial.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, strict=True)
            if reader.fieldnames != COLUMNS[tool] or sum(1 for _ in reader) != rows_written:
                raise DownloadError("CSV readback did not match the verified row count")
        with partial.open("rb") as binary:
            digest = hashlib.file_digest(binary, "sha256").hexdigest()
        # Same-directory hard link atomically refuses an existing destination, including races.
        os.link(partial, output)
        partial.unlink()
        return dict(status="complete", path=str(output), row_count=rows_written, page_count=pages,
                    first_date=first_date, last_date=last_date, sha256=digest, tool=tool,
                    request={key: value for key, value in args.items() if key != "cursor"},
                    warnings=sorted(warnings))
    except Exception as error:
        # Retain clearly named partial bytes for inspection, but never publish an incomplete CSV.
        reason = str(error) if isinstance(error, DownloadError) else "Transport, filesystem or response processing failed"
        raise DownloadError(f"{reason}. Incomplete file: {partial}") from None
