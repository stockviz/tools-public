"""Stream authorized market-history pages to a verified local CSV without an LLM."""
import asyncio
import csv
import hashlib
import json
import math
import os
import re
import tempfile
import time
from datetime import date, datetime, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any, Awaitable, Callable

import httpx


COLUMNS = {
    "get_nav_history": ["scheme_code", "scheme_name", "date", "nav", "auto_id"],
    "get_index_history": ["index_name", "date", "close"],
    "get_equity_history": ["symbol", "series", "date", "open", "high", "low", "close", "last",
                           "previous_close", "total_traded_quantity", "total_traded_value", "num_transactions"],
}


class DownloadError(Exception):
    """Report a failed export without exposing upstream payloads or credentials."""


def validate_label(value: Any, field: str) -> None:
    """Require exact safe identifiers using the server's UTF-16 length units."""
    if (not isinstance(value, str) or not value or any(ord(c) < 32 or ord(c) == 127 for c in value)
            or any(0xD800 <= ord(c) <= 0xDFFF for c in value)
            or len(value.encode("utf-16-le")) // 2 > 256):
        raise DownloadError(f"{field} must be an exact nonempty identifier of at most 256 UTF-16 units without controls")


def validate_request(tool: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Validate one immutable first-page request and explicitly select JSON rows."""
    if tool not in COLUMNS:
        raise DownloadError("Only NAV, index and equity history downloads are supported")
    identity = {"get_nav_history": {"scheme_code"}, "get_index_history": {"index_name"},
                "get_equity_history": {"symbol", "series"}}[tool]
    allowed = identity | {"start", "end", "limit"}
    if set(arguments) - allowed:
        raise DownloadError("Unsupported request field; cursors are managed internally")
    values = {key: value for key, value in arguments.items() if value is not None}
    size = values.get("limit", 1000)
    if type(size) is not int or not 1 <= size <= 1000:
        raise DownloadError("Page size must be an integer from 1 to 1000")
    if tool == "get_nav_history":
        code = values.get("scheme_code")
        if not isinstance(code, str) or not re.fullmatch(r"[1-9][0-9]*", code) or int(code) > 2147483647:
            raise DownloadError("Scheme code must be a canonical positive SQL integer string")
    elif tool == "get_equity_history":
        for field in ("symbol", "series"):
            validate_label(values.get(field), field)
    else:
        name = values.get("index_name")
        if not isinstance(name, str) or not 1 <= len(name) <= 256 or any(ord(char) < 32 for char in name):
            raise DownloadError("Supply an exact nonempty index name without control characters")
    for key in ("start", "end"):
        if key in values:
            try:
                if date.fromisoformat(values[key]).isoformat() != values[key]:
                    raise ValueError()
            except (TypeError, ValueError):
                raise DownloadError(f"{key} must be a real ISO calendar date") from None
    if "start" in values and "end" in values and values["start"] > values["end"]:
        raise DownloadError("start must not be after end")
    return {**values, "limit": size, "format": "json", "cursor": None}


class PublicToolError(DownloadError):
    """Carry validated policy metadata, never an upstream message or SDK body."""

    def __init__(self, code: str, category: str, retry_after_seconds: float | None,
                 reset_at: str | int | float | None):
        """Build actionable diagnostics exclusively from recognized public fields."""
        self.code = code
        self.category = category
        self.retry_after_seconds = retry_after_seconds
        self.reset_at = reset_at
        super().__init__(f"Remote export stopped: code={code}, category={category}, "
                         f"retry_after_seconds={retry_after_seconds}, reset_at={reset_at}. "
                         "Retry later using a new filename; retained partial files are not resumable")


def safe_delay(value: Any) -> float | None:
    """Accept only finite nonnegative JSON numbers as explicit wait durations."""
    if type(value) not in (int, float):
        return None
    try:
        result = float(value)
    except (ValueError, OverflowError):
        return None
    return result if math.isfinite(result) and result >= 0 else None


def public_error(value: Any) -> PublicToolError | None:
    """Recognize policy envelopes while withholding arbitrary upstream error text."""
    if not isinstance(value, dict) or not isinstance(value.get("error"), dict):
        return None
    error = value["error"]
    code = error.get("code")
    if code not in ("download_rate_limited", "policy_unavailable", "query_timeout"):
        return None
    category = error.get("category")
    # Unknown categories fail closed; only the three explicit transient categories retry.
    categories = {"concurrency", "global_concurrency", "page_rate", "request_rate", "policy_unavailable", "query_timeout",
                  "burst", "distinct_instruments", "state_capacity", "page_size", "response_bound",
                  "daily", "day_rate", "daily_rows", "daily_bytes", "daily_pages",
                  "daily_requests", "daily_exports", "row_budget", "byte_budget",
                  "rows", "bytes", "requests", "pages", "exports", "timeout"}
    category = category if isinstance(category, str) and category in categories else "unknown"
    reset = error.get("reset_at")
    if isinstance(reset, str):
        try:
            if len(reset) > 64 or any(ord(char) < 32 or ord(char) == 127 for char in reset):
                raise ValueError
            parsed = datetime.fromisoformat(reset.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError
        except ValueError:
            reset = None
    elif safe_delay(reset) is None:
        reset = None
    return PublicToolError(code, category, safe_delay(error.get("retry_after_seconds")), reset)


def unpack(result: Any) -> dict[str, Any]:
    """Extract exact JSON rows or safe policy metadata, never raw error messages."""
    failed = getattr(result, "isError", False)
    value = getattr(result, "structuredContent", None)
    if value is None:
        blocks = [item.text for item in getattr(result, "content", []) if getattr(item, "type", None) == "text"]
        if len(blocks) != 1:
            raise DownloadError("Expected one JSON result from the remote MCP tool")
        try:
            value = json.loads(blocks[0])
        except (TypeError, ValueError):
            raise DownloadError("Remote tool result was not valid JSON") from None
    error = public_error(value)
    if error is not None:
        raise error
    if failed:
        raise DownloadError("Remote MCP tool returned an error; no complete CSV was published")
    if not isinstance(value, dict) or value.get("status") != "ok":
        raise DownloadError("Remote market data is unavailable or did not return status=ok")
    return value


def http_rate_error(error: httpx.HTTPStatusError) -> PublicToolError:
    """Read only HTTP 429 Retry-After, excluding response bodies and request URLs."""
    value = error.response.headers.get("Retry-After", "")
    delay, reset = None, None
    if re.fullmatch(r"[0-9]{1,12}", value):
        delay = float(value)
    elif len(value) <= 128:
        try:
            parsed = parsedate_to_datetime(value)
            if parsed.tzinfo is not None:
                delay = max(0.0, parsed.timestamp() - time.time())
                reset = parsed.astimezone(timezone.utc).isoformat()
        except (TypeError, ValueError, OverflowError):
            pass
    return PublicToolError("download_rate_limited", "http_rate", delay, reset)


async def fetch_page(call_tool: Callable[..., Awaitable[Any]], tool: str,
                     args: dict[str, Any], wait_remaining: float) -> tuple[dict[str, Any], float]:
    """Retry the identical opaque-cursor request at most three times within export wait budget."""
    for attempt in range(3):
        try:
            return unpack(await call_tool(tool, dict(args))), wait_remaining
        except httpx.HTTPStatusError as error:
            if error.response.status_code != 429:
                raise
            failure = http_rate_error(error)
        except PublicToolError as error:
            failure = error
        delay = failure.retry_after_seconds
        # A later advertised reset must not be bypassed by a shorter retry hint.
        if delay is not None and failure.reset_at is not None:
            reset_epoch = (datetime.fromisoformat(failure.reset_at.replace("Z", "+00:00")).timestamp()
                           if isinstance(failure.reset_at, str) else failure.reset_at)
            delay = max(delay, reset_epoch - time.time())
        transient = ((failure.code == "download_rate_limited"
                      and failure.category in {"concurrency", "global_concurrency", "page_rate", "request_rate", "http_rate"})
                     or (failure.code == "policy_unavailable" and failure.category == "policy_unavailable"))
        if not transient or delay is None or attempt == 2 or delay > wait_remaining:
            raise failure from None
        started = time.monotonic()
        await asyncio.sleep(delay)
        # Charge actual elapsed sleep as well as requested time; never replenish between pages.
        wait_remaining = max(0.0, wait_remaining - max(delay, time.monotonic() - started))
    raise DownloadError("Page attempts exhausted")


def checked_key(row: dict[str, Any], tool: str, args: dict[str, Any]) -> tuple:
    """Check row shape, source identity, date bounds and exact signed sort keys."""
    if not isinstance(row, dict) or set(row) != set(COLUMNS[tool]):
        raise DownloadError("Remote row columns do not match the history contract")
    for field, value in row.items():
        # NUM_TXNS is a native nullable SQL int; price/quantity DOUBLEs remain text.
        if tool == "get_equity_history" and field == "num_transactions" and type(value) is int:
            if not -(2**31) <= value < 2**31:
                raise DownloadError("Remote transaction count exceeds the signed SQL int range")
            continue
        if value is not None and not isinstance(value, str):
            raise DownloadError("Remote history fields must remain strings or null, except an integer equity transaction count")
    day = row["date"]
    try:
        if date.fromisoformat(day).isoformat() != day:
            raise ValueError()
    except (TypeError, ValueError):
        raise DownloadError("Remote observation has an invalid date") from None
    if (args.get("start") and day < args["start"]) or (args.get("end") and day > args["end"]):
        raise DownloadError("Remote observation falls outside the requested date window")
    if tool == "get_nav_history":
        if row["scheme_code"] != args["scheme_code"]:
            raise DownloadError("Remote observation belongs to a different scheme")
        identifier = row["auto_id"]
        if not isinstance(identifier, str) or not re.fullmatch(r"0|-?[1-9][0-9]*", identifier):
            raise DownloadError("Remote AUTO_ID is not an exact signed integer string")
        number = int(identifier)
        if not -(2**63) <= number < 2**63:
            raise DownloadError("Remote AUTO_ID is outside the signed-bigint range")
        return day, number
    if tool == "get_equity_history":
        if any(row[field] != args[field] for field in ("symbol", "series")):
            raise DownloadError("Remote observation belongs to a different equity symbol/series")
        return (day,)
    if row["index_name"] != args["index_name"]:
        raise DownloadError("Remote observation belongs to a different index")
    return (day,)


def check_page(value: dict[str, Any], size: int) -> tuple[list, bool, str | None]:
    """Require internally consistent counts and explicit continuation semantics."""
    rows, page = value.get("rows"), value.get("page")
    if not isinstance(rows, list) or not isinstance(page, dict):
        raise DownloadError("Remote result has no valid rows/page envelope")
    if type(page.get("limit")) is not int or page["limit"] != size:
        raise DownloadError("Remote page size changed during the export")
    if type(page.get("returned_count")) is not int or page["returned_count"] != len(rows) or len(rows) > size:
        raise DownloadError("Remote page row count is inconsistent")
    more, cursor = page.get("has_more"), page.get("next_cursor")
    if type(more) is not bool:
        raise DownloadError("Remote has_more is not a boolean")
    if more and (not rows or not isinstance(cursor, str) or not cursor or len(cursor) > 4096):
        raise DownloadError("Remote continuation has no usable opaque cursor or no progress")
    if not more and cursor is not None:
        raise DownloadError("Final page unexpectedly contains a continuation cursor")
    return rows, more, cursor


async def download(call_tool: Callable[..., Awaitable[Any]], tool: str, arguments: dict[str, Any],
                   output: Path, max_pages: int = 10000) -> dict[str, Any]:
    """Persist verified pages with bounded policy retries, then publish without replacement."""
    args = validate_request(tool, arguments)
    wait_remaining = 30.0
    if type(max_pages) is not int or max_pages < 1:
        raise DownloadError("max_pages must be a positive integer")
    output = Path(output).absolute()
    if output.exists() or output.is_symlink():
        raise DownloadError("Destination already exists; choose a new filename")
    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=output.name + ".", suffix=".partial", dir=output.parent)
    partial = Path(temporary)
    rows_written, pages = 0, 0
    first_date, last_date, previous = None, None, None
    seen = set()
    warnings = {"Pages are not a consistent snapshot during a server mirror refresh; restart the export after a refresh if needed."}
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=COLUMNS[tool], lineterminator="\r\n")
            writer.writeheader()
            while True:
                if pages >= max_pages:
                    raise DownloadError("Page budget exhausted before export completion")
                value, wait_remaining = await fetch_page(call_tool, tool, args, wait_remaining)
                rows, more, cursor = check_page(value, args["limit"])
                pages += 1
                for row in rows:
                    key = checked_key(row, tool, args)
                    if previous is not None and key <= previous:
                        raise DownloadError("Remote keys repeated or did not increase; no rows were silently deduplicated")
                    previous = key
                    first_date = first_date or row["date"]
                    last_date = row["date"]
                    writer.writerow(row)
                    rows_written += 1
                handle.flush()
                for warning in value.get("metadata", {}).get("warnings", []):
                    if (isinstance(warning, str) and len(warnings) < 50
                            and not warning.startswith("This is a partial history page,")):
                        # That warning describes individual pages, not this fully assembled CSV.
                        warnings.add(warning)
                if not more:
                    break
                digest = hashlib.sha256(cursor.encode("utf-8")).hexdigest()
                if digest in seen:
                    raise DownloadError("Remote continuation cursor repeated")
                seen.add(digest)
                # Pass the original string object through; never decode, trim or repair it.
                args = {**args, "cursor": cursor}
            os.fsync(handle.fileno())
        with partial.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle, strict=True)
            if reader.fieldnames != COLUMNS[tool] or sum(1 for _ in reader) != rows_written:
                raise DownloadError("CSV readback did not match the verified row count")
        with partial.open("rb") as binary:
            digest = hashlib.file_digest(binary, "sha256").hexdigest()
        # Same-directory hard link atomically refuses an existing destination, including races.
        os.link(partial, output)
        partial.unlink()
        return dict(status="complete", path=str(output), row_count=rows_written, page_count=pages,
                    first_date=first_date, last_date=last_date, sha256=digest, tool=tool,
                    request={key: value for key, value in args.items() if key != "cursor"},
                    warnings=sorted(warnings))
    except Exception as error:
        # Retain clearly named partial bytes for inspection, but never publish an incomplete CSV.
        reason = str(error) if isinstance(error, DownloadError) else "Transport, filesystem or response processing failed"
        raise DownloadError(f"{reason}. Incomplete file: {partial}") from None
