"""Command-line login, complete CSV downloads and local MCP serving."""
import argparse
import asyncio
import json
import sys
from pathlib import Path

from mcp_consumer.client import run_download, run_equity_catalog
from mcp_consumer.download import DownloadError
from mcp_consumer.server import build_server
from mcp_consumer.transport import TransportError, authenticate_login, connect, validate_url


DEFAULT_STATE = Path.home() / ".local" / "state" / "stockviz-mcp-consumer"


def parser() -> argparse.ArgumentParser:
    """Describe the same explicit configuration for login, CLI and Goose's extension."""
    result = argparse.ArgumentParser(description="Download full StockViz MCP histories without copying rows or cursors through an LLM")
    result.add_argument("--config", type=Path, help="Private local JSON configuration")
    result.add_argument("--url", help="Remote MCP endpoint; overrides server_url in config")
    result.add_argument("--state-dir", type=Path, help="Private OAuth cache, independent of Goose and Hermes")
    commands = result.add_subparsers(dest="command", required=True)
    commands.add_parser("login", help="Authorize this client interactively in a browser")
    for name, flag, help_text in [("nav", "--scheme-code", "Exact NAV scheme code"),
                                  ("index", "--index-name", "Exact index name, including TR when applicable"),
                                  ("equity", "--symbol", "Exact equity symbol; series is also required")]:
        command = commands.add_parser(name, help="Download every page and create a verified CSV")
        command.add_argument(flag, required=True, help=help_text)
        if name == "equity":
            command.add_argument("--series", required=True, help="Exact exchange series, for example EQ")
        command.add_argument("--start", help="Inclusive YYYY-MM-DD; omitted means available history")
        command.add_argument("--end", help="Inclusive YYYY-MM-DD; omitted means latest available data")
        command.add_argument("--page-size", type=int, default=1000)
        command.add_argument("--max-pages", type=int, default=10000)
        command.add_argument("--output", type=Path, required=True, help="New local CSV path; existing files are never replaced")
    catalog = commands.add_parser("equities", help="Read one bounded equity catalog page")
    catalog.add_argument("--search")
    catalog.add_argument("--series")
    catalog.add_argument("--page-size", type=int, default=250)
    catalog.add_argument("--cursor", help="Exact next_cursor from the same catalog filters and page size")
    serve = commands.add_parser("serve", help="Expose local download tools to Goose over stdio")
    serve.add_argument("--output-dir", type=Path, help="Only this directory accepts model-selected CSV basenames")
    return result


def resolve_config(args: argparse.Namespace) -> argparse.Namespace:
    """Resolve private configuration without retaining a deployment-specific default."""
    config = {}
    base = Path.cwd()
    if args.config is not None:
        path = args.config.expanduser().resolve()
        base = path.parent
        try:
            config = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raise DownloadError("Cannot read config: supply a valid local JSON file") from None
        if not isinstance(config, dict) or set(config) - {"server_url", "state_dir", "output_dir"}:
            raise DownloadError("Config contains unsupported fields; credentials must stay in the OAuth cache")
        for key in ("server_url", "state_dir", "output_dir"):
            if key in config and (not isinstance(config[key], str) or not config[key].strip()):
                raise DownloadError("Config endpoint and path fields must be nonempty strings")
    args.url = args.url if args.url is not None else config.get("server_url")
    if not args.url:
        raise DownloadError("Configure server_url in --config or supply --url; no server is selected by default")
    try:
        validate_url(args.url)
    except TransportError:
        raise DownloadError("Invalid endpoint: use HTTPS without embedded credentials, query or fragment") from None
    if args.state_dir is None:
        value = Path(config["state_dir"]).expanduser() if "state_dir" in config else DEFAULT_STATE
        args.state_dir = value if value.is_absolute() else base / value
    else:
        args.state_dir = args.state_dir.expanduser().absolute()
    if args.command == "serve":
        if args.output_dir is None:
            if "output_dir" not in config:
                raise DownloadError("serve requires --output-dir or output_dir in config")
            value = Path(config["output_dir"]).expanduser()
            args.output_dir = value if value.is_absolute() else base / value
        else:
            args.output_dir = args.output_dir.expanduser().absolute()
    return args


async def execute(args: argparse.Namespace) -> dict:
    """Run one explicit login or noninteractive download, returning small metadata."""
    if args.command == "login":
        async with connect(args.url, args.state_dir, interactive=True) as session:
            tools = await session.list_tools()
            names = {tool.name for tool in tools.tools}
            if not {"get_nav_history", "get_index_history"}.issubset(names):
                raise DownloadError("Connected server does not expose the required history tools")
            await authenticate_login(session, args.url, args.state_dir)
        return {"status": "authenticated", "source_url": args.url, "state_dir": str(args.state_dir)}
    if args.command == "equities":
        return await run_equity_catalog(args.url, args.state_dir,
            dict(search=args.search, series=args.series, limit=args.page_size, cursor=args.cursor))
    field = {"nav": "scheme_code", "index": "index_name", "equity": "symbol"}[args.command]
    values = {field: getattr(args, field), "start": args.start, "end": args.end, "limit": args.page_size}
    if args.command == "equity":
        values["series"] = args.series
    tool = {"nav": "get_nav_history", "index": "get_index_history", "equity": "get_equity_history"}[args.command]
    return await run_download(args.url, args.state_dir, tool, values, args.output, max_pages=args.max_pages)


def main() -> int:
    """Keep stdio protocol clean and suppress raw credential-bearing SDK exceptions."""
    args = parser().parse_args()
    try:
        args = resolve_config(args)
        if args.command == "serve":
            build_server(args.url, args.state_dir, args.output_dir).run(transport="stdio")
        else:
            print(json.dumps(asyncio.run(execute(args)), indent=2))
        return 0
    except KeyboardInterrupt:
        print("Cancelled; any partial export remains incomplete.", file=sys.stderr)
        return 130
    except DownloadError as error:
        print(str(error), file=sys.stderr)
        return 1
    except Exception:
        print("MCP connection or authorization failed. Check --url and run login interactively; raw SDK errors are suppressed to protect credentials.", file=sys.stderr)
        return 1
