"""StockViz's deterministic, authenticated MCP-to-CSV consumer."""

__version__ = "0.3.0"
