"""Validate bounded equity discovery separately from complete history exports."""
from datetime import date
from typing import Any

from mcp_consumer.download import DownloadError, check_page, fetch_page, validate_label


def validate_catalog(arguments: dict[str, Any]) -> dict[str, Any]:
    """Keep optional discovery filters and opaque continuation literal and bounded."""
    if set(arguments) - {'search', 'series', 'limit', 'cursor'}:
        raise DownloadError('Unsupported equity catalog field')
    values = {key: value for key, value in arguments.items() if value is not None}
    size = values.get('limit', 250)
    if type(size) is not int or not 1 <= size <= 1000:
        raise DownloadError('Catalog page size must be an integer from 1 to 1000')
    for field in ('search', 'series'):
        if field in values:
            validate_label(values[field], field)
    cursor = values.get('cursor')
    if cursor is not None and (not isinstance(cursor, str) or not cursor or len(cursor) > 4096):
        raise DownloadError('Catalog cursor must be an unchanged nonempty opaque string')
    return {**values, 'limit': size, 'cursor': cursor}


async def equity_catalog(call_tool, arguments: dict[str, Any]) -> dict[str, Any]:
    """Read one validated catalog page under the existing bounded quota retry policy."""
    args = validate_catalog(arguments)
    value, _ = await fetch_page(call_tool, 'list_equities', args, 30.0)
    rows, more, cursor = check_page(value, args['limit'])
    if more and cursor == args['cursor']:
        raise DownloadError('Remote catalog continuation cursor repeated')
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or set(row) != {'symbol', 'series', 'first_date', 'last_date', 'observations'}:
            raise DownloadError('Remote catalog columns do not match the equity contract')
        for field in ('symbol', 'series'):
            validate_label(row[field], field)
        identity = row['symbol'], row['series']
        if identity in seen or ('series' in args and row['series'] != args['series']):
            raise DownloadError('Remote catalog returned duplicate or wrong-series identities')
        seen.add(identity)
        if 'search' in args and args['search'].lower() not in row['symbol'].lower():
            raise DownloadError('Remote catalog symbol does not match the literal search')
        for field in ('first_date', 'last_date'):
            try:
                if date.fromisoformat(row[field]).isoformat() != row[field]:
                    raise ValueError
            except (TypeError, ValueError):
                raise DownloadError('Remote catalog date is invalid') from None
        count = row['observations']
        if (row['first_date'] > row['last_date'] or
                not (type(count) is int and count > 0 or
                     isinstance(count, str) and count.isascii() and count.isdigit() and int(count) > 0)):
            raise DownloadError('Remote catalog coverage/count is invalid')
    return value
